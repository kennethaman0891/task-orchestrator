import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [
    react(),
  ],
  server: {
    port: 1421,
    strictPort: true,
    host: true,
    proxy: {
      '/api': 'http://localhost:8765',
      '/ws': { target: 'ws://localhost:8765', ws: true }
    }
  },
  build: {
    outDir: 'dist',
    sourcemap: false
  }
});