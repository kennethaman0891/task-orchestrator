import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTerminals } from './hooks/useTerminals';
import { LiveClock } from './components/LiveClock';
import { StatsBar, StatsBarCompact } from './components/StatsBar';
import { AddTerminalCard } from './components/AddTerminalCard';
import { PlannerView } from './components/PlannerView';
import { WorkspaceTaskCenter } from './components/WorkspaceTaskCenter';
import { KanbanBoard } from './components/KanbanBoard';
import { RemoteControlPanel } from './components/RemoteControlPanel';
import { CodeEditor, fileIcon, markDiscardOnClose } from './components/CodeEditor';
import { TokenUsage } from './components/TokenUsage';
import { Toast, type ToastState } from './components/Toast';
import { WorkspaceBar, type View } from './components/WorkspaceBar';
import { Sidebar } from './components/Sidebar';
import { WorkspaceWizard, type WizardConfig } from './components/WorkspaceWizard';
import { TerminalWorkspace } from './components/TerminalWorkspace';
import type { DropChip } from './components/DroppedFileChip';
import { WorkspaceControlPanel, type ViewMode } from './components/WorkspaceControlPanel';
import { SplitView } from './components/SplitView';
import { CommandPalette } from './components/CommandPalette';
import { GitStatusBadge } from './components/GitStatusBadge';
import { GitSourceControl } from './components/GitSourceControl';
import { SearchPanel } from './components/SearchPanel';
import { SettingsModal } from './components/SettingsModal';
import { InspectorOverlay } from './components/InspectorOverlay';
import { InspectorPanel } from './components/InspectorPanel';
import { TerminalHost, TerminalAnchor } from './components/TerminalHost';
import { TerminalInput } from './terminal/TerminalInput';
import { DjangoReviewer } from './components/DjangoReviewer';
import { AgentWorkspace } from './features/agent-workspace/pages/AgentWorkspace';

import { tauri, listenEvent, isTauri, type EgoLiteStatus } from './terminal/channels';
import { Scheduler } from './terminal/TerminalScheduler';
import { TerminalManager } from './terminal/TerminalManager';
import { IDEView } from './components/IDEView';
import { WelcomeVideo } from './components/WelcomeVideo';
import { isClosed, cleanModel, baseName, modifierLabel } from './lib/format';
import { normalizeClaudeFresh } from './lib/claude';
import {
  launchCli,
  pushSessions,
  pushWorkspaces,
  fetchRemoteSessions,
  fetchRemoteWorkspaces,
  setTerminalAppliedModel,
  resetTerminalTasks,
  waitForOpencodeBoot,
  listFiles,
} from './api/client';
import { apiBase } from './api/base';
import { convertFileSrc } from '@tauri-apps/api/core';
import {
  type Workspace,
  type TemplateKey,
  type GridMode,
  newWorkspace,
  loadWorkspaces,
  saveWorkspaces,
  loadActiveWs,
  saveActiveWs,
  loadTheme,
  saveTheme,
  applyTheme,
  computeResponsiveLayout,
  templateCols,
  GRID_GAP,
  gridMins,
} from './workspace';
import type { SessionMeta } from './terminal/types';
import type { UnifiedTerminal, Annotation } from './types';
import type { FileEntry } from './api/client';
import { useTerminalState } from './hooks/useTerminalState';

// ── Drop dedupe ──────────────────────────────────────────────────────────
// EVERY drop path funnels into handleDrop below: the pane native capture
// handler, the pane React synthetic handler, the xterm-surface backstop,
// the workspace recovery layer, the window capture fallback and the
// tto://drag-drop event (OS drags). In some engines several of these fire
// for a single physical drop. Route exactly once per drop by keying on
// (target session + paths) inside a short window. Module scope (not state)
// so the guard survives re-renders and protects every callback identity.
let lastDropKey = '';
let lastDropMs = 0;
const DROP_DEDUPE_WINDOW_MS = 300;

/**
 * The terminal task orchestrator (spec §1).
 */

/** Runs the workspace-restore pass exactly once per app launch (StrictMode-safe). */
let restoreDone = false;

/**
 * Dedicated, independent IDE terminal session — NOT tied to any workspace
 * pane.  Lives in module scope (survives re-renders) and is lazily created
 * by `ensureIdeTerminal` the first time the IDE view opens.
 */
let ideTerminalSessionId: string | null = null;

/**
 * In-flight guard for creating the dedicated IDE terminal. Prevents a
 * StrictMode double-invoke (or an effect/command race) from creating two
 * 'ide' sessions at once. Reset to false once creation resolves/rejects.
 */
let ideTerminalCreating = false;

/**
 * Initial PTY size for freshly-created terminals. Must be GENEROUS (not 80×24):
 * a full-screen CLI (opencode, vim, htop…) reads TIOCGWINSZ the moment it
 * launches and draws its layout at that width. If it launches into an 80-col
 * PTY it draws an 80-col TUI and its banner/lines WRAP (garbled, "compressed").
 * We create wide (120×40) so the first frame is reasonable; TerminalPane's fit
 * then resizes to the exact card size and sends SIGWINCH. Rows 40 so full tall
 * cards don't clip the launch frame either.
 */
const INITIAL_TERMINAL_COLS = 120;
const INITIAL_TERMINAL_ROWS = 40;

/**
 * Measure an element's size with a ResizeObserver (rAF-throttled).
 * Drives the responsive grid engine — the workspace adapts to the ACTUAL
 * container size (which already excludes header, toolbar and sidebar).
 */
function useElementSize<T extends HTMLElement>() {
  // Callback ref: re-runs the observer whenever the tracked element (re)mounts.
  // `.container` only exists while view === 'grid', i.e. it mounts AFTER App's
  // first render — a plain useEffect([]) would observe nothing and leave the
  // size at {0,0}, which made the grid layout fall back to window.innerWidth
  // (too many columns → panes clamped to their min width → tiny compressed
  // terminal cards).
  const [node, setNode] = useState<T | null>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const ref = useCallback((el: T | null) => setNode((prev) => (prev === el ? prev : el)), []);
  useEffect(() => {
    if (!node) return;
    let raf = 0;
    const measure = () => {
      raf = 0;
      setSize({ w: node.clientWidth, h: node.clientHeight });
    };
    const ro = new ResizeObserver(() => {
      if (!raf) raf = requestAnimationFrame(measure);
    });
    ro.observe(node);
    measure();
    return () => {
      if (raf) cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [node]);
  return { ref, size };
}

export default function App() {
  const { terminals, tokenUsage, connected, lastUpdate } = useTerminals();
  const [view, setView] = useState<View>('workspace');
  const [toast, setToast] = useState<ToastState | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);
  const [workspaces, setWorkspaces] = useState<Workspace[]>(() => loadWorkspaces());
  const [activeId, setActiveId] = useState<string>(() => loadActiveWs());
  const [theme, setTheme] = useState<string>(() => loadTheme());
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [remoteOpen, setRemoteOpen] = useState(false);
  const [egoLite, setEgoLite] = useState<EgoLiteStatus | null>(null);
  const [openFiles, setOpenFiles] = useState<{ path: string; name: string; dirty?: boolean }[]>([]);
  const [activeFile, setActiveFile] = useState<string | null>(null);
  // Bumped on every goto-line request — forces the editor to remount (via its
  // key) so re-clicking the SAME search result / terminal link re-jumps.
  const [gotoNonce, setGotoNonce] = useState(0);
  // ── Command palette -------------------------------------------------------
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [availableFiles, setAvailableFiles] = useState<FileEntry[]>([]);
  // ── IDE panels ----------------------------------------------------------
  const [searchPanelOpen, setSearchPanelOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [gitPanelOpen, setGitPanelOpen] = useState(false);
  // ── UI Inspector (⌘+Shift+A) ------------------------------------------
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [annotations, setAnnotations] = useState<Annotation[]>([]);

  // ── New: focused terminal + view mode ──────────────────────────────────
  const [focusedTerminal, setFocusedTerminal] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('focus');
  // Pending lines indicator for auto-scroll
  const [pendingLines, setPendingLines] = useState(0);

  // ── Dedicated IDE terminal (independent of workspace panes) ───────────
  // Bumped to force re-renders when the module-level ideTerminalSessionId
  // changes or the underlying Rust session is recreated.
  const [ideTerminalReady, setIdeTerminalReady] = useState(false);

  // ── Attached-file chips: ChatGPT-style dropped-file pills per terminal ──
  // Keyed by the real (resolved) session id. Each terminal session keeps its
  // own stack (max 8). Added in App.handleDrop after a successful drop.
  const [dropChips, setDropChips] = useState<Record<string, DropChip[]>>({});

  // ── Quick-launch inline form (empty pane → project path + command) ──
  const [quickLaunchPane, setQuickLaunchPane] = useState<string | null>(null);
  const [quickLaunchPath, setQuickLaunchPath] = useState('');
  const [quickLaunchCmd, setQuickLaunchCmd] = useState('opencode');
  const [quickLaunchCount, setQuickLaunchCount] = useState(4);

  // ── Grid view state (for the card-grid layout tab) ─────────────────────
  const [expandedPane, setExpandedPane] = useState<string | null>(null);
  const manualExpandRef = useRef<Set<string>>(new Set());
  const [selectedPane, setSelectedPane] = useState<string | null>(null);
  const [proportionalPane, setProportionalPane] = useState<string | null>(null);
  const proportionalSnapshot = useRef<{ cols: number[]; rows: number[] } | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const { ref: containerRef, size: containerSize } = useElementSize<HTMLDivElement>();
  const autoExpandRef = useRef<Set<string>>(new Set());

  // Per-terminal scroll state (ref-backed, no re-renders)
  const { isAutoScroll, getPendingLines, markAtBottom, markScrolledUp, markNewOutput } =
    useTerminalState();

  useEffect(() => {
    applyTheme(theme);
    saveTheme(theme);
  }, [theme]);

  // --- Auto-fill projectPath from the directory the user ran `tto` from ---
  useEffect(() => {
    if (!isTauri()) return;
    let done = false;
    tauri
      .getLaunchCwd()
      .then((cwd) => {
        if (done || !cwd) return;
        setWorkspaces((prev) => {
          let changed = false;
          const next = prev.map((ws) => {
            if (!ws.projectPath) {
              changed = true;
              return { ...ws, projectPath: cwd };
            }
            return ws;
          });
          return changed ? next : prev;
        });
      })
      .catch(() => {});
    return () => {
      done = true;
    };
  }, []);

  // --- ego-lite browser automation status (Tauri only) ---
  useEffect(() => {
    if (!isTauri()) return;
    tauri
      .egoLiteStatus()
      .then(setEgoLite)
      .catch(() => {});
  }, []);

  // --- Rust native session state ---
  const [nativeSessions, setNativeSessions] = useState<SessionMeta[]>([]);
  const [sessionsLoaded, setSessionsLoaded] = useState(false);

  const [startupReady, setStartupReady] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [showWelcomePopup, setShowWelcomePopup] = useState(false);
  const welcomePopupTimer = useRef<number | null>(null);
  // Clear the welcome-popup auto-dismiss timer if the app unmounts.
  useEffect(() => {
    return () => {
      if (welcomePopupTimer.current !== null) {
        window.clearTimeout(welcomePopupTimer.current);
        welcomePopupTimer.current = null;
      }
    };
  }, []);
  useEffect(() => {
    if (!isTauri() || !connected || startupReady) return;
    resetTerminalTasks().finally(() => setStartupReady(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, startupReady]);

  // Listen to Rust terminal-updated events and refresh the session list.
  useEffect(() => {
    if (!isTauri()) return;
    Scheduler.start();
    let unlisten: (() => void) | null = null;
    const refresh = () => {
      tauri
        .list()
        .then((sessions) => {
          setNativeSessions(sessions);
          setSessionsLoaded(true);
        })
        .catch(() => {});
    };
    refresh();
    listenEvent('terminal-updated', refresh).then((unsub) => {
      unlisten = unsub;
    });
    return () => {
      Scheduler.stop();
      unlisten?.();
    };
  }, []);

  // Desktop → sidecar: publish native session links
  useEffect(() => {
    if (!isTauri() || nativeSessions.length === 0) return;
    const links = nativeSessions.map((s) => ({
      id: s.id,
      tty: s.tty || s.id,
      cwd: s.cwd || '',
      agent: s.agent || '',
    }));
    const h = setTimeout(() => {
      pushSessions(links);
    }, 800);
    return () => clearTimeout(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nativeSessions]);

  // Web/mobile client: hydrate from the shared sidecar state
  useEffect(() => {
    if (isTauri()) return;
    let cancelled = false;
    (async () => {
      try {
        const [ws, sess] = await Promise.all([fetchRemoteWorkspaces(), fetchRemoteSessions()]);
        if (cancelled) return;
        if (ws.length > 0) {
          setWorkspaces(ws as Workspace[]);
          setActiveId((cur) =>
            (ws as Workspace[]).some((w) => w.id === cur) ? cur : (ws[0] as Workspace).id,
          );
        }
        const metas: SessionMeta[] = sess
          .filter((s) => s.id && s.tty)
          .map((s) => ({
            id: s.id,
            workspace_id: '',
            shell: '',
            cwd: s.cwd || '',
            title: s.agent || s.tty,
            status: 'running' as const,
            agent: s.agent || '',
            created_at: 0,
            last_activity: 0,
            cols: INITIAL_TERMINAL_COLS,
            rows: INITIAL_TERMINAL_ROWS,
            tui_active: false,
            pid: 0,
            tty: s.tty,
          }));
        if (metas.length > 0) {
          setNativeSessions(metas);
          setSessionsLoaded(true);
        }
      } catch {
        /* sidecar not reachable yet — next reload retries */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Fetch top-level files on mount for command palette (recursive).
  // Seed from a WORKSPACE project path — the backend rejects an empty path
  // (400: listing the whole home dir was a security issue), so an empty seed
  // would both spam console errors and leave the palette's file index empty.
  const seededFilesRef = useRef(false);
  useEffect(() => {
    if (seededFilesRef.current) return;
    const seed = workspaces.find((w) => w.projectPath)?.projectPath;
    if (!seed) return; // re-run once a workspace projectPath lands
    seededFilesRef.current = true;
    loadAllFiles(seed, 0, 4)
      .then((files) => setAvailableFiles(files.filter((f) => !f.is_dir)))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const restoringRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!isTauri() || !sessionsLoaded) return;
    if (restoreDone) return;
    restoreDone = true;
    const liveIds = new Set(nativeSessions.map((s) => s.id));
    for (const ws of workspaces) {
      for (const pane of ws.panes) {
        if (!pane.tty || liveIds.has(pane.tty)) continue;
        const key = `${ws.id}:${pane.id}`;
        if (restoringRef.current.has(key)) continue;
        restoringRef.current.add(key);
        assignPane(ws.id, pane.id, null);
        tauri
          .create(ws.projectPath || undefined, ws.id, INITIAL_TERMINAL_COLS, INITIAL_TERMINAL_ROWS)
          .then((meta) => assignPane(ws.id, pane.id, meta.id))
          .catch(() => {})
          .finally(() => restoringRef.current.delete(key));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nativeSessions, sessionsLoaded]);

  useEffect(() => {
    const active = workspaces.find((w) => w.id === activeId) || workspaces[0];
    if (active) saveActiveWs(active.id);
    saveWorkspaces(workspaces);
    const h = setTimeout(() => {
      pushWorkspaces(workspaces);
    }, 600);
    return () => clearTimeout(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaces, activeId]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey)) return;
      // Skip shortcut handling when user is typing in an input/textarea/contenteditable
      const tag = document.activeElement?.tagName;
      const isInput =
        document.activeElement?.getAttribute('contenteditable') === 'true' ||
        (document.activeElement as any)?.isContentEditable;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || isInput) return;
      if (e.key === 't' || e.key === 'T') {
        e.preventDefault();
        setView('wizard');
      } else if (e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        setCommandPaletteOpen((o) => !o);
      } else if (e.shiftKey && (e.key === 'f' || e.key === 'F')) {
        // Cmd+Shift+F: Open search panel
        e.preventDefault();
        setSearchPanelOpen((o) => !o);
      } else if (e.key === ',' && e.shiftKey) {
        // Cmd+Shift+, : Open settings
        e.preventDefault();
        setSettingsOpen((o) => !o);
      } else if (e.key === 'g' && e.shiftKey) {
        // Cmd+Shift+G: Toggle git panel
        e.preventDefault();
        setGitPanelOpen((o) => !o);
      } else if (e.shiftKey && (e.key === 'a' || e.key === 'A')) {
        // Cmd+Shift+A: Toggle UI inspector
        e.preventDefault();
        setInspectorOpen((o) => !o);
      } else if (/^[1-9]$/.test(e.key)) {
        e.preventDefault();
        const idx = Number(e.key) - 1;
        if (workspaces[idx]) {
          setActiveId(workspaces[idx].id);
          setView('workspace');
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaces]);

  const showToast = useCallback((message: string, error = false) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ message, error, id: Date.now() });
    toastTimer.current = window.setTimeout(() => setToast(null), 4000);
  }, []);

  // Clear pending toast timer on unmount to avoid leaking the timeout.
  useEffect(() => {
    return () => {
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    };
  }, []);

  const activeWs = workspaces.find((w) => w.id === activeId) || workspaces[0];

  // ── Unified terminal map ─────────────────────────────────────────────
  const unifiedTerminals = useMemo(() => {
    const merged: Record<string, UnifiedTerminal> = { ...terminals };
    for (const s of nativeSessions) {
      // Skip if we don't have a tty (shouldn't happen but safety check)
      if (!s.tty) continue;

      const key = s.tty; // Always use tty as the key to match frontend terminals state
      const existing = merged[key];
      if (existing) {
        // Preserve frontend data (including session_name) and add Rust-specific fields
        merged[key] = { ...existing, session_id: s.id, rust_status: s.status };
      } else {
        // Create placeholder - session_name will be filled by backend data
        merged[key] = {
          tty: s.tty,
          agent: s.agent || '',
          cwd: s.cwd,
          is_live: s.status === 'running',
          tokens: { tokens_input: 0, tokens_output: 0, cost: 0, model: '', session_title: s.title },
          // Seed with the Rust title; overwritten by backend-persisted
          // session_name once the sidecar poll includes this tty.
          session_name: s.title,
          window_name: '',
          pane_title: s.title,
          session_context: '',
          session_summary: '',
          pending_cli: false,
          live_output: '',
          suggested_task: '',
          current_task: null,
          next_task: null,
          queue: [],
          history: [],
          session_id: s.id,
          rust_status: s.status,
        };
      }
    }
    return merged;
  }, [terminals, nativeSessions]);

  // Only live terminals appear in lists/dropdowns
  const list = Object.keys(unifiedTerminals).filter((tty) => !isClosed(unifiedTerminals[tty]));

  // Auto-focus the first terminal when sessions load and none is selected.
  // Prevents the blank-screen / empty-state-on-startup issue.
  useEffect(() => {
    if (focusedTerminal || !sessionsLoaded) return;
    if (isTauri()) {
      if (nativeSessions.length === 0) return;
      setFocusedTerminal(nativeSessions[0].id);
    } else {
      // Web fallback: auto-select first live sidecar terminal
      if (list.length > 0) setFocusedTerminal(list[0]);
    }
  }, [nativeSessions, sessionsLoaded, focusedTerminal, list]);

  // Every workspace pane's session id (pane.tty), across ALL workspaces, deduped.
  // Passed to TerminalWorkspace so it can keep one xterm mounted per session and
  // just show/hide on focus change — the fix for panes going blank on tab switch.
  const allWorkspaceSessionIds = useMemo(() => {
    const ids: string[] = [];
    const seen = new Set<string>();
    for (const ws of workspaces) {
      for (const p of ws.panes) {
        if (!p.tty) continue;
        if (!seen.has(p.tty)) {
          seen.add(p.tty);
          ids.push(p.tty);
        }
      }
    }
    return ids;
  }, [workspaces]);

  // Active workspace's own panes — rendered side-by-side in split view mode.
  const activeWsSessionIds = useMemo(() => {
    const ids: string[] = [];
    for (const p of activeWs?.panes ?? []) {
      if (p.tty) ids.push(p.tty);
    }
    return ids;
  }, [activeWs]);

  // ── Persistent terminal host (shared pane pool) ────────────────────────
  // TerminalHost (always mounted in <main>) renders ONE <TerminalPane> per
  // session and keeps it mounted across EVERY view/panel switch, so xterm
  // instances and their scrollback survive leaving and re-entering the
  // workspace / grid / cards / kanban / memory / ceo views.
  const terminalSessionIds = useMemo(
    () =>
      Array.from(
        new Set([
          ...allWorkspaceSessionIds,
          ...(focusedTerminal ? [focusedTerminal] : []),
          // Dedicated IDE terminal (independent of workspace panes)
          ...(ideTerminalSessionId ? [ideTerminalSessionId] : []),
        ]),
      ),
    [
      allWorkspaceSessionIds,
      focusedTerminal,
      ideTerminalReady /* re-compute when IDE terminal created */,
    ],
  );

  // Per-session visible/focused/paneId for the CURRENT view. PaneId drives
  // TUI auto-expand routing only — the xterm instance is keyed by sessionId
  // and never remounts when this changes (TerminalPane reads it via a ref).
  const terminalSessionStates = useMemo(() => {
    const states: Record<string, { paneId: string; visible: boolean; focused: boolean }> = {};
    const set = (sid: string, paneId: string, visible: boolean, focused: boolean) => {
      states[sid] = { paneId, visible, focused };
    };
    if (view === 'workspace') {
      // FOCUS mode: only the focused terminal is visible (others parked).
      // SPLIT mode: every ACTIVE workspace pane is visible side-by-side.
      const split = viewMode === 'split';
      for (const ws of workspaces) {
        const isActiveWs = ws.id === activeId;
        for (const pane of ws.panes) {
          if (!pane.tty) continue;
          const focused = pane.tty === focusedTerminal;
          const visible = split ? isActiveWs || focused : focused;
          set(pane.tty, `workspace-${pane.tty}`, visible, focused);
        }
      }
      if (focusedTerminal && !states[focusedTerminal]) {
        set(focusedTerminal, `workspace-${focusedTerminal}`, true, true);
      }
    } else if (view === 'grid') {
      // Every pane cell is anchored; only the ACTIVE workspace's cells are on
      // screen (the rest are parked offscreen by the ws-grid containers).
      for (const ws of workspaces) {
        const isActiveWs = ws.id === activeId;
        for (const pane of ws.panes) {
          if (!pane.tty) continue;
          set(
            pane.tty,
            pane.id,
            isActiveWs,
            isActiveWs && (expandedPane === pane.id || selectedPane === pane.id),
          );
        }
      }
    } else {
      // cards / kanban / memory / ceo / ide / wizard: nothing visible.
      for (const sid of allWorkspaceSessionIds) set(sid, `workspace-${sid}`, false, false);
    }
    // Keep focused-but-unpinned sessions mounted (parked) so a control-panel
    // selection never disposes their xterm either.
    if (focusedTerminal && !states[focusedTerminal]) {
      set(focusedTerminal, `workspace-${focusedTerminal}`, false, false);
    }
    // Dedicated IDE terminal — always parked at app level; the IDEView's
    // own <TerminalAnchor> handles the visible slot.
    if (ideTerminalSessionId) {
      set(ideTerminalSessionId, `ide-${ideTerminalSessionId}`, false, false);
    }
    return states;
  }, [
    view,
    viewMode,
    workspaces,
    activeId,
    expandedPane,
    selectedPane,
    focusedTerminal,
    allWorkspaceSessionIds,
    ideTerminalReady,
  ]);

  const tcmAttachSessions = isTauri()
    ? nativeSessions.map((s) => ({ id: s.id, label: `${s.id}${s.title ? ` · ${s.title}` : ''}` }))
    : list.map((tty) => ({
        id: tty,
        label: `${tty}${unifiedTerminals[tty].agent ? ` · ${unifiedTerminals[tty].agent}` : ''}`,
      }));

  // ── Remote task delivery watcher ─────────────────────────────────────
  const deliveredTasksRef = useRef<Set<string>>(new Set());
  const deliveryAttemptsRef = useRef<Map<string, number>>(new Map());
  const appliedModelRef = useRef<Map<string, string>>(new Map());
  const failedModelsRef = useRef<Set<string>>(new Set());
  const recentSessionsRef = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    if (!isTauri() || !startupReady) return;
    for (const entry of Object.values(unifiedTerminals)) {
      const u = entry as UnifiedTerminal;
      const sid = u.session_id;
      const ct = u.current_task;
      if (!sid || sid === entry.tty || !ct || ct.status !== 'running') continue;
      const key = `${sid}:${ct.id}`;
      if (deliveredTasksRef.current.has(key)) continue;
      deliveredTasksRef.current.add(key);
      const taskModel = (ct as any).model as string | undefined;
      deliverToSession(sid, ct.description, taskModel).catch((e) => {
        console.warn(`[tto] task delivery failed on ${sid}:`, e);
        const attempts = (deliveryAttemptsRef.current.get(key) || 0) + 1;
        deliveryAttemptsRef.current.set(key, attempts);
        if (attempts < 3) deliveredTasksRef.current.delete(key);
      });
    }
    if (deliveredTasksRef.current.size > 512) deliveredTasksRef.current.clear();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unifiedTerminals, startupReady]);

  const deliverToSession = async (sid: string, description: string, model?: string) => {
    const entry = Object.values(unifiedTerminals).find(
      (u) => (u as UnifiedTerminal).session_id === sid,
    ) as UnifiedTerminal | undefined;
    const persisted = (entry as unknown as { applied_model?: string })?.applied_model || '';
    const scanned = (entry as unknown as { opencode_running?: boolean; opencode_model?: string })
      ?.opencode_running
      ? ((entry as unknown as { opencode_model?: string })?.opencode_model ?? '')
      : null;
    const alreadyApplied =
      scanned !== null ? scanned : (appliedModelRef.current.get(sid) ?? persisted);
    // Never /exit a session the wizard just created — the fresh CLI was
    // launched intentionally; swapping models seconds later kills it.
    const bornAt = recentSessionsRef.current.get(sid) || 0;
    const sessionJustCreated = bornAt > 0 && Date.now() - bornAt < 15000;
    if (
      model &&
      alreadyApplied !== model &&
      !failedModelsRef.current.has(`${sid}:${model}`) &&
      !sessionJustCreated
    ) {
      const e = entry as unknown as { opencode_running?: boolean; opencode_pid?: number };
      const opencodeRunning = !!e?.opencode_running;
      const oldPid = e?.opencode_pid || 0;
      if (opencodeRunning) {
        await tauri.sendCommand(sid, '/exit');
        await new Promise((r) => setTimeout(r, 4000));
        await tauri.sendCommand(sid, `opencode -m ${model}`);
      } else {
        await tauri.sendCommand(sid, `opencode -m ${model}`);
      }
      let booted = await waitForOpencodeBoot(entry?.tty || '', oldPid, 30000);
      if (!booted) {
        failedModelsRef.current.add(`${sid}:${model}`);
        console.warn(`[tto] model ${model} failed to launch on ${sid} — restoring bare opencode`);
        await tauri.sendCommand(sid, 'opencode');
        booted = await waitForOpencodeBoot(entry?.tty || '', oldPid, 20000);
      } else {
        await new Promise((r) => setTimeout(r, 1500));
        appliedModelRef.current.set(sid, model);
        if (entry?.tty) {
          void setTerminalAppliedModel(entry.tty, model);
        }
      }
      if (!booted) {
        throw new Error(`opencode unavailable on ${entry?.tty || sid}`);
      }
    }
    await tauri.sendCommand(sid, description);
  };

  // Workspace stats
  const stats = useMemo(() => {
    let live = 0;
    let closed = 0;
    let active = 0;
    let done = 0;
    let agents = 0;
    for (const t of Object.values(unifiedTerminals)) {
      if (t.is_live !== false && !(t.agent || '').includes('closed')) live++;
      else closed++;
      if (
        t.current_task &&
        (t.current_task.status === 'running' || t.current_task.status === 'pending')
      )
        active++;
      if (t.current_task && t.current_task.status === 'done') done++;
      if (t.agent) agents++;
    }
    return { live, closed, active, done, agents };
  }, [unifiedTerminals]);

  const openWizard = () => setView('wizard');

  const handleWizardCreate = async (config: WizardConfig) => {
    const name = config.projectPath ? baseName(config.projectPath) || 'Workspace' : undefined;
    const ws = newWorkspace(name, (config.template || 4) as TemplateKey);
    ws.projectPath = config.projectPath || undefined;
    ws.command = config.command || undefined;
    setWorkspaces((w) => [...w, ws]);
    setActiveId(ws.id);

    if (isTauri()) {
      const created: string[] = [];
      for (const pane of ws.panes) {
        try {
          const meta = await tauri.create(
            ws.projectPath || undefined,
            ws.id,
            INITIAL_TERMINAL_COLS,
            INITIAL_TERMINAL_ROWS,
          );
          assignPane(ws.id, pane.id, meta.id);
          created.push(meta.id);
        } catch (e) {
          console.warn(`[tto] terminal_create failed for pane ${pane.id}:`, e);
          /* pane stays empty */
        }
      }
      if (created.length > 0) {
        tauri.indexSet(ws.id, created).catch(() => {});
        // Wait for shells to reach a prompt before typing — scaled with session
        // count because each terminal_create is serialized on the Rust main thread
        // (includes a `ps` subprocess per session).
        await new Promise((r) => setTimeout(r, Math.min(1500, 500 + created.length * 120)));
        if (config.command) {
          // ── Pre-resize PTY to match the expected card dimensions ──────
          // CLIs (opencode, kilo…) read TIOCGWINSZ at launch and draw their
          // layout at that size. If the PTY is still at the generous initial
          // size (120×40) when the CLI starts, it draws a 120-col TUI that
          // gets garbled when the fit watcher resizes the card to its actual
          // smaller dimensions. We compute the expected card size from the
          // same grid math the CSS grid uses and resize the PTY BEFORE
          // launching the CLI, so it starts with the correct dimensions.
          const mode = ws.layoutMode ?? 'auto';
          const { minW, minH } = gridMins(mode);
          // Container width: the .container element is inside .main-area
          // (which already excludes the sidebar), so containerSize.w is the
          // correct width. When the container hasn't mounted yet (first render),
          // fall back to window.innerWidth minus sidebar and padding.
          const SIDEBAR_W = 220;
          const PADDING_PX = 16;
          const rawW =
            containerSize.w > 0
              ? containerSize.w
              : window.innerWidth - (sidebarOpen ? SIDEBAR_W : 0);
          const contW = Math.max(400, rawW - PADDING_PX);
          // Container height: subtract header (36px), workspace bar (40px),
          // status bar (28px), stats bar (24px), padding (8px×2).
          // Pane header height varies by mode (see styles.css data-grid-mode).
          const HEADER_H = 36;
          const WSBAR_H = 40;
          const STATUS_H = 28;
          const STATS_H = 24;
          const PANE_HEAD_H =
            mode === 'grid' ? 26 : mode === 'compact' ? 28 : mode === 'large' ? 36 : 32;
          const contH = Math.max(
            200,
            (containerSize.h > 0 ? containerSize.h : window.innerHeight) -
              HEADER_H -
              WSBAR_H -
              STATUS_H -
              STATS_H -
              PADDING_PX,
          );
          const layout = computeResponsiveLayout({
            count: ws.panes.length,
            width: contW,
            mode,
            gap: GRID_GAP,
            maxColumns: ws.maxColumns,
            templateCols: templateCols(ws.template),
          });
          // Compute per-pane pixel dimensions (same formula the CSS grid uses
          // with minmax(minW, 1fr) × minmax(minH, 1fr)).
          const paneW = Math.max(
            minW,
            Math.floor((contW - (layout.cols - 1) * GRID_GAP) / layout.cols),
          );
          const paneH = Math.max(
            minH,
            Math.floor((contH - (layout.rows - 1) * GRID_GAP) / layout.rows),
          );
          // Reserve pane header height (varies by mode).
          const termH = Math.max(60, paneH - PANE_HEAD_H);
          // Terminal font: 11px default, 1.25 line height.
          const TERM_FONT = 11;
          const LINE_H = 1.25;
          const cellW = TERM_FONT * 0.6; // ~6.6px per char
          const cellH = TERM_FONT * LINE_H; // ~13.75px per row
          const termCols = Math.max(40, Math.round(paneW / cellW));
          const termRows = Math.max(10, Math.round(termH / cellH));
          console.log(
            `[tto] pre-resize: mode=${mode} pane=${paneW}×${paneH} term=${termCols}×${termRows} (from ${contW}×${contH} container, ${layout.cols}×${layout.rows} grid)`,
          );
          // Stagger launches to avoid N CLIs (e.g. opencode) contending on shared
          // per-project state and exiting at boot. Before each launch, resize
          // the PTY so the CLI reads the correct size from TIOCGWINSZ.
          let i = 0;
          for (const sid of created) {
            try {
              // Resize the PTY to the expected card dimensions.
              await tauri.resize(sid, termCols, termRows);
              // Brief settle: let xterm.js refit to the new PTY size.
              await new Promise((r) => setTimeout(r, 120));
              await tauri.sendCommand(sid, normalizeClaudeFresh(config.command));
              recentSessionsRef.current.set(sid, Date.now());
            } catch (e) {
              console.warn(`[tto] launch command failed on ${sid}:`, e);
            }
            if (++i < created.length) await new Promise((r) => setTimeout(r, 200));
          }
        }
      }
      // Auto-focus the first terminal
      if (created.length > 0) setFocusedTerminal(created[0]);
    } else {
      // Web fallback: bind panes to live sidecar terminals, skipping stale
      // ttys the sidecar may still list but can no longer launch into.
      const ttys = list.filter((t) => !isClosed(unifiedTerminals[t]));
      ws.panes.forEach((p, i) => {
        if (ttys[i]) assignPane(ws.id, p.id, ttys[i]);
      });
      const launchWithLog = (tty: string, cmd: string) =>
        launchCli(tty, cmd).catch((e) => console.warn(`[tto] web launch failed on ${tty}:`, e));
      if (ws.projectPath) {
        for (const tty of ttys) {
          launchWithLog(tty, `cd ${JSON.stringify(ws.projectPath)} && clear`);
          await new Promise((r) => setTimeout(r, 150));
        }
      }
      if (config.command) {
        // Stagger CLI launches — same contention as the Tauri path.
        await new Promise((r) => setTimeout(r, 300));
        let wi = 0;
        for (const tty of ttys) {
          launchWithLog(tty, config.command);
          if (++wi < ttys.length) await new Promise((r) => setTimeout(r, 200));
        }
      }
      if (ttys.length > 0) setFocusedTerminal(ttys[0]);
    }

    setView('grid');
    showToast(
      `Workspace "${ws.name}" ready (${ws.template} terminals)` +
        (config.command ? ` · launching ${config.command}` : ''),
    );
  };

  const closeWorkspace = (id: string) => {
    setWorkspaces((w) => {
      const next = w.filter((x) => x.id !== id);
      if (next.length === 0) {
        const fresh = newWorkspace();
        setActiveId(fresh.id);
        return [fresh];
      }
      if (id === activeId) setActiveId(next[0].id);
      return next;
    });
  };

  const setTemplate = (ws: Workspace, tpl: TemplateKey) => {
    setWorkspaces((all) =>
      all.map((w) => {
        if (w.id !== ws.id) return w;
        const panes = Array.from(
          { length: tpl },
          (_, i) => w.panes[i] ?? { id: `p-${w.id}-${i}`, tty: null },
        );
        const cols = templateCols(tpl);
        const rows = Math.max(1, Math.ceil(tpl / cols));
        return {
          ...w,
          template: tpl,
          panes,
          trackCols: Array.from({ length: cols }, () => 1),
          trackRows: Array.from({ length: rows }, () => 1),
        };
      }),
    );
  };

  const assignPane = useCallback((wsId: string, paneId: string, tty: string | null) => {
    setWorkspaces((all) =>
      all.map((w) =>
        w.id === wsId
          ? { ...w, panes: w.panes.map((p) => (p.id === paneId ? { ...p, tty } : p)) }
          : w,
      ),
    );
  }, []);

  // Guard: detect and clear duplicate sessionIds across panes. If two panes
  // share a sessionId they compete for the same slot/anchor and the last-to-
  // register anchor wins, leaving other cards empty or showing stale content
  // from the shared xterm instance.
  useEffect(() => {
    const seen = new Set<string>();
    const duplicates: Array<{ wsId: string; paneId: string }> = [];
    for (const ws of workspaces) {
      for (const p of ws.panes) {
        if (!p.tty) continue;
        if (seen.has(p.tty)) {
          duplicates.push({ wsId: ws.id, paneId: p.id });
        } else {
          seen.add(p.tty);
        }
      }
    }
    for (const dup of duplicates) {
      console.warn(
        `[tto] DUPLICATE sessionId in pane ${dup.paneId} (ws ${dup.wsId}) — clearing to force re-creation`,
      );
      assignPane(dup.wsId, dup.paneId, null);
    }
  }, [workspaces, assignPane]);

  const openInPane = async (wsId: string, paneId: string) => {
    try {
      const ws = workspaces.find((w) => w.id === wsId);
      const meta = await tauri.create(
        ws?.projectPath || undefined,
        wsId,
        INITIAL_TERMINAL_COLS,
        INITIAL_TERMINAL_ROWS,
      );
      assignPane(wsId, paneId, meta.id);
      if (ws?.projectPath) {
        await new Promise((r) => setTimeout(r, 400));
        tauri.sendCommand(meta.id, `cd ${JSON.stringify(ws.projectPath)}`).catch(() => {});
      }
      setFocusedTerminal(meta.id);
      if (view === 'grid') setSelectedPane(paneId);
      else setView('workspace');
      showToast('Terminal ready');
    } catch {
      showToast('Failed to open terminal', true);
    }
  };

  const attachInPane = async (wsId: string, paneId: string, sessionId: string) => {
    try {
      assignPane(wsId, paneId, sessionId);
      setFocusedTerminal(sessionId);
      if (view === 'grid') setSelectedPane(paneId);
      else setView('workspace');
      showToast(`Attached to ${sessionId}`);
    } catch {
      showToast('Failed to attach', true);
    }
  };

  /** Quick-launch: create terminals ONLY in EMPTY panes of the ACTIVE workspace.
   *  Never touches existing terminals. Shows error if not enough empty panes. */
  const handleQuickLaunch = useCallback(
    async (clickedPaneId: string) => {
      if (!activeWs) {
        showToast('No active workspace', true);
        return;
      }
      const path = quickLaunchPath.trim();
      const cmd = quickLaunchCmd.trim();
      const count = Math.max(1, Math.min(16, quickLaunchCount));
      if (!path) {
        showToast('Enter a project path', true);
        return;
      }

      // Find ALL empty panes (tty === null) — never touch occupied ones.
      const emptyPanes = activeWs.panes.filter((p) => !p.tty);
      if (emptyPanes.length === 0) {
        showToast(
          'All panes are occupied — close some terminals first or increase template size',
          true,
        );
        setQuickLaunchPane(null);
        return;
      }
      if (count > emptyPanes.length) {
        showToast(
          `Only ${emptyPanes.length} empty pane(s) available — cannot launch ${count} terminals. Close some terminals or reduce the count.`,
          true,
        );
        setQuickLaunchPane(null);
        return;
      }

      // Build target list: clicked pane first, then remaining empty panes.
      const clickedPane = emptyPanes.find((p) => p.id === clickedPaneId);
      const otherEmpty = emptyPanes.filter((p) => p.id !== clickedPaneId);
      const targetPanes = clickedPane
        ? [clickedPane, ...otherEmpty.slice(0, count - 1)]
        : emptyPanes.slice(0, count);

      showToast(`Creating ${count} terminal${count > 1 ? 's' : ''}…`);

      let createdCount = 0;
      if (isTauri()) {
        const created: string[] = [];
        for (const tp of targetPanes) {
          try {
            const meta = await tauri.create(
              path,
              activeWs.id,
              INITIAL_TERMINAL_COLS,
              INITIAL_TERMINAL_ROWS,
            );
            assignPane(activeWs.id, tp.id, meta.id);
            created.push(meta.id);
          } catch (e) {
            console.warn(`[tto] quick-launch create failed:`, e);
          }
        }
        if (created.length > 0) {
          createdCount = created.length;
          tauri.indexSet(activeWs.id, created).catch(() => {});
          await new Promise((r) => setTimeout(r, Math.min(1500, 500 + created.length * 120)));
          if (cmd) {
            let i = 0;
            for (const sid of created) {
              try {
                // Guarantee Claude Code launches fresh (strips resume) — native
                // Rust PTY path bypasses the backend normalizer.
                await tauri.sendCommand(sid, normalizeClaudeFresh(cmd));
                recentSessionsRef.current.set(sid, Date.now());
              } catch (e) {
                console.warn(`[tto] quick-launch command failed:`, e);
              }
              if (++i < created.length) await new Promise((r) => setTimeout(r, 200));
            }
          }
          setFocusedTerminal(created[0]);
        }
      }

      setQuickLaunchPane(null);
      setQuickLaunchPath('');
      const wsName = activeWs.name;
      showToast(
        createdCount > 0
          ? `Workspace "${wsName}" — ${createdCount} terminal${createdCount > 1 ? 's' : ''} ready` +
              (cmd ? ` · ${cmd}` : '')
          : `Failed to create terminals`,
        createdCount === 0,
      );
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [activeWs, quickLaunchPath, quickLaunchCmd, quickLaunchCount, assignPane, showToast],
  );

  const handleNewTerminal = useCallback(async () => {
    if (view === 'wizard') {
      setView('workspace');
      return;
    }
    if (activeWs) {
      try {
        const meta = await tauri.create(
          activeWs.projectPath || undefined,
          activeWs.id,
          INITIAL_TERMINAL_COLS,
          INITIAL_TERMINAL_ROWS,
        );
        const emptyPane = activeWs.panes.find((p) => !p.tty);
        if (emptyPane) {
          assignPane(activeWs.id, emptyPane.id, meta.id);
          // Keep the newly-created terminal visible in both layouts:
          // - Workspace view uses focusedTerminal for visibility.
          // - Grid view needs selectedPane or expandedPane to not park it offscreen.
          setFocusedTerminal(meta.id);
          if (view === 'grid') setSelectedPane(emptyPane.id);
          else setView('workspace');
        } else {
          showToast('All panes full — close one first or increase template size');
        }
        if (activeWs.projectPath && emptyPane) {
          await new Promise((r) => setTimeout(r, 400));
          tauri.sendCommand(meta.id, `cd ${JSON.stringify(activeWs.projectPath)}`).catch(() => {});
        }
        if (emptyPane) showToast('Terminal ready');
      } catch {
        showToast('Failed to create terminal', true);
      }
    } else {
      showToast('Open a workspace first', true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, activeWs, assignPane, showToast]);

  const handlePaneRestart = useCallback(
    async (id: string) => {
      await tauri.restart(id);
      showToast('Terminal restarted');
    },
    [showToast],
  );

  const handlePaneKill = useCallback(
    async (id: string) => {
      await tauri.close(id);
      setWorkspaces((all) =>
        all.map((w) => ({
          ...w,
          panes: w.panes.map((p) => (p.tty === id ? { ...p, tty: null } : p)),
        })),
      );
      // If the killed terminal was focused, focus another
      if (focusedTerminal === id) {
        const ws = workspaces.find((w) => w.panes.some((p) => p.tty === id));
        if (ws) {
          const next = ws.panes.find((p) => p.tty && p.tty !== id);
          setFocusedTerminal(next?.tty || null);
        } else {
          setFocusedTerminal(null);
        }
      }
      // Clear selection/expansion if the killed terminal was the active pane
      const killedPane = workspaces.flatMap((w) => w.panes).find((p) => p.tty === id);
      if (killedPane) {
        if (selectedPane === killedPane.id) setSelectedPane(null);
        if (expandedPane === killedPane.id) setExpandedPane(null);
      }
      showToast('Terminal killed');
    },
    [showToast, focusedTerminal, workspaces, selectedPane, expandedPane],
  );

  const handleSendToTerminal = useCallback(
    async (tty: string, filePath: string) => {
      try {
        if (isTauri()) {
          // In Tauri mode: `tty` from the IDE panel is actually the pane's tty
          // field, which is the Rust session id (e.g. "terminal-1").
          // Resolve to the real session id: check unifiedTerminals first, then
          // treat the value itself as a session id (panes store session ids).
          const entry = unifiedTerminals[tty];
          const sid = entry?.session_id || tty;
          // Type the file path into the terminal character-by-character
          // so the user can see it and press Enter themselves.
          // Using write() (not sendCommand) avoids auto-executing in TUIs.
          const text = `cat '${filePath.replace(/'/g, "'\\''")}'`;
          const encoder = new TextEncoder();
          await tauri.write(sid, encoder.encode(text));
          showToast(`File path typed in terminal — press Enter to run`);
        } else {
          const res = await fetch(`${apiBase()}/api/terminals/${tty}/send-file`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ file_path: filePath }),
          });
          if (!res.ok) throw new Error('Failed');
          showToast(`File sent to terminal`);
        }
      } catch {
        showToast('Failed to send file to terminal', true);
      }
    },
    [isTauri, tauri, unifiedTerminals, apiBase, showToast],
  );

  /** Handle files dragged into a terminal pane — shell-escapes paths and injects them into the PTY. */
  const handleDrop = useCallback(
    async (sessionId: string, paths: string[], kinds?: ('file' | 'folder')[]) => {
      if (!isTauri() || paths.length === 0) return;
      // Exactly-once guard: multiple drop layers route into this single
      // chokepoint; swallow the redundant ones (same target + same paths
      // within a 300ms window). Keeps image preview single-fire too.
      const now = Date.now();
      const key = `${sessionId || ''}\u0000${paths.join('\u0000')}`;
      if (key === lastDropKey && now - lastDropMs < DROP_DEDUPE_WINDOW_MS) return;
      lastDropKey = key;
      lastDropMs = now;
      // Resolve ALL candidate live terminals, in priority order:
      //   1. the session the drop landed on,
      //   2. the focused terminal,
      //   3. every pane across all workspaces,
      //   4. every native (Rust) session,
      //   5. every known unifiedTerminals entry.
      // We then type into the first one whose session actually accepts the
      // write — so a dead/mismatched pane can no longer silently eat the drop.
      const candidates: string[] = [];
      const push = (id: string | null | undefined) => {
        if (id && !candidates.includes(id)) candidates.push(id);
      };
      push(sessionId);
      push(focusedTerminal);
      for (const ws of workspaces) {
        for (const p of ws.panes || []) push(p.tty);
      }
      for (const s of nativeSessions) push(s.id);
      for (const tty of Object.keys(unifiedTerminals)) push(tty);
      // Keep only sessions that look alive.
      const live = candidates.filter((c) => {
        const entry = unifiedTerminals[c];
        if (entry && entry.rust_status)
          return entry.rust_status !== 'exited' && entry.rust_status !== 'killed';
        if (entry) return true; // frontend-managed terminal without a rust_status yet
        return !!nativeSessions.find((s) => s.id === c && s.status === 'running');
      });
      const paneCount = workspaces.reduce((n, w) => n + w.panes.length, 0);
      if (live.length === 0) {
        showToast(
          `No terminal to receive the drop (live: ${nativeSessions.length}, panes: ${paneCount})`,
          true,
        );
        console.warn(
          '[drop] no live candidate. nativeSessions=',
          nativeSessions,
          'unified=',
          Object.keys(unifiedTerminals),
        );
        return;
      }
      for (const cand of live) {
        const entry = unifiedTerminals[cand];
        const realId = entry?.session_id || cand;
        try {
          await tauri.dropFiles(realId, paths);
          showToast(`File path dropped into terminal — press Enter to run`);
          // ── Attached-file chip: ChatGPT-style pill above this terminal ──
          const firstPath = paths[0] || '';
          const name = baseName(firstPath);
          const kind = kinds?.[0] ?? 'file';
          const entry =
            unifiedTerminals[realId] ||
            Object.values(unifiedTerminals).find((u) => u.session_id === realId);
          const terminalLabel = entry?.agent || entry?.session_name || realId;
          const chipId = Date.now();
          console.info(
            `[chip] attached ${kind} "${name}" → ${realId} (${terminalLabel || 'no-label'})`,
          );
          setDropChips((prev) => {
            const existing = prev[realId] || [];
            const next = [
              ...existing,
              { id: chipId, kind, name, fullPath: firstPath, terminalId: realId, terminalLabel },
            ];
            return { ...prev, [realId]: next.slice(-8) };
          });
          // Auto-remove this chip after 90s (chatgpt-style cleanup timer).
          window.setTimeout(() => {
            setDropChips((prev) => {
              const cur = prev[realId];
              if (!cur) return prev;
              return { ...prev, [realId]: cur.filter((c) => c.id !== chipId) };
            });
          }, 90_000);
          // Check if any dropped file is an image → show preview
          for (const p of paths) {
            const ext = p.split('.').pop()?.toLowerCase() || '';
            if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'bmp', 'avif'].includes(ext)) {
              setImagePreview(p);
              break;
            }
          }
          return;
        } catch (e: unknown) {
          console.warn(`[drop] candidate ${cand} (real ${realId}) rejected:`, e);
        }
      }
      showToast(`Failed to drop file into terminal — no live session accepted the write`, true);
    },
    [unifiedTerminals, workspaces, activeId, focusedTerminal, nativeSessions, showToast],
  );

  // ── Image preview state (shown when image files are dropped on terminal) ──
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // ── Window-level drop fallback + Tauri native drag-drop ────────────────
  // When dragging from the sidebar, the drop event may not reach the terminal
  // pane because xterm.js canvas intercepts it. This window-level listener
  // catches any file drops that weren't handled by a terminal pane and routes
  // them to the focused terminal.
  //
  // Tauri v2's native drag-drop handler intercepts OS file drops before the
  // HTML5 dataTransfer.files API can see them (dt.files is empty). Tauri emits
  // a `tauri://drag-drop` event with the actual file paths — we listen for that
  // here and route to the focused terminal. The DOM fallback handles sidebar
  // drags (text/plain) and non-Tauri web environments.
  useEffect(() => {
    let dropHandled = false;
    const onWinDragOver = (e: DragEvent) => {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    };
    const onWinDrop = (e: DragEvent) => {
      if (dropHandled) {
        dropHandled = false;
        return;
      }
      const dt = e.dataTransfer;
      if (!dt) return;
      // If the drop landed on the command-line input (workspace focus bar),
      // let TerminalInput's own handler paste the path into the line instead of
      // auto-executing it into the PTY here.
      // If the drop landed on a terminal input, terminal pane, or workspace container,
      // let their own specific element handlers route the drop to the exact targeted pane
      // instead of using window-level fallback routing.
      const targetEl = e.target as Element | null;
      if (
        targetEl &&
        targetEl.closest &&
        (targetEl.closest('.ws-input') ||
          targetEl.closest('.term-pane') ||
          targetEl.closest('.terminal-workspace'))
      ) {
        return;
      }
      // Get file paths from OS drag
      const files = Array.from(dt.files);
      const filePaths = files.map((f: any) => f.path || f.name).filter(Boolean);
      // Get file path from sidebar drag (text/plain)
      const textPath = dt.getData('text/plain') || dt.getData('application/x-tto-file');
      const paths = filePaths.length > 0 ? filePaths : textPath ? [textPath] : [];
      if (paths.length === 0) return;
      e.preventDefault();
      // Route to the focused terminal (fallback resolves inside handleDrop)
      const target = focusedTerminal || '';
      {
        handleDrop(target, paths);
        showToast(`Dropped ${paths.length} file(s) into terminal`);
      }
    };
    // Capture phase so we fire before default browser behavior
    window.addEventListener('dragover', onWinDragOver, { capture: true });
    window.addEventListener('drop', onWinDrop, { capture: true });

    // Tauri native drag-drop: OS file drops are intercepted by Tauri's native
    // handler before HTML5 dataTransfer.files populates. The tto://drag-drop
    // event carries the real paths in its payload.paths array.
    let unlisten: (() => void) | null = null;
    if (isTauri()) {
      listenEvent<{ paths: string[] }>('tto://drag-drop', (data) => {
        console.log('[TTO DRAG JS] tto://drag-drop event received:', data);
        const paths = data?.paths || [];
        if (paths.length === 0) return;
        dropHandled = true;
        // If the cursor is over the command line (TerminalInput) swap-events
        // flag this, route the OS drop INTO the focused command line so the
        // user can review/modify the path before pressing Enter — do NOT
        // auto-execute it into the PTY.
        const overInput = typeof window !== 'undefined' && !!window.__tto_dragOverTerminalInput;
        console.log(
          '[TTO DRAG JS] overInput flag:',
          overInput,
          '__tto_insertIntoTerminalInput:',
          typeof window.__tto_insertIntoTerminalInput,
        );
        if (overInput && typeof window !== 'undefined' && window.__tto_insertIntoTerminalInput) {
          window.__tto_insertIntoTerminalInput(paths);
          showToast(`Dropped ${paths.length} file(s) into command line`);
          return;
        }
        const target = focusedTerminal;
        if (target) {
          handleDrop(target, paths);
          showToast(`Dropped ${paths.length} file(s) into ${target}`);
        }
      })
        .then((fn) => {
          unlisten = fn;
        })
        .catch(() => {});
    }

    return () => {
      window.removeEventListener('dragover', onWinDragOver, { capture: true });
      window.removeEventListener('drop', onWinDrop, { capture: true });
      if (unlisten) unlisten();
    };
  }, [focusedTerminal, handleDrop, showToast]);

  /** Send a raw command string from the IDE panel to a terminal. */
  const handleSendCommand = useCallback(
    async (tty: string, command: string) => {
      try {
        if (isTauri()) {
          const entry = unifiedTerminals[tty];
          const sid = entry?.session_id || tty;
          // Type the command + newline so it executes immediately.
          // Guarantee Claude Code launches a fresh session (strip resume) — the
          // native Rust PTY path bypasses the backend normalizer.
          const normalized = normalizeClaudeFresh(command);
          const encoder = new TextEncoder();
          await tauri.write(sid, encoder.encode(normalized + '\n'));
          showToast(`Command sent to ${tty}`);
        } else {
          const res = await fetch(`${apiBase()}/api/terminals/${tty}/command`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command: command + '\n' }),
          });
          if (!res.ok) throw new Error('Failed');
          showToast(`Command sent to ${tty}`);
        }
      } catch {
        showToast('Failed to send command', true);
      }
    },
    [isTauri, tauri, unifiedTerminals, apiBase, showToast],
  );

  /**
   * Guarantee a live, dedicated IDE terminal exists — INDEPENDENT of any
   * workspace pane.  The session is tagged 'ide' (not a real workspace id)
   * so Rust never indexes it into a workspace, and we never call assignPane.
   */
  const ensureIdeTerminal = useCallback(async (): Promise<string | null> => {
    if (!isTauri()) return null; // web mode: no dedicated terminal yet

    // Fast path: module-level id still alive in Rust?
    if (ideTerminalSessionId) {
      const alive = nativeSessions.some((s) => s.id === ideTerminalSessionId);
      if (alive) return ideTerminalSessionId;
      // Stale — session was killed externally
      ideTerminalSessionId = null;
    }

    // In-flight guard: if a create is already underway (StrictMode double
    // invoke, or an effect/command race), skip — the in-flight create will
    // set ideTerminalSessionId and bump ideTerminalReady, which re-runs this.
    if (ideTerminalCreating) return ideTerminalSessionId;

    ideTerminalCreating = true;
    try {
      const meta = await tauri.create(
        activeWs?.projectPath || undefined,
        'ide', // tag — NOT a real workspace id
        INITIAL_TERMINAL_COLS,
        INITIAL_TERMINAL_ROWS,
      );
      ideTerminalSessionId = meta.id;
      ideTerminalCreating = false;
      setIdeTerminalReady((v) => !v); // trigger re-render so TerminalHost mounts it

      // cd into the project path once the shell prompt is ready
      const projectPath = activeWs?.projectPath;
      if (projectPath) {
        setTimeout(() => {
          tauri.sendCommand(meta.id, `cd ${JSON.stringify(projectPath)}`).catch(() => {});
        }, 400);
      }
      return meta.id;
    } catch {
      ideTerminalCreating = false;
      return null;
    }
  }, [activeWs, nativeSessions, isTauri, tauri]);

  /**
   * Auto-create the dedicated, independent IDE terminal the moment the IDE
   * view opens — so the IDE's bottom terminal is ready (not just after the
   * user runs a command). StrictMode-safe: skips while a create is in flight
   * and re-resolves once the session id is set and ideTerminalReady bumps.
   */
  useEffect(() => {
    if (view !== 'ide' || !startupReady || !isTauri()) return;
    if (ideTerminalSessionId) return; // already exists
    ensureIdeTerminal();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, startupReady, ideTerminalReady, ensureIdeTerminal]);

  const handleOpenFile = useCallback((path: string, name: string, lineNumber?: number) => {
    setOpenFiles((prev) => {
      if (prev.some((f) => f.path === path)) return prev;
      return [...prev, { path, name }];
    });
    // Activate the tab immediately — otherwise clicking a file in the tree /
    // search results adds a HIDDEN tab and the editor stays blank.
    setActiveFile(path);
    if (lineNumber) {
      // Store line number for gotoLine prop + bump the nonce so the editor
      // remounts and jumps even when the file was already active (re-click).
      (window as any).__tto_pending_goto_line = lineNumber;
      setGotoNonce((n) => n + 1);
    } else {
      (window as any).__tto_pending_goto_line = null;
    }
  }, []);

  /** Open a file from a terminal file-path link (shared by the pane pool). */
  const handleTerminalLinkClick = useCallback(
    (target: string, lineNumber?: number, isUrl?: boolean) => {
      // Handle HTTP/HTTPS URLs - open in embedded browser tab
      if (isUrl || target.startsWith('http://') || target.startsWith('https://')) {
        // Call externalNavigate (Tauri command to open in embedded browser)
        if (isTauri()) {
          (window as any).__tto_external_navigate?.(target);
        }
        showToast(`Opening ${target} in browser`);
        return;
      }
      // Handle file paths - existing behavior
      const fileName = target.split('/').pop() || target;
      handleOpenFile(target, fileName, lineNumber);
      if (lineNumber) showToast(`Opening ${fileName}${lineNumber ? `:${lineNumber}` : ''}`);
    },
    [handleOpenFile, showToast],
  );

  /**
   * Close an open file. Confirms before discarding unsaved (dirty) edits, then
   * activates the NEIGHBOUR tab (the one next to the closed tab) instead of the
   * first remaining one.
   */
  const closeFile = useCallback(
    (path: string) => {
      const file = openFiles.find((f) => f.path === path);
      if (file?.dirty && !window.confirm(`Discard unsaved changes in ${file.name}?`)) return false;
      if (file?.dirty) markDiscardOnClose(path); // confirmed discard — no unmount flush
      const idx = openFiles.findIndex((f) => f.path === path);
      const next = openFiles.filter((f) => f.path !== path);
      const neighbor = next[Math.min(idx, next.length - 1)] ?? null;
      setOpenFiles((prev) => prev.filter((f) => f.path !== path));
      setActiveFile((prev) => (prev === path ? (neighbor ? neighbor.path : null) : prev));
      return true;
    },
    [openFiles],
  );

  /** Recursively fetch all files up to depth 4 for command palette search. */
  async function loadAllFiles(path: string, depth: number, maxDepth: number): Promise<FileEntry[]> {
    try {
      const result = await listFiles(path);
      const entries = (result.files || []).map((f) => ({
        ...f,
        path: path ? `${path}/${f.name}` : f.name,
        size: f.size ?? null,
        mtime: f.mtime ?? 0,
      }));
      if (depth >= maxDepth) return entries;
      const dirs = entries.filter((e) => e.is_dir);
      const rest = entries.filter((e) => !e.is_dir);
      const subEntries = await Promise.all(
        dirs.slice(0, 20).map((d) => loadAllFiles(d.path, depth + 1, maxDepth)),
      );
      return [...rest, ...subEntries.flat()];
    } catch {
      return [];
    }
  }

  // ── Grid view: layout + expand/restore/drag logic ──────────────────────
  const layoutFor = (ws: Workspace) =>
    computeResponsiveLayout({
      count: ws.panes.length,
      width: containerSize.w,
      mode: ws.layoutMode ?? 'auto',
      gap: GRID_GAP,
      maxColumns: ws.maxColumns,
      templateCols: templateCols(ws.template),
    });

  const tracksFor = (ws: Workspace) => {
    const layout = layoutFor(ws);
    const cols =
      ws.trackCols && ws.trackCols.length === layout.cols
        ? ws.trackCols
        : Array.from({ length: layout.cols }, () => 1);
    const rows =
      ws.trackRows && ws.trackRows.length === layout.rows
        ? ws.trackRows
        : Array.from({ length: layout.rows }, () => 1);
    return { cols, rows, layout };
  };

  const setTrack = (wsId: string, axis: 'col' | 'row', index: number, weight: number) => {
    const w = Math.max(0.5, Math.min(10, weight));
    setWorkspaces((all) =>
      all.map((x) => {
        if (x.id !== wsId) return x;
        const layout = layoutFor(x);
        if (axis === 'col') {
          const cols = [
            ...(x.trackCols && x.trackCols.length === layout.cols
              ? x.trackCols
              : Array.from({ length: layout.cols }, () => 1)),
          ];
          if (index >= 0 && index < cols.length) cols[index] = w;
          return { ...x, trackCols: cols };
        }
        const rows = [
          ...(x.trackRows && x.trackRows.length === layout.rows
            ? x.trackRows
            : Array.from({ length: layout.rows }, () => 1)),
        ];
        if (index >= 0 && index < rows.length) rows[index] = w;
        return { ...x, trackRows: rows };
      }),
    );
  };

  const handleTuiChange = useCallback(
    (active: boolean, paneId: string) => {
      const ws = workspaces.find((w) => w.panes.some((p) => p.id === paneId));
      if (!ws) return;
      const wsId = ws.id;
      const enabled = ws?.autoExpandTui !== false;
      const isActive = wsId === activeId;
      if (active) {
        autoExpandRef.current.add(paneId);
        if (enabled && isActive) setExpandedPane((cur) => (cur === null ? paneId : cur));
      } else {
        autoExpandRef.current.delete(paneId);
        setExpandedPane((cur) => {
          if (cur === paneId && !manualExpandRef.current.has(paneId)) return null;
          return cur;
        });
      }
    },
    [workspaces, activeId],
  );

  const toggleManualExpand = (paneId: string) => {
    setExpandedPane((cur) => {
      const next = cur === paneId ? null : paneId;
      if (next === paneId) manualExpandRef.current.add(paneId);
      else manualExpandRef.current.delete(paneId);
      return next;
    });
  };

  const EXPAND_FACTOR = 2.5;

  const selectPane = (paneId: string) => {
    setSelectedPane(paneId);
    // Keep focusedTerminal in sync so the workspace view shows the same
    // terminal the user clicked in the grid — this is the bridge between
    // the card-grid layout and the editor+terminal layout.
    const ws = workspaces.find((w) => w.panes.some((p) => p.id === paneId));
    const pane = ws?.panes.find((p) => p.id === paneId);
    if (pane?.tty) setFocusedTerminal(pane.tty);
  };

  const expandPane = (paneId: string) => {
    if (!activeWs) return;
    if (proportionalPane === paneId) return;
    const idx = activeWs.panes.findIndex((p) => p.id === paneId);
    if (idx < 0) return;
    const { cols, rows } = tracksFor(activeWs);
    const colIdx = idx % cols.length;
    const rowIdx = Math.floor(idx / cols.length);
    proportionalSnapshot.current = { cols: [...cols], rows: [...rows] };
    setProportionalPane(paneId);
    setSelectedPane(paneId);
    setTrack(activeWs.id, 'col', colIdx, (cols[colIdx] ?? 1) * EXPAND_FACTOR);
    setTrack(activeWs.id, 'row', rowIdx, (rows[rowIdx] ?? 1) * EXPAND_FACTOR);
  };

  const restorePane = (paneId: string) => {
    if (!activeWs || !proportionalSnapshot.current) return;
    const idx = activeWs.panes.findIndex((p) => p.id === paneId);
    if (idx < 0) return;
    const { cols, rows } = proportionalSnapshot.current;
    const colIdx = idx % cols.length;
    const rowIdx = Math.floor(idx / cols.length);
    setTrack(activeWs.id, 'col', colIdx, cols[colIdx] ?? 1);
    setTrack(activeWs.id, 'row', rowIdx, rows[rowIdx] ?? 1);
    proportionalSnapshot.current = null;
    setProportionalPane(null);
    setSelectedPane(paneId);
  };

  useEffect(() => {
    if (!selectedPane) return;
    const stillThere = workspaces.some((w) => w.panes.some((p) => p.id === selectedPane));
    if (!stillThere) {
      setSelectedPane(null);
      setProportionalPane(null);
      proportionalSnapshot.current = null;
    }
  }, [workspaces, selectedPane]);

  // --- Drag-to-resize ---
  const dragRef = useRef<{
    mode: 'edge' | 'corner';
    axis: 'col' | 'row';
    index: number;
    startX: number;
    startY: number;
    pairs: {
      col: { aIdx: number; bIdx: number; wA: number; wB: number };
      row: { aIdx: number; bIdx: number; wA: number; wB: number };
    };
    avails: { col: number; row: number };
  } | null>(null);
  const [dragAxis, setDragAxis] = useState<'col' | 'row' | 'corner' | null>(null);

  const clampW = (w: number) => Math.max(0.5, Math.min(10, w));

  const pairFor = (weights: number[], aIdx: number, bIdx: number) => ({
    aIdx,
    bIdx,
    wA: weights[aIdx] ?? 1,
    wB: weights[bIdx] ?? 1,
  });

  const beginDrag = (move: (e: MouseEvent) => void, end: () => void) => {
    const onMove = (e: MouseEvent) => move(e);
    const onEnd = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onEnd);
      dragRef.current = null;
      setDragAxis(null);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      end();
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onEnd);
  };

  const applyTrackDelta = (axis: 'col' | 'row', deltaPx: number) => {
    const d = dragRef.current;
    if (!d || !activeWs) return;
    const p = d.pairs[axis];
    const sum = p.wA + p.wB;
    const k = sum / Math.max(1, d.avails[axis]);
    const newWA = clampW(p.wA + deltaPx * k);
    const newWB = Math.max(0.5, sum - newWA);
    setTrack(activeWs.id, axis, p.aIdx, Math.round(newWA * 10) / 10);
    setTrack(activeWs.id, axis, p.bIdx, Math.round(newWB * 10) / 10);
  };

  const paneEdgeAt = (
    e: React.MouseEvent,
    paneEl: HTMLElement,
  ): { axis: 'col' | 'row'; index: number } | null => {
    if (!activeWs) return null;
    const THRESHOLD = 8;
    const idx = Number(paneEl.dataset.idx ?? -1);
    if (idx < 0) return null;
    const { cols, rows } = tracksFor(activeWs);
    const colIdx = idx % cols.length;
    const rowIdx = Math.floor(idx / cols.length);
    const r = paneEl.getBoundingClientRect();
    const nearCol = e.clientX - r.left < THRESHOLD || r.right - e.clientX < THRESHOLD;
    const nearRow = e.clientY - r.top < THRESHOLD || r.bottom - e.clientY < THRESHOLD;
    if (nearCol) {
      const boundary = e.clientX - r.left < THRESHOLD ? colIdx - 1 : colIdx;
      if (boundary >= 0 && boundary < cols.length - 1) return { axis: 'col', index: boundary };
    }
    if (nearRow) {
      const boundary = e.clientY - r.top < THRESHOLD ? rowIdx - 1 : rowIdx;
      if (boundary >= 0 && boundary < rows.length - 1) return { axis: 'row', index: boundary };
    }
    return null;
  };

  const startPaneDrag = (e: React.MouseEvent, paneEl: HTMLElement) => {
    if (!activeWs) return;
    const edge = paneEdgeAt(e, paneEl);
    if (!edge) return;
    const grid = gridRef.current;
    if (!grid) return;
    const { cols, rows, layout } = tracksFor(activeWs);
    const availCol = grid.clientWidth - cols.length * (layout.minW + GRID_GAP) + GRID_GAP;
    const availRow = grid.clientHeight - rows.length * (layout.minH + GRID_GAP) + GRID_GAP;
    const avail = edge.axis === 'col' ? availCol : availRow;
    if (avail <= 4) return;
    e.preventDefault();
    dragRef.current = {
      mode: 'edge',
      axis: edge.axis,
      index: edge.index,
      startX: e.clientX,
      startY: e.clientY,
      pairs: {
        col:
          edge.axis === 'col'
            ? pairFor(cols, edge.index, edge.index + 1)
            : { aIdx: 0, bIdx: 1, wA: 1, wB: 1 },
        row:
          edge.axis === 'row'
            ? pairFor(rows, edge.index, edge.index + 1)
            : { aIdx: 0, bIdx: 1, wA: 1, wB: 1 },
      },
      avails: { col: availCol, row: availRow },
    };
    setDragAxis(edge.axis);
    document.body.style.cursor = edge.axis === 'col' ? 'col-resize' : 'row-resize';
    document.body.style.userSelect = 'none';
    const axis = edge.axis;
    beginDrag(
      (ev) => {
        const delta =
          axis === 'col'
            ? ev.clientX - dragRef.current!.startX
            : ev.clientY - dragRef.current!.startY;
        applyTrackDelta(axis, delta);
      },
      () => {},
    );
  };

  const startCornerDrag = (e: React.MouseEvent, paneId: string) => {
    if (!activeWs || !gridRef.current) return;
    const grid = gridRef.current;
    const idx = activeWs.panes.findIndex((p) => p.id === paneId);
    if (idx < 0) return;
    const { cols, rows, layout } = tracksFor(activeWs);
    const colIdx = idx % cols.length;
    const rowIdx = Math.floor(idx / cols.length);
    const colB = colIdx + 1 < cols.length ? colIdx + 1 : colIdx - 1;
    const rowB = rowIdx + 1 < rows.length ? rowIdx + 1 : rowIdx - 1;
    if (colB < 0 || rowB < 0) return;
    const availCol = grid.clientWidth - cols.length * (layout.minW + GRID_GAP) + GRID_GAP;
    const availRow = grid.clientHeight - rows.length * (layout.minH + GRID_GAP) + GRID_GAP;
    e.preventDefault();
    e.stopPropagation();
    dragRef.current = {
      mode: 'corner',
      axis: 'col',
      index: 0,
      startX: e.clientX,
      startY: e.clientY,
      pairs: {
        col: pairFor(cols, colIdx, colB),
        row: pairFor(rows, rowIdx, rowB),
      },
      avails: { col: Math.max(1, availCol), row: Math.max(1, availRow) },
    };
    setDragAxis('corner');
    document.body.style.cursor = 'nwse-resize';
    document.body.style.userSelect = 'none';
    beginDrag(
      (ev) => {
        const d = dragRef.current;
        if (!d) return;
        applyTrackDelta('col', ev.clientX - d.startX);
        applyTrackDelta('row', ev.clientY - d.startY);
      },
      () => {},
    );
  };

  const collapseGridForPane = useCallback((paneId: string) => {
    setExpandedPane((cur) => (cur !== null && cur !== paneId ? null : cur));
  }, []);

  const attachInGridPane = async (wsId: string, paneId: string, sessionId: string) => {
    try {
      assignPane(wsId, paneId, sessionId);
      collapseGridForPane(paneId);
      showToast(`Attached to ${sessionId}`);
    } catch {
      showToast('Failed to attach', true);
    }
  };

  const closeEmbedPane = async (wsId: string, paneId: string, sessionId: string) => {
    assignPane(wsId, paneId, null);
    // Clear selection/expansion if this was the active pane
    if (selectedPane === paneId) setSelectedPane(null);
    if (expandedPane === paneId) setExpandedPane(null);
    try {
      await tauri.close(sessionId);
    } catch {
      /* session may already be gone */
    }
  };

  // Safety net: clear stale expandedPane
  useEffect(() => {
    if (!expandedPane) return;
    const ws = workspaces.find((w) => w.id === activeId);
    const pane = ws?.panes.find((p) => p.id === expandedPane);
    if (!pane || !pane.tty) setExpandedPane(null);
  }, [workspaces, activeId, expandedPane]);

  // TUI auto-expand re-assert after workspace switch
  useEffect(() => {
    const ws = workspaces.find((w) => w.id === activeId);
    if (!ws) return;
    const expandTui = () => {
      for (const pane of ws.panes) {
        if (!pane.tty || !pane.id) continue;
        const handle = TerminalManager.get(pane.tty);
        if (!handle || !handle.attached) continue;
        let tui = false;
        try {
          tui = handle.term.buffer.active.type === 'alternate';
        } catch {
          /* disposed */
        }
        if (tui) {
          autoExpandRef.current.add(pane.id);
          setExpandedPane(pane.id);
        }
      }
    };
    expandTui();
    const retry = window.setTimeout(expandTui, 300);
    return () => window.clearTimeout(retry);
  }, [activeId]);
  // Auto-select the first terminal when workspace changes
  useEffect(() => {
    if (!activeWs) return;
    const hasFocused = activeWs.panes.some((p) => p.tty === focusedTerminal);
    if (!hasFocused) {
      const firstTerminal = activeWs.panes.find((p) => p.tty);
      setFocusedTerminal(firstTerminal?.tty || null);
    }
  }, [activeWs?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-scroll detection: track pending lines when user scrolls up
  useEffect(() => {
    if (!focusedTerminal) return;
    const handle = TerminalManager.get(focusedTerminal);
    if (!handle?.term) return;

    let wasAtBottom = true;
    const checkScroll = () => {
      try {
        const term = handle.term;
        const buffer = term.buffer.active;
        const viewportY = buffer.viewportY;
        const baseY = buffer.baseY;
        const isAtBottom = viewportY >= baseY + term.rows - 2;

        if (isAtBottom && !wasAtBottom) {
          // Scrolled to bottom — clear pending
          markAtBottom(focusedTerminal);
          setPendingLines(0);
        } else if (!isAtBottom && wasAtBottom) {
          // Scrolled up
          markScrolledUp(focusedTerminal);
        }
        wasAtBottom = isAtBottom;
      } catch {
        /* disposed */
      }
    };

    const disposable = handle.term.onScroll(checkScroll);
    return () => {
      disposable.dispose();
    };
  }, [focusedTerminal, markAtBottom, markScrolledUp]);

  // Track new output arriving while scrolled up
  useEffect(() => {
    if (!focusedTerminal) return;
    const handle = TerminalManager.get(focusedTerminal);
    if (!handle) return;

    let prevTotal = 0;
    const interval = window.setInterval(() => {
      try {
        const term = handle.term;
        const buffer = term.buffer.active;
        const currentTotal = buffer.length;
        if (prevTotal > 0 && currentTotal > prevTotal) {
          if (!isAutoScroll(focusedTerminal)) {
            const newLines = currentTotal - prevTotal;
            markNewOutput(focusedTerminal, newLines);
            setPendingLines(getPendingLines(focusedTerminal));
          }
        }
        prevTotal = currentTotal;
      } catch {
        /* disposed */
      }
    }, 500);

    return () => window.clearInterval(interval);
  }, [focusedTerminal, isAutoScroll, markNewOutput, getPendingLines]);

  const handleScrollToBottom = useCallback(() => {
    if (focusedTerminal) {
      markAtBottom(focusedTerminal);
      setPendingLines(0);
    }
  }, [focusedTerminal, markAtBottom]);

  const toggleAutoExpand = (id: string, enabled: boolean) => {
    setWorkspaces((prev) => prev.map((w) => (w.id === id ? { ...w, autoExpandTui: enabled } : w)));
  };

  const setLayoutMode = (id: string, mode: GridMode) => {
    setWorkspaces((prev) => prev.map((w) => (w.id === id ? { ...w, layoutMode: mode } : w)));
    // Switch to grid view when the user picks a grid layout mode, so the
    // layout change is immediately visible (instead of silently changing a
    // setting the user can't see).
    if (view !== 'grid') setView('grid');
  };

  const renameWorkspace = (id: string, name: string) => {
    setWorkspaces((prev) => prev.map((w) => (w.id === id ? { ...w, name } : w)));
  };

  const setProjectPath = (id: string, projectPath: string) => {
    setWorkspaces((prev) => prev.map((w) => (w.id === id ? { ...w, projectPath } : w)));
  };

  // Welcome video finished → reveal the app and show the 2s "Welcome to tto" popup.
  const handleWelcomeVideoComplete = () => {
    setShowWelcome(false);
    setShowWelcomePopup(true);
    welcomePopupTimer.current = window.setTimeout(() => {
      setShowWelcomePopup(false);
      welcomePopupTimer.current = null;
    }, 2000);
  };

  // Early dismiss (backdrop click) — cancels the pending auto-dismiss timer.
  const dismissWelcomePopup = () => {
    if (welcomePopupTimer.current !== null) {
      window.clearTimeout(welcomePopupTimer.current);
      welcomePopupTimer.current = null;
    }
    setShowWelcomePopup(false);
  };

  if (showWelcome) {
    return <WelcomeVideo onComplete={handleWelcomeVideoComplete} />;
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header>
        <h1>
          <span className="logo">tto</span> Terminal Task Orchestrator
          <span className="app-version">v2.3.0</span>
        </h1>
        <div className="header-right">
          <span id="conn-status" style={{ color: connected ? 'var(--green)' : 'var(--red)' }}>
            ● {connected ? 'connected' : 'disconnected (retrying...)'}
          </span>
          <button
            className={`remote-toggle ${remoteOpen ? 'active' : ''}`}
            onClick={() => setRemoteOpen((o) => !o)}
            title="Remote control (WhatsApp via OpenWA)"
          >
            🛰️
          </button>
          {egoLite && (
            <span
              className="ego-lite-badge"
              title={
                egoLite.app_installed
                  ? `ego-lite: app ✓${egoLite.skill_installed ? ' · skill ✓' : ' · skill ✗'}`
                  : 'ego-lite not installed — agents cannot automate browsers'
              }
            >
              <span
                className={`ego-dot ${egoLite.app_installed && egoLite.skill_installed ? 'ready' : egoLite.app_installed ? 'partial' : ''}`}
              />
              <span className="ego-label">ego-lite</span>
            </span>
          )}
          <LiveClock />
          {inspectorOpen && (
            <span
              className="inspector-mode-badge"
              onClick={() => setInspectorOpen(false)}
              title={`${modifierLabel()}+Shift+A to toggle`}
            >
              INSPECT
              {annotations.length > 0 && (
                <span className="inspector-counter">· {annotations.length}</span>
              )}
            </span>
          )}
        </div>
      </header>

      {remoteOpen && (
        <RemoteControlPanel onToast={showToast} onClose={() => setRemoteOpen(false)} />
      )}

      <WorkspaceBar
        workspaces={workspaces}
        activeId={activeWs?.id || ''}
        theme={theme}
        sidebarOpen={sidebarOpen}
        view={view}
        onSelect={(id) => {
          setActiveId(id);
          setView('workspace');
        }}
        onNew={() => openWizard()}
        onClose={closeWorkspace}
        onTemplate={setTemplate}
        onTheme={setTheme}
        onToggleAutoExpand={toggleAutoExpand}
        onSetLayoutMode={setLayoutMode}
        onAddTerminal={handleNewTerminal}
        onToggleSidebar={() => setSidebarOpen((s) => !s)}
        onView={(v) => {
          setView(v);
        }}
      />

      <div className={`app-body ${sidebarOpen ? 'with-sidebar' : ''}`}>
        {sidebarOpen && (
          <Sidebar
            activeWorkspace={activeWs}
            workspaces={workspaces}
            activeId={activeWs?.id || ''}
            onSelectWorkspace={(id) => {
              setActiveId(id);
              setView('workspace');
            }}
            onRenameWorkspace={renameWorkspace}
            onSetProjectPath={setProjectPath}
            onCloseWorkspace={closeWorkspace}
            onNewWorkspace={() => openWizard()}
            onOpenFile={handleOpenFile}
            onDropFiles={(paths, sessionId, kinds) => handleDrop(sessionId || '', paths, kinds)}
          />
        )}
        <main className="main-area">
          {/* ── Persistent terminal host — ALWAYS mounted ───────────────────
              Every xterm instance lives here, keyed by sessionId, and is moved
              into the active view's anchors (or parked offscreen) as the view
              changes. Views only ever render lightweight <TerminalAnchor>s, so
              switching workspace/grid/cards/ide/... never disposes an xterm and
              terminal scrollback survives every switch. */}
          <TerminalHost
            sessionIds={terminalSessionIds}
            sessionStates={terminalSessionStates}
            view={view}
            onToast={showToast}
            onRestart={handlePaneRestart}
            onKill={handlePaneKill}
            onNewTerminal={handleNewTerminal}
            onTuiChange={handleTuiChange}
            onLinkClick={handleTerminalLinkClick}
            onDrop={handleDrop}
          />
          {view === 'wizard' ? (
            <WorkspaceWizard onCreate={handleWizardCreate} onClose={() => setView('workspace')} />
          ) : view === 'ide' ? (
            <IDEView
              workspaces={workspaces}
              activeId={activeId}
              projectPath={activeWs?.projectPath}
              openFiles={openFiles}
              activeFile={activeFile}
              setActiveFile={setActiveFile}
              setOpenFiles={setOpenFiles}
              handleOpenFile={handleOpenFile}
              onToast={showToast}
              onSendToTerminal={handleSendToTerminal}
              terminals={unifiedTerminals}
              onSelectWorkspace={(id) => {
                setActiveId(id);
                // File tree auto-reloads via IDEView's useEffect on projectPath
              }}
              onSendCommand={handleSendCommand}
              onEnsureTerminal={ensureIdeTerminal}
              terminalSessionId={ideTerminalSessionId || focusedTerminal || activeWsSessionIds[0]}
              closeFile={closeFile}
              gotoNonce={gotoNonce}
            />
          ) : view === 'workspace' ? (
            /* ── TWO-PANEL WORKSPACE LAYOUT (SplitView) ── */
            <SplitView
              initialRatio={0.62}
              minLeft={320}
              minRight={280}
              storageKey="tto-workspace-split"
              orientation="horizontal"
              left={
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    minWidth: 0,
                    minHeight: 0,
                    flex: 1,
                  }}
                >
                  <TerminalWorkspace
                    sessionId={focusedTerminal}
                    sessionIds={allWorkspaceSessionIds}
                    splitSessionIds={activeWsSessionIds}
                    viewMode={viewMode === 'split' ? 'split' : 'focus'}
                    onSelectTerminal={setFocusedTerminal}
                    terminals={unifiedTerminals}
                    onRestart={handlePaneRestart}
                    onKill={handlePaneKill}
                    onNewTerminal={handleNewTerminal}
                    visible={view === 'workspace'}
                    pendingLines={pendingLines}
                    onScrollToBottom={handleScrollToBottom}
                    onDrop={handleDrop}
                    onToast={showToast}
                    chips={dropChips[focusedTerminal || ''] || []}
                    onDismissChip={(id) =>
                      setDropChips((prev) => {
                        const cur = prev[focusedTerminal || ''];
                        if (!cur) return prev;
                        return { ...prev, [focusedTerminal || '']: cur.filter((c) => c.id !== id) };
                      })
                    }
                    onClearChips={() =>
                      setDropChips((prev) => ({ ...prev, [focusedTerminal || '']: [] }))
                    }
                  />
                </div>
              }
              right={
                <div
                  className="right-panel"
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    minWidth: 0,
                    minHeight: 0,
                    flex: 1,
                    overflow: 'hidden',
                  }}
                >
                  {/* ── Control panel: fixed height, never grows ── */}
                  <div style={{ flex: 'none', overflowY: 'auto', minHeight: 0 }}>
                    <WorkspaceControlPanel
                      workspaces={workspaces}
                      activeId={activeId}
                      terminals={unifiedTerminals}
                      focusedTerminal={focusedTerminal}
                      viewMode={viewMode}
                      onSelectTerminal={setFocusedTerminal}
                      onSetViewMode={(mode) => {
                        setViewMode(mode);
                        // Sync the main view: 'grid' viewMode → grid view,
                        // 'focus'/'split' → workspace view.
                        if (mode === 'grid') setView('grid');
                        else setView('workspace');
                      }}
                      onNewTerminal={handleNewTerminal}
                      onSelectWorkspace={(id) => setActiveId(id)}
                      onRenameTerminal={(sid, name) => {
                        const entry = Object.values(unifiedTerminals).find(
                          (u) => (u as UnifiedTerminal).session_id === sid,
                        ) as UnifiedTerminal | undefined;
                        const tty = entry?.tty || sid;
                        import('./api/client').then(({ updateSessionName }) => {
                          updateSessionName(tty, name)
                            .then(() => showToast(`Renamed to "${name}"`))
                            .catch(() => showToast('Failed to rename', true));
                        });
                      }}
                      tokenUsage={tokenUsage}
                    />
                  </div>
                  {/* ── Editor: fills remaining space, scrollable ── */}
                  {activeFile &&
                    (() => {
                      const file = openFiles.find((f) => f.path === activeFile);
                      return file ? (
                        <div
                          className="editor-section"
                          style={{
                            flex: '1 1 0%',
                            minHeight: 0,
                            display: 'flex',
                            flexDirection: 'column',
                            overflow: 'hidden',
                            borderTop: '1px solid var(--border)',
                          }}
                        >
                          {openFiles.length > 1 && (
                            <div className="editor-tabs" style={{ flex: 'none' }}>
                              {openFiles.map((f) => (
                                <button
                                  key={f.path}
                                  className={`editor-tab ${f.path === activeFile ? 'active' : ''}${f.dirty ? ' dirty' : ''}`}
                                  onClick={() => setActiveFile(f.path)}
                                >
                                  <span className="editor-tab-icon">{fileIcon(f.name)}</span>
                                  {f.dirty && <span className="dirty-dot">●</span>}
                                  {f.name}
                                  <span
                                    className="editor-tab-close"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      closeFile(f.path);
                                    }}
                                  >
                                    ×
                                  </span>
                                </button>
                              ))}
                            </div>
                          )}
                          <div style={{ flex: '1 1 0%', minHeight: 0, overflow: 'hidden' }}>
                            <CodeEditor
                              key={`${activeFile}:${gotoNonce}`}
                              path={activeFile}
                              name={file.name}
                              gotoLine={(window as any).__tto_pending_goto_line || undefined}
                              onChange={(dirty) => {
                                setOpenFiles((prev) =>
                                  prev.map((f) => (f.path === activeFile ? { ...f, dirty } : f)),
                                );
                              }}
                              onClose={() => {
                                if (activeFile) closeFile(activeFile);
                              }}
                              onToast={showToast}
                            />
                          </div>
                        </div>
                      ) : null;
                    })()}
                </div>
              }
            />
          ) : view === 'grid' ? (
            /* ── CARD GRID LAYOUT (old workspace view) ── */
            <div className="container" ref={containerRef}>
              <StatsBarCompact stats={stats} />

              {workspaces.map((ws) => {
                const isActiveWs = ws.id === activeId;
                const gridStyleWs = (() => {
                  const { cols, rows, layout } = tracksFor(ws);
                  return {
                    gridTemplateColumns: cols
                      .map((w) => `minmax(${layout.minW}px, ${w}fr)`)
                      .join(' '),
                    gridTemplateRows: rows.map((w) => `minmax(${layout.minH}px, ${w}fr)`).join(' '),
                    gap: GRID_GAP,
                  };
                })();
                return (
                  <div
                    key={ws.id}
                    ref={isActiveWs ? gridRef : undefined}
                    className={`ws-grid${expandedPane ? ' has-expanded' : ''}${dragAxis === 'col' ? ' dragging-col' : dragAxis === 'row' ? ' dragging-row' : dragAxis === 'corner' ? ' dragging-corner' : ''}`}
                    data-grid-mode={ws.layoutMode ?? 'auto'}
                    // REFERENCE PATTERN (matches TerminalWorkspace.tsx):
                    // Non-active workspaces are parked OFFSCREEN at full size
                    // rather than display:none. Collapsing xterm hosts to 0×0
                    // invalidates their render dimensions and the row cache never
                    // recovers -> terminals come back blank/garbled after a tab
                    // or view switch. Keeping real dimensions means no resize/SIGWINCH
                    // burst and a clean refit on reveal (TerminalPane refits on visible).
                    style={
                      view === 'grid' && isActiveWs
                        ? gridStyleWs
                        : {
                            ...gridStyleWs,
                            position: 'absolute',
                            left: '-99999px',
                            top: 0,
                            width: '100%',
                            height: '100%',
                            pointerEvents: 'none',
                          }
                    }
                  >
                    {ws.panes.map((pane, paneIdx) => {
                      const isExpanded = expandedPane === pane.id;
                      const isSelected = selectedPane === pane.id;
                      const isTerminal = !!pane.tty;

                      const paneClass = `ws-pane${isExpanded ? ' ws-pane-expanded' : ''}${isSelected ? ' ws-pane-selected' : ''}${isTerminal ? ' ws-pane-term' : ' ws-pane-empty'}`;

                      const paneDragProps = {
                        'data-idx': paneIdx,
                        onClick: () => selectPane(pane.id),
                        onMouseMove: (e: React.MouseEvent<HTMLDivElement>) => {
                          if (dragRef.current) return;
                          const edge = paneEdgeAt(e, e.currentTarget);
                          e.currentTarget.style.cursor = edge
                            ? edge.axis === 'col'
                              ? 'col-resize'
                              : 'row-resize'
                            : '';
                        },
                        onMouseDown: (e: React.MouseEvent<HTMLDivElement>) =>
                          startPaneDrag(e, e.currentTarget),
                      };

                      if (isTerminal) {
                        const sessionId = pane.tty!;
                        return (
                          <div
                            className={paneClass}
                            key={pane.id}
                            data-tto-session={sessionId}
                            {...paneDragProps}
                          >
                            <div className="ws-pane-head">
                              <span className="ws-traffic" aria-hidden="true">
                                <i className="t-close" />
                                <i className="t-min" />
                                <button
                                  className={`t-max${isExpanded ? ' active' : ''}`}
                                  onClick={() => toggleManualExpand(pane.id)}
                                  title={
                                    isExpanded
                                      ? 'Click to restore grid'
                                      : 'Expand to full workspace'
                                  }
                                />
                              </span>
                              <span className="ws-pane-title">
                                {(() => {
                                  const entry =
                                    unifiedTerminals[sessionId] ||
                                    Object.values(unifiedTerminals).find(
                                      (u) => (u as any).session_id === sessionId,
                                    );
                                  const agent = entry?.agent || '';
                                  const model = entry?.model || (entry as any)?.applied_model || '';
                                  const shortModel = model ? cleanModel(model) : '';
                                  return (
                                    <>
                                      {agent && <span className="ws-pane-agent">{agent}</span>}
                                      {shortModel && (
                                        <span className="ws-pane-model">{shortModel}</span>
                                      )}
                                      <span className="ws-pane-id">{sessionId}</span>
                                    </>
                                  );
                                })()}
                              </span>
                              {isExpanded && (
                                <span
                                  className={`ws-expand-badge${autoExpandRef.current.has(pane.id) ? ' cli' : ''}`}
                                >
                                  {autoExpandRef.current.has(pane.id) ? '⤢ CLI mode' : '⤢ expanded'}
                                </span>
                              )}
                              {proportionalPane === pane.id ? (
                                <button
                                  className="pane-restore-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    restorePane(pane.id);
                                  }}
                                  title="Restore original layout"
                                >
                                  ⤡ Restore
                                </button>
                              ) : isExpanded ? (
                                <button
                                  className="pane-restore-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleManualExpand(pane.id);
                                  }}
                                  title="Exit focus — restore the grid"
                                >
                                  ⤡ Exit focus
                                </button>
                              ) : isSelected ? (
                                <button
                                  className="pane-expand-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    expandPane(pane.id);
                                  }}
                                  title="Expand — other terminals compress proportionally"
                                >
                                  ⤢ Expand
                                </button>
                              ) : null}
                              <button
                                className={`pane-focus-btn${isExpanded ? ' active' : ''}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleManualExpand(pane.id);
                                }}
                                title={
                                  isExpanded ? 'Exit focus' : 'Focus terminal (fill the workspace)'
                                }
                              >
                                ⛶
                              </button>
                              <button
                                className="ws-close"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  closeEmbedPane(ws.id, pane.id, sessionId);
                                }}
                                title="Close terminal"
                              >
                                ✕
                              </button>
                            </div>
                            {/* The xterm itself lives in TerminalHost's shared
                                 pane pool (always mounted) — this anchor is where
                                 the host parks this pane's slot for this cell.
                                 Note: no per-pane TerminalInput here — the input
                                 bar lives in the workspace view (TerminalWorkspace)
                                 for the focused terminal only. Per-pane inputs in
                                 grid view steal ~26px of vertical space from each
                                 terminal card, making full-screen CLIs (opencode,
                                 vim, htop) render with too few rows → wrapped /
                                 compressed banner lines. */}
                            <TerminalAnchor sessionId={sessionId} />
                            {isTauri() && (
                              <div className="ws-pane-input-bar">
                                <TerminalInput sessionId={sessionId} />
                              </div>
                            )}
                            {isSelected && (
                              <div
                                className="ws-resize-handle"
                                onMouseDown={(e) => startCornerDrag(e, pane.id)}
                                title="Drag to resize freely — other terminals auto-adjust"
                              />
                            )}
                          </div>
                        );
                      }

                      return (
                        <div className={paneClass} key={pane.id} {...paneDragProps}>
                          {quickLaunchPane === pane.id ? (
                            /* ── Quick-launch inline form ─────────────────── */
                            <div className="ql-form">
                              <div className="ql-title">⚡ Quick Launch</div>
                              <input
                                className="ql-input"
                                placeholder="/path/to/project"
                                value={quickLaunchPath}
                                onChange={(e) => setQuickLaunchPath(e.target.value)}
                                autoFocus
                              />
                              <input
                                className="ql-input"
                                placeholder="Command (e.g. opencode, claude)"
                                value={quickLaunchCmd}
                                onChange={(e) => setQuickLaunchCmd(e.target.value)}
                              />
                              <div className="ql-row">
                                <label className="ql-label">Terminals:</label>
                                <input
                                  className="ql-num"
                                  type="number"
                                  min={1}
                                  max={16}
                                  value={quickLaunchCount}
                                  onChange={(e) =>
                                    setQuickLaunchCount(parseInt(e.target.value) || 4)
                                  }
                                />
                              </div>
                              <div className="ql-actions">
                                <button
                                  className="btn small primary"
                                  onClick={() => handleQuickLaunch(pane.id)}
                                >
                                  ⚡ Launch
                                </button>
                                <button
                                  className="btn small"
                                  onClick={() => setQuickLaunchPane(null)}
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            /* ── Default empty-pane options ──────────────── */
                            <>
                              <select
                                className="ws-pane-assign"
                                value=""
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val.startsWith('attach:')) {
                                    attachInGridPane(ws.id, pane.id, val.slice(7));
                                  } else {
                                    assignPane(ws.id, pane.id, val);
                                  }
                                }}
                              >
                                <option value="">Open / attach terminal…</option>
                                {isTauri()
                                  ? nativeSessions.map((s) => (
                                      <option key={`att-${s.id}`} value={`attach:${s.id}`}>
                                        🔗 {s.id}
                                        {s.title ? ` · ${s.title}` : ''}
                                      </option>
                                    ))
                                  : list.map((tty) => (
                                      <option key={`att-${tty}`} value={`attach:${tty}`}>
                                        🔗 {tty}
                                        {unifiedTerminals[tty].agent
                                          ? ` · ${unifiedTerminals[tty].agent}`
                                          : ''}
                                      </option>
                                    ))}
                              </select>
                              <button
                                className="btn small"
                                onClick={() => openInPane(ws.id, pane.id)}
                              >
                                + Open new terminal
                              </button>
                              <button
                                className="btn small ql-trigger"
                                onClick={() => {
                                  setQuickLaunchPane(pane.id);
                                  setQuickLaunchPath(activeWs?.projectPath || '');
                                }}
                              >
                                ⚡ Quick Launch
                              </button>
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}

              <div className="status-bar-row">
                <GitStatusBadge
                  workspacePath={activeWs?.projectPath || ''}
                  onOpenInTerminal={() => showToast('Git badge clicked')}
                />
                <div className="muted-line">
                  Last update: {lastUpdate ? new Date(lastUpdate).toLocaleTimeString() : '—'}
                </div>
              </div>
            </div>
          ) : view === 'agent' ? (
            /* ── AGENT WORKSPACE ── */
            <AgentWorkspace />
          ) : view === 'django-reviewer' ? (
            /* ── DJANGO REVIEWER ── */
            <DjangoReviewer />
          ) : (
            /* ── OTHER VIEWS ── */
            <div className="container">
              {view === 'cards' ? null /* WorkspaceTaskCenter has its own header */ : (
                <>
                  <StatsBar
                    stats={stats}
                    leading={<AddTerminalCard onToast={showToast} onOpen={handleNewTerminal} />}
                  />
                  <TokenUsage live={tokenUsage} onToast={showToast} />
                </>
              )}

              {view === 'kanban' ? (
                <KanbanBoard
                  terminals={unifiedTerminals}
                  onToast={showToast}
                  workspaces={workspaces}
                  activeId={activeWs?.id || ''}
                />
              ) : view === 'cards' ? (
                <WorkspaceTaskCenter
                  workspaces={workspaces}
                  terminals={unifiedTerminals}
                  activeId={activeWs?.id || ''}
                  onToast={showToast}
                  attachableSessions={tcmAttachSessions}
                  onAttach={(wsId, paneId, sessionId) => attachInPane(wsId, paneId, sessionId)}
                  onOpenNew={(wsId, paneId) => openInPane(wsId, paneId)}
                  onCreate={() => openWizard()}
                />
              ) : view === 'planner' || view === 'memory' || view === 'ceo' ? (
                <PlannerView
                  workspaces={workspaces}
                  activeId={activeWs?.id || ''}
                  terminals={unifiedTerminals}
                  onToast={showToast}
                />
              ) : null}

              {(view === 'kanban' ||
                view === 'cards' ||
                view === 'planner' ||
                view === 'memory' ||
                view === 'ceo') &&
                activeFile &&
                (() => {
                  const file = openFiles.find((f) => f.path === activeFile);
                  return file ? (
                    <div className="editor-section">
                      {openFiles.length > 1 && (
                        <div className="editor-tabs">
                          {openFiles.map((f) => (
                            <button
                              key={f.path}
                              className={`editor-tab ${f.path === activeFile ? 'active' : ''}`}
                              onClick={() => setActiveFile(f.path)}
                            >
                              <span className="editor-tab-icon">{fileIcon(f.name)}</span>
                              {f.name}
                              <span
                                className="editor-tab-close"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  closeFile(f.path);
                                }}
                              >
                                ×
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                      <CodeEditor
                        key={`${activeFile}:${gotoNonce}`}
                        path={activeFile}
                        name={file.name}
                        gotoLine={(window as any).__tto_pending_goto_line || undefined}
                        onClose={() => {
                          if (activeFile) closeFile(activeFile);
                        }}
                        onToast={showToast}
                      />
                    </div>
                  ) : null;
                })()}

              <div className="status-bar-row">
                <GitStatusBadge
                  workspacePath={activeWs?.projectPath || ''}
                  onOpenInTerminal={() => showToast('Git badge clicked')}
                />
                <div className="muted-line">
                  Last update: {lastUpdate ? new Date(lastUpdate).toLocaleTimeString() : '—'}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      <Toast toast={toast} />

      {/* ── Image Preview Overlay (shown when image files are dropped on terminal) ── */}
      {imagePreview && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'rgba(0,0,0,0.8)',
            backdropFilter: 'blur(8px)',
          }}
          onClick={() => setImagePreview(null)}
        >
          <div
            style={{
              position: 'relative',
              maxWidth: '80vw',
              maxHeight: '80vh',
              background: '#1a1d1a',
              borderRadius: 12,
              border: '1px solid #333',
              overflow: 'hidden',
              boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '8px 14px',
                borderBottom: '1px solid #333',
                fontSize: 12,
                color: '#aaa',
              }}
            >
              <span>🖼 {imagePreview.split('/').pop()}</span>
              <button
                onClick={() => setImagePreview(null)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#aaa',
                  cursor: 'pointer',
                  fontSize: 16,
                }}
              >
                ✕
              </button>
            </div>
            <img
              src={
                isTauri()
                  ? convertFileSrc(imagePreview)
                  : `${apiBase()}/api/file/blob?path=${encodeURIComponent(imagePreview)}`
              }
              alt="Preview"
              style={{
                maxWidth: '75vw',
                maxHeight: '70vh',
                display: 'block',
                objectFit: 'contain',
              }}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).style.display = 'none';
              }}
            />
          </div>
        </div>
      )}

      <CommandPalette
        open={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onSelectFile={handleOpenFile}
        onNewTerminal={handleNewTerminal}
        onNewWorkspace={() => openWizard()}
        files={availableFiles}
      />

      {searchPanelOpen && (
        <SearchPanel
          searchPath={activeWs?.projectPath}
          onClose={() => setSearchPanelOpen(false)}
          onOpenFile={handleOpenFile}
        />
      )}

      {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} />}

      {gitPanelOpen && (
        <div className="git-panel-overlay">
          <div className="git-panel-wrapper">
            <GitSourceControl
              onToast={showToast}
              onOpenFile={handleOpenFile}
              workspacePath={activeWs?.projectPath}
            />
            <button className="git-panel-close" onClick={() => setGitPanelOpen(false)}>
              ×
            </button>
          </div>
        </div>
      )}

      {/* ── UI Inspector (⌘+Shift+A) ─────────────────────────────────── */}
      <InspectorOverlay isOpen={inspectorOpen} annotations={annotations} />
      <InspectorPanel
        activeTty={list[0] || null}
        activeProjectPath={activeWs?.projectPath}
        activeWorkspaceName={activeWs?.name}
        onAnnotationsChange={setAnnotations}
      />

      {/* ── Welcome to tto popup (2s after splash video) ─────────────── */}
      {showWelcomePopup && (
        <div
          className="welcome-popup-overlay"
          onClick={dismissWelcomePopup}
          role="dialog"
          aria-modal="true"
          aria-label="Welcome to tto"
        >
          <div className="welcome-popup-card" onClick={(e) => e.stopPropagation()}>
            <img src="/desktop-icon.png" alt="tto" className="welcome-popup-logo" />
            <h2 className="welcome-popup-title">Welcome to tto</h2>
            <p className="welcome-popup-sub">
              Terminal Task Orchestrator
              <span className="welcome-popup-version">v2.3.0</span>
            </p>
            <p className="welcome-popup-note">Get started with the control panel on the right</p>
          </div>
        </div>
      )}
    </div>
  );
}
