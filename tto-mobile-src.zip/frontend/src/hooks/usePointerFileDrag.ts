import { useEffect, useRef } from 'react';

/**
 * usePointerFileDrag — deterministic file drag-and-drop for the sidebar.
 *
 * WKWebView (the packaged Tauri webview) is unreliable at delivering native
 * HTML5 drag events (dragover/drop) when dragging internal elements over
 * xterm canvases — the previous silent failures were exactly that. Instead of
 * fighting the webview, this hook implements drag-and-drop with raw pointer
 * events: on mousedown we arm a drag, on movement past a threshold we render
 * a floating ghost and highlight the terminal under the cursor, and on mouseup
 * we hit-test the drop target ourselves and route the file path directly.
 *
 * UI feedback (what the user asked for):
 *  - a drag ghost that follows the cursor,
 *  - a glowing "Release to drop" indicator on the terminal pane under the cursor,
 *  - a "✓ Dropped" flash + toast once the drop lands.
 */

export interface PointerDragItem {
  label: string;
  path: string;
  kind: 'file' | 'folder';
  icon?: string; // e.g. '📄' | '📁'
}

const DRAG_THRESHOLD = 6; // px of movement before a drag activates
const GHOST_CLASS = 'tto-drag-ghost';
const TARGET_CLASS = 'tto-drag-target';
const FLASH_CLASS = 'tto-drop-flash';

export function usePointerFileDrag(
  onDrop: (paths: string[], sessionId?: string, kinds?: ('file' | 'folder')[]) => void,
) {
  const onDropRef = useRef(onDrop);
  onDropRef.current = onDrop;

  const armedRef = useRef<PointerDragItem | null>(null); // mousedown armed, not yet moved
  const activeRef = useRef<PointerDragItem | null>(null); // drag actively in progress
  const originRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const movedRef = useRef(false); // did the last interaction become a drag?
  const ghostElRef = useRef<HTMLDivElement | null>(null);
  const highlightedRef = useRef<HTMLElement | null>(null);
  const flashTimerRef = useRef<number | null>(null);

  const clearGhost = () => {
    if (ghostElRef.current) {
      ghostElRef.current.remove();
      ghostElRef.current = null;
    }
  };
  const clearHighlight = () => {
    if (highlightedRef.current) {
      highlightedRef.current.classList.remove(TARGET_CLASS);
      delete highlightedRef.current.dataset.ttoIcon;
      delete highlightedRef.current.dataset.ttoName;
      highlightedRef.current = null;
    }
  };
  const cancel = () => {
    armedRef.current = null;
    activeRef.current = null;
    clearGhost();
    clearHighlight();
  };

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!armedRef.current && !activeRef.current) return;

      // Only activate a drag after real movement.
      if (!activeRef.current) {
        const dx = e.clientX - originRef.current.x;
        const dy = e.clientY - originRef.current.y;
        if (Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
        activeRef.current = armedRef.current;
        movedRef.current = true;
      }

      // Suppress native text selection / element drag while dragging.
      e.preventDefault();

      const item = activeRef.current!;
      // Imperative ghost — no React re-render per mousemove.
      if (!ghostElRef.current) {
        const ghost = document.createElement('div');
        ghost.className = GHOST_CLASS;
        const inner = document.createElement('div');
        const emoji = item.kind === 'folder' ? '📁' : '📄';
        inner.textContent = `${emoji} ${item.label}`;
        ghost.appendChild(inner);
        document.body.appendChild(ghost);
        ghostElRef.current = ghost;
      }
      const ghost = ghostElRef.current;
      ghost.style.left = e.clientX + 14 + 'px';
      ghost.style.top = e.clientY + 10 + 'px';

      // Live highlight: which terminal pane is under the cursor?
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const pane = (el instanceof Element ? el.closest('.term-pane') : null) as HTMLElement | null;
      if (pane !== highlightedRef.current) {
        clearHighlight();
        if (pane) {
          const emoji = item.kind === 'folder' ? '📁' : '📄';
          pane.dataset.ttoIcon = emoji;
          pane.dataset.ttoName = item.label;
          pane.classList.add(TARGET_CLASS);
          highlightedRef.current = pane;
        }
      }
    };

    const onUp = (e: MouseEvent) => {
      if (!activeRef.current) {
        // No drag happened — leave the click alone.
        armedRef.current = null;
        return;
      }
      const item = activeRef.current;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const pane = (el instanceof Element ? el.closest('.term-pane') : null) as HTMLElement | null;

      if (pane) {
        // Route the file → show a ✓ flash on the pane.
        pane.classList.remove(TARGET_CLASS);
        const flashEmoji = item.kind === 'folder' ? '📁' : '📄';
        pane.dataset.ttoFlash = flashEmoji;
        pane.dataset.ttoFlashName = item.label;
        pane.classList.add(FLASH_CLASS);
        if (flashTimerRef.current) window.clearTimeout(flashTimerRef.current);
        flashTimerRef.current = window.setTimeout(() => {
          pane.classList.remove(FLASH_CLASS);
          delete pane.dataset.ttoFlash;
          delete pane.dataset.ttoFlashName;
        }, 900);
        // Identify WHICH terminal this pane belongs to so the drop types into
        // the exact terminal the user dropped on — not the focused/first one.
        // Supported container selectors by view mode:
        // - Focus mode: .terminal-workspace
        // - Split mode: .tw-split-pane
        // - Focus parked panes: .tw-pane-slot
        // - Grid/Card layout (App.tsx): .ws-pane
        const container = pane.closest(
          '.terminal-workspace, .tw-split-pane, .tw-pane-slot, .ws-pane',
        );
        const sessionId =
          container instanceof Element
            ? container.getAttribute('data-tto-session') || undefined
            : undefined;
        onDropRef.current([item.path], sessionId, [item.kind]);
      }

      armedRef.current = null;
      activeRef.current = null;
      clearGhost();
      clearHighlight();
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') cancel();
    };

    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('blur', cancel);
    return () => {
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('mouseup', onUp, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('blur', cancel);
      cancel();
    };
  }, []);

  return {
    /** Call from mousedown on a draggable row. */
    begin: (e: React.MouseEvent, item: PointerDragItem) => {
      if (e.button !== 0) return; // left button only
      // Don't arm when the user is interacting with the rename input.
      const t = e.target as HTMLElement;
      if (t.closest('input, textarea, button, a')) return;
      originRef.current = { x: e.clientX, y: e.clientY };
      armedRef.current = item;
      movedRef.current = false;
    },
    /** Call inside onClick: returns true if the click was actually a drag. */
    consumeDrag: () => {
      const was = movedRef.current;
      movedRef.current = false;
      return was;
    },
  };
}
