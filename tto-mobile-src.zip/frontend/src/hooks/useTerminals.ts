import { useEffect, useState } from 'react';
import type { TerminalEntry, TokenUsage } from '../types';
import { getTerminals } from '../api/client';
import { wsBase } from '../api/base';

export function useTerminals() {
  const [terminals, setTerminals] = useState<Record<string, TerminalEntry>>({});
  const [tokenUsage, setTokenUsage] = useState<TokenUsage | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(0);

  useEffect(() => {
    let ws: WebSocket | null = null;
    let retry: number | undefined;
    let closed = false;
    let lastHash = '';

    const connect = () => {
      if (closed) return;
      // Tauri release: embedded frontend (tauri://localhost) must reach the
      // sidecar at its absolute origin; dev mode uses the Vite proxy.
      ws = new WebSocket(`${wsBase()}/ws`);
      ws.onopen = () => setConnected(true);
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg && msg.type === 'state' && msg.terminals) {
            const h = JSON.stringify(msg.terminals);
            lastHash = h;
            setTerminals(msg.terminals);
            if (msg.token_usage) setTokenUsage(msg.token_usage);
            setLastUpdate(Date.now());
          }
        } catch {
          /* ignore malformed messages */
        }
      };
      ws.onclose = () => {
        setConnected(false);
        ws = null;
        if (!closed) retry = window.setTimeout(connect, 3000);
      };
      ws.onerror = () => {
        try {
          ws?.close();
        } catch {
          /* noop */
        }
      };
    };
    connect();

    // The WebSocket is the authoritative live source. Only fall back to HTTP
    // polling while the socket is NOT connected, so we never double-fetch and
    // never fight the WS for updates in the same interval.
    const poll = window.setInterval(async () => {
      if (ws && ws.readyState === WebSocket.OPEN) return; // WS is live — skip
      try {
        const data = await getTerminals();
        const h = JSON.stringify(data.terminals);
        if (h !== lastHash) {
          lastHash = h;
          setTerminals(data.terminals);
          setLastUpdate(Date.now());
        }
        if (data.token_usage) setTokenUsage(data.token_usage);
      } catch {
        /* silent — WebSocket will cover it */
      }
    }, 3000);

    return () => {
      closed = true;
      if (retry) clearTimeout(retry);
      clearInterval(poll);
      try {
        ws?.close();
      } catch {
        /* noop */
      }
    };
  }, []);

  return { terminals, tokenUsage, connected, lastUpdate };
}
