import { useCallback, useRef } from 'react';

/**
 * Per-terminal scroll state — stored in a ref-backed Map to avoid re-renders
 * when unrelated terminals update.  Each terminal (keyed by session id) tracks
 * its own scroll position and auto-scroll toggle.
 */
interface TerminalScrollState {
  /** Whether new output should auto-scroll the terminal to the bottom. */
  autoScroll: boolean;
  /** Lines received while the user was scrolled up. */
  pendingLines: number;
}

const DEFAULT_STATE: TerminalScrollState = {
  autoScroll: true,
  pendingLines: 0,
};

/**
 * Hook that manages per-terminal scroll/auto-scroll state without causing
 * re-renders on every terminal update.
 *
 * Usage:
 *   const { isAutoScroll, pendingLines, markScrolled, markNewOutput, resetTerminal } =
 *     useTerminalState(sessionId);
 */
export function useTerminalState() {
  const stateMap = useRef<Map<string, TerminalScrollState>>(new Map());

  const getState = useCallback((sessionId: string): TerminalScrollState => {
    return stateMap.current.get(sessionId) || DEFAULT_STATE;
  }, []);

  /** Check if auto-scroll is enabled for a terminal. */
  const isAutoScroll = useCallback(
    (sessionId: string): boolean => {
      return getState(sessionId).autoScroll;
    },
    [getState],
  );

  /** Get count of pending new lines while scrolled up. */
  const getPendingLines = useCallback(
    (sessionId: string): number => {
      return getState(sessionId).pendingLines;
    },
    [getState],
  );

  /** Mark the terminal as scrolled to the bottom (enable auto-scroll). */
  const markAtBottom = useCallback((sessionId: string) => {
    stateMap.current.set(sessionId, {
      autoScroll: true,
      pendingLines: 0,
    });
  }, []);

  /** Mark the terminal as scrolled up (disable auto-scroll). */
  const markScrolledUp = useCallback((sessionId: string) => {
    const prev = stateMap.current.get(sessionId) || DEFAULT_STATE;
    stateMap.current.set(sessionId, {
      ...prev,
      autoScroll: false,
    });
  }, []);

  /** Record new output arriving while scrolled up. */
  const markNewOutput = useCallback((sessionId: string, lineCount: number) => {
    const prev = stateMap.current.get(sessionId) || DEFAULT_STATE;
    if (!prev.autoScroll) {
      stateMap.current.set(sessionId, {
        ...prev,
        pendingLines: prev.pendingLines + lineCount,
      });
    }
  }, []);

  /** Reset state for a terminal (e.g. when terminal is closed). */
  const resetTerminal = useCallback((sessionId: string) => {
    stateMap.current.delete(sessionId);
  }, []);

  return {
    isAutoScroll,
    getPendingLines,
    markAtBottom,
    markScrolledUp,
    markNewOutput,
    resetTerminal,
  };
}
