import { useEffect, useRef } from 'react';
import { listFiles } from '../api/client';

/**
 * Polls the filesystem for changes and calls onChange when files are modified.
 * Uses mtime comparison to detect changes efficiently.
 */
export function useFileWatcher(
  rootPath: string,
  onChange: (path: string, event: 'created' | 'modified' | 'deleted') => void,
  intervalMs: number = 2000,
) {
  const cacheRef = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    if (!rootPath) return;

    const poll = async () => {
      try {
        const result = await listFiles(rootPath);
        const currentFiles = new Map<string, number>();

        for (const entry of result.files || []) {
          const fullPath = rootPath ? `${rootPath}/${entry.name}` : entry.name;
          currentFiles.set(fullPath, entry.mtime || 0);

          const oldMtime = cacheRef.current.get(fullPath);
          if (oldMtime === undefined) {
            // New file
            onChange(fullPath, 'created');
          } else if (entry.mtime && entry.mtime > oldMtime + 1) {
            // Modified (1s debounce)
            onChange(fullPath, 'modified');
          }
        }

        // Check for deleted files
        for (const [path] of cacheRef.current.entries()) {
          if (!currentFiles.has(path)) {
            onChange(path, 'deleted');
          }
        }

        cacheRef.current = currentFiles;
      } catch {
        // Ignore polling errors
      }
    };

    poll();
    const interval = setInterval(poll, intervalMs);
    return () => clearInterval(interval);
  }, [rootPath, intervalMs, onChange]);
}
