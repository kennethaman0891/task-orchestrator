// Sidecar API base URL (spec §4).
//
// Dev mode: Vite serves the frontend on :1420 and proxies /api + /ws to the
// Python sidecar on :8765 — relative URLs work.
//
// Release mode: the frontend is embedded and served from tauri://localhost, so
// relative URLs would resolve to port 80 and fail. We must call the sidecar
// directly at its absolute address.

export const SIDECAR_ORIGIN = 'http://127.0.0.1:8765';

// Single source of truth for the Tauri-webview check lives in terminal/channels
// (used by the IPC layer). Import + re-export here so every /api and component
// consumer gets the SAME implementation — no duplicate detection logic.
import { isTauri } from '../terminal/channels';
export { isTauri };

/** Absolute URL prefix for sidecar REST calls. */
export function apiBase(): string {
  return isTauri() ? SIDECAR_ORIGIN : '';
}

/** Absolute WebSocket URL for the sidecar live state stream. */
export function wsBase(): string {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  if (isTauri()) return `${proto}://127.0.0.1:8765`;
  return `${proto}://${location.host}`;
}
