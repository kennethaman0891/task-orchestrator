import { useState, useCallback } from 'react';
import { useAgentSessions, useAgentSession } from '../hooks/useAgentSession';
import { useAgents } from '../hooks/useAgentHandoff';
import { AgentSidebar } from '../components/AgentSidebar';
import { AgentTimeline } from '../components/AgentTimeline';
import { AgentComposer } from '../components/AgentComposer';
import { ChangedFilesPanel } from '../components/ChangedFilesPanel';
import { TodoPanel } from '../components/TodoPanel';

export function AgentWorkspace() {
  const { agents } = useAgents();
  const { sessions, createSession, deleteSession } = useAgentSessions();
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  // 'build' is opencode's default agent; 'main' is NOT a real opencode agent
  // and makes every message fail with 400.
  const [activeAgentId, setActiveAgentId] = useState<string>('build');
  const [showRightPanel, setShowRightPanel] = useState(false);

  const { session, isStreaming, sendMessage, stopStreaming } = useAgentSession(activeSessionId);

  const handleSelectSession = useCallback((id: string) => {
    setActiveSessionId(id);
  }, []);

  const handleSelectAgent = useCallback((id: string) => {
    setActiveAgentId(id);
  }, []);

  const handleNewSession = useCallback(
    async (agentId: string) => {
      const s = await createSession({ agentId });
      setActiveSessionId(s.id);
    },
    [createSession],
  );

  const handleDeleteSession = useCallback(
    (id: string) => {
      deleteSession(id);
      if (activeSessionId === id) {
        setActiveSessionId(sessions.find((s) => s.id !== id)?.id ?? null);
      }
    },
    [activeSessionId, deleteSession, sessions],
  );

  const handleSend = useCallback(
    async (message: string) => {
      if (!activeSessionId) {
        // Create a new session if none active
        const s = await createSession({ agentId: activeAgentId });
        setActiveSessionId(s.id);
        // NOTE: useAgentSession.sendMessage signature is (content, sessionId).
        await sendMessage(message, s.id);
      } else {
        await sendMessage(message, activeSessionId);
      }
    },
    [activeSessionId, activeAgentId, createSession, sendMessage],
  );

  // Build agent lookup map
  const agentMap = new Map(
    agents.map((a) => [a.id, { name: a.name, color: a.color, icon: a.icon }]),
  );

  return (
    <div className="aw-container">
      {/* ── Left Sidebar ── */}
      <div className="aw-sidebar-wrap">
        <AgentSidebar
          agents={agents}
          sessions={sessions.map((s) => ({
            id: s.id,
            title: s.title,
            agentId: s.agentId,
            status: s.status,
            updatedAt: s.updatedAt,
          }))}
          activeSessionId={activeSessionId}
          activeAgentId={activeAgentId}
          onSelectSession={handleSelectSession}
          onSelectAgent={handleSelectAgent}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
        />
      </div>

      {/* ── Main Area ── */}
      <div className="aw-main">
        {/* Header */}
        <div className="aw-header">
          <div className="aw-header-left">
            {/* Mac traffic-light dots */}
            <div className="aw-mac-dots" aria-hidden="true">
              <span className="aw-mac-dot aw-mac-dot--close"></span>
              <span className="aw-mac-dot aw-mac-dot--minimize"></span>
              <span className="aw-mac-dot aw-mac-dot--maximize"></span>
            </div>
            <span className="aw-header-title">{session?.title || 'Agent Workspace'}</span>
            {session && (
              <span
                className={`aw-status-badge aw-status-${session.status}`}
                role="status"
                aria-label={`Session status: ${session.status}`}
              >
                {session.status === 'running'
                  ? 'Running'
                  : session.status === 'completed'
                    ? 'Done'
                    : session.status === 'error'
                      ? 'Error'
                      : 'Idle'}
              </span>
            )}
          </div>
          <div className="aw-header-right">
            <button
              className={`aw-panel-toggle ${showRightPanel ? 'active' : ''}`}
              onClick={() => setShowRightPanel(!showRightPanel)}
              title="Toggle files/todo panel"
              aria-label="Toggle files and todo panel"
              aria-pressed={showRightPanel}
            >
              &#9776;
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="aw-content">
          <div className="aw-timeline-wrap">
            {session ? (
              <>
                <AgentTimeline
                  events={session.messages}
                  agentMap={agentMap}
                  isStreaming={isStreaming}
                />
              </>
            ) : (
              <div className="aw-empty">
                <div className="aw-empty-icon" aria-hidden="true">
                  $
                </div>
                <div className="aw-empty-title">Agent Workspace</div>
                <div className="aw-empty-hint">Select an agent and start a conversation</div>
                <button className="aw-start-btn" onClick={() => handleNewSession('main')}>
                  Start New Session
                </button>
              </div>
            )}
          </div>

          {/* Right Panel */}
          {showRightPanel && session && (
            <div className="aw-right-panel">
              <ChangedFilesPanel events={session.messages} />
              <TodoPanel events={session.messages} />
            </div>
          )}
        </div>

        {/* Composer */}
        <AgentComposer
          onSend={handleSend}
          onStop={stopStreaming}
          isStreaming={isStreaming}
          model={agents.find((a) => a.id === activeAgentId)?.model}
          agents={agents.map((a) => ({ id: a.id, name: a.name, icon: a.icon }))}
          activeAgentId={activeAgentId}
        />
      </div>
    </div>
  );
}
