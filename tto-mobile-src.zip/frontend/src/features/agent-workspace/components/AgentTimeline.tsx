import { useEffect, useRef } from 'react';
import type { AgentEvent } from '../types/agent';
import { AgentMessage } from './AgentMessage';

interface Props {
  events: AgentEvent[];
  agentMap: Map<string, { name: string; color: string; icon: string }>;
  isStreaming?: boolean;
}

/**
 * Renders a WhatsApp-style chat timeline.
 *
 * - User messages bubble right, agent messages bubble left.
 * - `thinking` events are NOT rendered as persistent bubbles. Instead a
 *   transient typing indicator (WhatsApp-style three dots) shows while the
 *   agent is processing (driven by `isStreaming`) and disappears once the
 *   agent's reply / completion event arrives.
 */
export function AgentTimeline({ events, agentMap, isStreaming }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [events, isStreaming]);

  // `thinking`/`streaming` are shown via the transient typing indicator and
  // must NOT render as persistent bubbles (which would linger after done).
  const visibleEvents = events.filter((e) => e.type !== 'thinking' && e.type !== 'streaming');

  const hasMessages = visibleEvents.length > 0;

  if (!hasMessages && !isStreaming) {
    return (
      <div className="aw-timeline-empty">
        <div className="aw-timeline-empty-icon" aria-hidden="true">
          $
        </div>
        <div className="aw-timeline-empty-title">Start a conversation</div>
        <div className="aw-timeline-empty-hint">
          Send a message to begin working with your agent
        </div>
      </div>
    );
  }

  return (
    <div className="aw-timeline">
      {visibleEvents.map((event) => {
        const agent = event.agentId ? agentMap.get(event.agentId) : null;
        return (
          <AgentMessage
            key={event.id}
            event={event}
            agentName={agent?.name}
            agentColor={agent?.color}
          />
        );
      })}

      {isStreaming && (
        <div className="aw-typing" role="status" aria-label="Agent is thinking">
          <div className="aw-typing-bubble">
            <span className="aw-typing-dot" aria-hidden="true"></span>
            <span className="aw-typing-dot" aria-hidden="true"></span>
            <span className="aw-typing-dot" aria-hidden="true"></span>
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}
