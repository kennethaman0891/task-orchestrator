import type { Agent } from '../types/agent';

interface Props {
  agents: Agent[];
  sessions: Array<{
    id: string;
    title: string;
    agentId: string;
    status: string;
    updatedAt: number;
  }>;
  activeSessionId: string | null;
  activeAgentId: string;
  onSelectSession: (id: string) => void;
  onSelectAgent: (id: string) => void;
  onNewSession: (agentId: string) => void;
  onDeleteSession: (id: string) => void;
}

export function AgentSidebar({
  agents,
  sessions,
  activeSessionId,
  activeAgentId,
  onSelectSession,
  onSelectAgent,
  onNewSession,
  onDeleteSession,
}: Props) {
  const formatTime = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return d.toLocaleDateString();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return '\u25B6'; // ▶
      case 'completed':
        return '\u2713'; // ✓
      case 'error':
        return '\u2717'; // ✗
      default:
        return '\u25CB'; // ○
    }
  };

  const agentMap = new Map(agents.map((a) => [a.id, a]));

  return (
    <div className="aw-sidebar">
      {/* ── Agents Section ── */}
      <div className="aw-sidebar-section">
        <div className="aw-sidebar-section-header">
          <span className="aw-sidebar-section-title">Agents</span>
          <span className="aw-sidebar-count">{agents.length}</span>
        </div>
        <div className="aw-agent-list">
          {agents.map((agent) => (
            <button
              key={agent.id}
              className={`aw-agent-item ${activeAgentId === agent.id ? 'active' : ''}`}
              onClick={() => onSelectAgent(agent.id)}
              title={agent.description}
            >
              <span className="aw-agent-icon">{agent.icon}</span>
              <div className="aw-agent-info">
                <span className="aw-agent-name">{agent.name}</span>
                <span className="aw-agent-model">
                  {agent.model.split('-').slice(0, 2).join('-')}
                </span>
              </div>
              <span
                className={`aw-agent-status aw-agent-status-${agent.status}`}
                role="status"
                aria-label={`Agent status: ${agent.status}`}
              >
                <span className="aw-agent-status-dot" aria-hidden="true"></span>
                <span className="aw-agent-status-label">{agent.status}</span>
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Sessions Section ── */}
      <div className="aw-sidebar-section">
        <div className="aw-sidebar-section-header">
          <span className="aw-sidebar-section-title">Sessions</span>
          <span className="aw-sidebar-count">{sessions.length}</span>
        </div>
        <div className="aw-session-list">
          {sessions.length === 0 && <div className="aw-sidebar-empty">No sessions yet.</div>}
          {sessions.map((s) => (
            <div key={s.id} className="aw-session-item">
              <button
                className={`aw-session-btn ${activeSessionId === s.id ? 'active' : ''}`}
                onClick={() => onSelectSession(s.id)}
              >
                <span className="aw-session-status">{getStatusIcon(s.status)}</span>
                <div className="aw-session-info">
                  <span className="aw-session-title">{s.title}</span>
                  <span className="aw-session-meta">
                    {agentMap.get(s.agentId)?.icon} · {formatTime(s.updatedAt)}
                  </span>
                </div>
              </button>
              <button
                className="aw-session-delete"
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteSession(s.id);
                }}
                title="Delete session"
              >
                ×
              </button>
            </div>
          ))}
        </div>
        <button
          className="aw-new-session-btn"
          onClick={() => onNewSession(activeAgentId)}
          aria-label="Create new session"
        >
          $ new session
        </button>
      </div>
    </div>
  );
}
