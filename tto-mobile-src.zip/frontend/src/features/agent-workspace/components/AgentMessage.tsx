import type { AgentEvent } from '../types/agent';

interface Props {
  event: AgentEvent;
  agentName?: string;
  agentColor?: string;
}

function formatTime(ts?: number): string {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

/**
 * Renders a single message as a WhatsApp-style chat bubble.
 *
 * - User messages bubble RIGHT (green), agent messages bubble LEFT (light).
 * - `thinking`/`streaming` events render nothing here: they are shown as a
 *   transient typing indicator in the timeline (so they don't persist after
 *   the task completes).
 * - Tool calls, tool results, diffs, handoffs, errors and todo updates are
 *   rendered as left-aligned "system cards" (they belong to the agent side).
 */
export function AgentMessage({ event, agentName, agentColor }: Props) {
  const isUser = event.content?.startsWith('[User]');
  const content = isUser ? event.content?.slice(7) : event.content; // strip "[User] "
  const time = formatTime(event.timestamp);

  // Thinking / streaming are handled by the transient typing indicator.
  if (event.type === 'thinking' || event.type === 'streaming') {
    return null;
  }

  if (event.type === 'tool_call') {
    const tool = event.tool;
    const cmd = tool?.input ? String((tool.input as Record<string, unknown>).command ?? '') : '';
    const hasCmd = !!cmd;
    const inputStr =
      tool?.input && Object.keys(tool.input).length > 0 ? JSON.stringify(tool.input, null, 2) : '';
    return (
      <div className="aw-bubble-row agent">
        <div className="aw-sys-card" role="article" aria-label={`Tool call: ${tool?.name}`}>
          <div className="aw-sys-card-header">
            <span className="aw-sys-card-icon" aria-hidden="true">
              $
            </span>
            <span className="aw-sys-card-name">{tool?.name}</span>
          </div>
          {hasCmd && <pre className="aw-sys-card-code">{cmd}</pre>}
          {!hasCmd && inputStr && (
            <details className="aw-sys-card-details">
              <summary>Show input</summary>
              <pre className="aw-sys-card-code">{inputStr}</pre>
            </details>
          )}
        </div>
      </div>
    );
  }

  if (event.type === 'tool_result') {
    const output = event.tool?.output || '';
    const error = event.tool?.error || '';
    const hasLongOutput = output.length > 300 || error.length > 300;
    return (
      <div className="aw-bubble-row agent">
        <div className="aw-sys-card" role="article" aria-label={`Tool result: ${event.tool?.name}`}>
          <div className="aw-sys-card-header">
            <span className="aw-sys-card-icon" aria-hidden="true">
              &#10003;
            </span>
            <span className="aw-sys-card-name">{event.tool?.name} — result</span>
          </div>
          {output && !hasLongOutput && <pre className="aw-sys-card-output">{output}</pre>}
          {output && hasLongOutput && (
            <details className="aw-sys-card-details" open>
              <summary>Output ({output.length} chars)</summary>
              <pre className="aw-sys-card-output">{output}</pre>
            </details>
          )}
          {error && <pre className="aw-sys-card-error">{error}</pre>}
        </div>
      </div>
    );
  }

  if (event.type === 'diff') {
    return (
      <div className="aw-bubble-row agent">
        <div className="aw-sys-card" role="article" aria-label={`Diff: ${event.file?.path}`}>
          <div className="aw-sys-card-header">
            <span className="aw-sys-card-icon" aria-hidden="true">
              &#9670;
            </span>
            <span className="aw-sys-card-name">{event.file?.path}</span>
          </div>
          <pre className="aw-sys-card-code">{event.file?.diff || content}</pre>
        </div>
      </div>
    );
  }

  if (event.type === 'handoff') {
    return (
      <div className="aw-bubble-row agent">
        <div
          className="aw-sys-card"
          role="status"
          aria-label={`Handoff from ${event.handoff?.sourceAgentId} to ${event.handoff?.targetAgentId}`}
        >
          <div className="aw-sys-card-header">
            <span className="aw-sys-card-icon" aria-hidden="true">
              &#8627;
            </span>
            <span className="aw-sys-card-name">
              {event.handoff?.sourceAgentId} &rarr; {event.handoff?.targetAgentId}
            </span>
          </div>
          <span className="aw-sys-card-task">{event.handoff?.task}</span>
        </div>
      </div>
    );
  }

  if (event.type === 'error') {
    return (
      <div className="aw-bubble-row agent">
        <div className="aw-sys-card aw-sys-card--error" role="alert">
          <span className="aw-sys-card-icon" aria-hidden="true">
            &#x2717;
          </span>
          <span className="aw-sys-card-text">{content}</span>
        </div>
      </div>
    );
  }

  if (event.type === 'todo_update' && event.todos) {
    return (
      <div className="aw-bubble-row agent">
        <div className="aw-sys-card" role="list" aria-label="Todo list update">
          {event.todos.map((todo) => (
            <div
              key={todo.id}
              className={`aw-todo-item ${todo.done ? 'done' : ''}`}
              role="listitem"
            >
              <span className="aw-todo-check" aria-hidden="true">
                {todo.done ? '\u2713' : '\u25CB'}
              </span>
              <span className="aw-todo-text">{todo.text}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Default: WhatsApp-style text bubble (user right / agent left).
  return (
    <div className={`aw-bubble-row ${isUser ? 'user' : 'agent'}`}>
      {!isUser && agentName && (
        <div className="aw-bubble-agent" style={{ color: agentColor || undefined }}>
          {agentName}
        </div>
      )}
      <div className={`aw-bubble ${isUser ? 'user' : 'agent'}`}>
        <div className="aw-bubble-text">{content}</div>
        <div className="aw-bubble-meta">
          {time && <span className="aw-bubble-time">{time}</span>}
          {isUser && (
            <span className="aw-bubble-checks" aria-hidden="true">
              &#10003;&#10003;
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
