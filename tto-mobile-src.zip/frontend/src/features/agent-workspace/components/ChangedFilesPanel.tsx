import type { AgentEvent } from '../types/agent';

interface Props {
  events: AgentEvent[];
}

/**
 * Shows files that were read/written during the session.
 */
export function ChangedFilesPanel({ events }: Props) {
  const files = events
    .filter((e) => e.type === 'file_read' || e.type === 'file_write' || e.type === 'diff')
    .map((e) => e.file?.path)
    .filter(Boolean);

  const uniqueFiles = [...new Set(files)];

  if (uniqueFiles.length === 0) {
    return null;
  }

  return (
    <div className="aw-files-panel" role="region" aria-label="Changed files">
      <div className="aw-files-header">
        <span>&#9670; Changed Files</span>
        <span className="aw-files-count">{uniqueFiles.length}</span>
      </div>
      <div className="aw-files-list" role="list">
        {uniqueFiles.map((path) => (
          <div key={path} className="aw-file-item" role="listitem">
            <span className="aw-file-name">{path}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
