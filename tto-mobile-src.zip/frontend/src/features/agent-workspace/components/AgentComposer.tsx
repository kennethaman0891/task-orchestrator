import { useState, useRef, useCallback } from 'react';

interface Props {
  onSend: (message: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  model?: string;
  agents?: Array<{ id: string; name: string; icon: string }>;
  activeAgentId?: string;
  onAgentChange?: (id: string) => void;
}

export function AgentComposer({
  onSend,
  onStop,
  isStreaming,
  model,
  agents,
  activeAgentId,
}: Props) {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = useCallback(() => {
    const msg = value.trim();
    if (!msg) return;
    onSend(msg);
    setValue('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  }, [value, onSend]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        handleSubmit();
      }
    },
    [handleSubmit],
  );

  const handleInput = useCallback(() => {
    const el = textareaRef.current;
    if (el) {
      el.style.height = 'auto';
      el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
    }
  }, []);

  return (
    <div className="aw-composer" role="form" aria-label="Agent message composer">
      <div className="aw-composer-top">
        <div className="aw-composer-model">
          {model && <span className="aw-composer-model-name">{model}</span>}
        </div>
        <div className="aw-composer-hint">
          {isStreaming ? (
            <button className="aw-stop-btn" onClick={onStop} aria-label="Stop streaming">
              &#x25A0; Stop
            </button>
          ) : (
            <span>&#8984;&#8629; to send</span>
          )}
        </div>
      </div>
      <div className="aw-composer-body">
        <span className="aw-composer-prompt" aria-hidden="true">
          &gt;
        </span>
        <textarea
          ref={textareaRef}
          className="aw-composer-input"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onInput={handleInput}
          placeholder="Message the agent..."
          rows={1}
          disabled={isStreaming}
          aria-label="Type your message to the agent"
        />
        <button
          className={`aw-send-btn ${isStreaming ? 'streaming' : ''}`}
          onClick={isStreaming ? onStop : handleSubmit}
          disabled={!value.trim() && !isStreaming}
          aria-label={isStreaming ? 'Stop streaming' : 'Send message'}
        >
          {isStreaming ? '\u25A0' : '\u2191'}
        </button>
      </div>
      {agents && agents.length > 1 && (
        <div className="aw-composer-agents" role="group" aria-label="Select agent">
          {agents.map((agent) => (
            <button
              key={agent.id}
              className={`aw-agent-chip ${activeAgentId === agent.id ? 'active' : ''}`}
              onClick={() => {}}
              title={agent.name}
              aria-label={`Switch to ${agent.name}`}
              aria-pressed={activeAgentId === agent.id}
            >
              {agent.icon} {agent.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
