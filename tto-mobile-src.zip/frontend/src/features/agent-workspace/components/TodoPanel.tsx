import type { AgentEvent } from '../types/agent';

interface Props {
  events: AgentEvent[];
}

/**
 * Shows todos/progress extracted from agent events.
 */
export function TodoPanel({ events }: Props) {
  const todos = events.flatMap((e) => e.todos || []).filter((t) => t);

  if (todos.length === 0) {
    return null;
  }

  const done = todos.filter((t) => t.done).length;

  return (
    <div className="aw-todo-panel" role="region" aria-label="Progress tracker">
      <div className="aw-todo-header">
        <span>&#9670; Progress</span>
        <span className="aw-todo-count">
          {done}/{todos.length}
        </span>
      </div>
      <div className="aw-todo-list" role="list">
        {todos.map((todo) => (
          <div key={todo.id} className={`aw-todo-item ${todo.done ? 'done' : ''}`} role="listitem">
            <span className="aw-todo-check" aria-hidden="true">
              {todo.done ? '\u2713' : '\u25CB'}
            </span>
            <span className="aw-todo-text">{todo.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
