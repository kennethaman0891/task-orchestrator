import { useEffect, useRef, useState, useCallback } from 'react';
import { OpenCodeAdapter } from '../services/OpenCodeAdapter';
import type { AgentSession, AgentEvent } from '../types/agent';

/**
 * Manages a single agent session's lifecycle and events.
 */
export function useAgentSession(sessionId: string | null) {
  const [session, setSession] = useState<AgentSession | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const unsubRef = useRef<(() => void) | null>(null);

  const refresh = useCallback(() => {
    if (sessionId) {
      setSession(OpenCodeAdapter.getSession(sessionId) ?? null);
    }
  }, [sessionId]);

  useEffect(() => {
    refresh();

    if (sessionId) {
      unsubRef.current = OpenCodeAdapter.subscribeToEvents((event: AgentEvent) => {
        if (event.sessionId === sessionId) {
          setIsStreaming(event.type === 'streaming' || event.type === 'thinking');
          refresh();
        }
      });
    }

    return () => {
      if (unsubRef.current) unsubRef.current();
    };
  }, [sessionId, refresh]);

  const sendMessage = useCallback(
    async (content: string, sid?: string) => {
      const targetId = sid ?? sessionId;
      if (!targetId) return;
      setIsStreaming(true);
      try {
        await OpenCodeAdapter.sendMessage(targetId, content);
      } finally {
        setIsStreaming(false);
        refresh();
      }
    },
    [sessionId, refresh],
  );

  const stopStreaming = useCallback(() => {
    setIsStreaming(false);
  }, []);

  return { session, isStreaming, sendMessage, stopStreaming, refresh };
}

/**
 * Manages the list of sessions and creation/deletion.
 */
export function useAgentSessions() {
  const [sessions, setSessions] = useState<AgentSession[]>([]);

  const refresh = useCallback(() => {
    setSessions(OpenCodeAdapter.listSessions());
  }, []);

  useEffect(() => {
    refresh();
    const unsub = OpenCodeAdapter.subscribeToEvents(refresh);
    return () => unsub();
  }, [refresh]);

  const createSession = useCallback(
    async (opts: { agentId: string; cwd?: string }) => {
      const s = await OpenCodeAdapter.createSession(opts);
      refresh();
      return s;
    },
    [refresh],
  );

  const deleteSession = useCallback(
    (sessionId: string) => {
      OpenCodeAdapter.deleteSession(sessionId);
      refresh();
    },
    [refresh],
  );

  return { sessions, createSession, deleteSession, refresh };
}
