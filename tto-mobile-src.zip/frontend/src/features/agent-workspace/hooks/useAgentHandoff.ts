import { useEffect, useState, useCallback } from 'react';
import { OpenCodeAdapter } from '../services/OpenCodeAdapter';
import type { Agent } from '../types/agent';

/**
 * Manages the list of available agents.
 */
export function useAgents() {
  const [agents, setAgents] = useState<Agent[]>(OpenCodeAdapter.agents);

  const refresh = useCallback(() => {
    setAgents(OpenCodeAdapter.agents);
  }, []);

  return { agents, refresh };
}

/**
 * Manages agent handoffs.
 */
export function useAgentHandoffs(sessionId?: string) {
  const [handoffs, setHandoffs] = useState<
    Array<{
      id: string;
      sourceAgentId: string;
      targetAgentId: string;
      task: string;
      context?: string;
      parentSessionId?: string;
      parentMessageId?: string;
      status: 'queued' | 'running' | 'completed' | 'failed';
      createdAt: string;
    }>
  >([]);

  const refresh = useCallback(() => {
    setHandoffs(OpenCodeAdapter.getHandoffs(sessionId));
  }, [sessionId]);

  useEffect(() => {
    refresh();
    const unsub = OpenCodeAdapter.subscribeToEvents(refresh);
    return () => unsub();
  }, [refresh]);

  const createHandoff = useCallback(
    (opts: { sourceAgentId: string; targetAgentId: string; task: string; context?: string }) => {
      const h = OpenCodeAdapter.createHandoff({ ...opts, parentSessionId: sessionId });
      refresh();
      return h;
    },
    [sessionId, refresh],
  );

  return { handoffs, createHandoff, refresh };
}
