// ── OpenCode Adapter ────────────────────────────────────────────────────────
//
// Bridges the OpenCode Server (http://localhost:4096) into normalized
// AgentEvent streams via the tto Python sidecar (http://127.0.0.1:8765).
//
// The sidecar proxies all OpenCode requests so the browser never hits
// port 4096 directly (avoids CORS).
//
// Usage:
//   1. Start opencode server: `opencode serve --port 4096`
//   2. The adapter auto-detects it and connects.

import { apiBase } from '../../../api/base';

import type { AgentEvent, AgentSession, Agent, AgentHandoff } from '../types/agent';

// ── State ──────────────────────────────────────────────────────────────────

const sessions = new Map<string, AgentSession>();
const eventCallbacks = new Set<(event: AgentEvent) => void>();
let _opencodeUrl = '';
let _healthChecked = false;

// ── Helpers ────────────────────────────────────────────────────────────────

async function ocFetch(path: string, init?: RequestInit): Promise<Response> {
  const url = `${apiBase()}/api/opencode${path}`;
  const resp = await fetch(url, init);
  if (!resp.ok) {
    const text = await resp.text().catch(() => '');
    throw new Error(`OpenCode ${resp.status}: ${text.slice(0, 200)}`);
  }
  return resp;
}

async function checkOpencodeHealth(): Promise<boolean> {
  if (_healthChecked) return !!_opencodeUrl;
  _healthChecked = true;
  try {
    const resp = await fetch(`${apiBase()}/api/opencode/health`);
    const data = await resp.json().catch(() => ({}));
    if (data.healthy) {
      _opencodeUrl = 'http://127.0.0.1:4096';
      return true;
    }
  } catch {
    /* not running */
  }
  return false;
}

/** Poll for health every 5s until the server appears. */
function pollHealth(onUp: () => void): () => void {
  const interval = setInterval(async () => {
    if (await checkOpencodeHealth()) {
      clearInterval(interval);
      onUp();
    }
  }, 5000);
  return () => clearInterval(interval);
}

// ── Session Management ─────────────────────────────────────────────────────

export async function createSession(opts: {
  agentId: string;
  cwd?: string;
  opencodeSessionId?: string;
}): Promise<AgentSession> {
  const id = `session-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  let opencodeSessionId = opts.opencodeSessionId;

  // Create a real OpenCode session if none exists
  if (!opencodeSessionId) {
    try {
      const resp = await ocFetch('/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agent: opts.agentId, directory: opts.cwd || '/' }),
      });
      const data = (await resp.json()) as { id: string };
      opencodeSessionId = data.id;
    } catch (e: any) {
      console.warn('Failed to create OpenCode session:', e?.message);
    }
  }

  const session: AgentSession = {
    id,
    title: 'New Session',
    agentId: opts.agentId,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    todos: [],
    status: 'idle',
    opencodeSessionId,
    cwd: opts.cwd,
  };
  sessions.set(id, session);
  return session;
}

export function getSession(sessionId: string): AgentSession | undefined {
  return sessions.get(sessionId);
}

export function listSessions(): AgentSession[] {
  return Array.from(sessions.values());
}

export function deleteSession(sessionId: string): void {
  sessions.delete(sessionId);
}

// ── Event Emission ─────────────────────────────────────────────────────────

export function emitEvent(event: AgentEvent): void {
  const session = sessions.get(event.sessionId);
  if (session) {
    // IMPORTANT: create a NEW object reference on every mutation. React's
    // useState uses Object.is() to decide whether to re-render, so mutating
    // the same object in place never triggers a re-render (the conversation
    // would appear blank when a new message arrives).
    const nextStatus =
      event.type === 'completed'
        ? 'completed'
        : event.type === 'error'
          ? 'error'
          : event.type === 'thinking' || event.type === 'streaming'
            ? 'running'
            : session.status;
    const next: AgentSession = {
      ...session,
      messages: [...session.messages, event],
      updatedAt: Date.now(),
      status: nextStatus,
    };
    sessions.set(event.sessionId, next);
  }
  eventCallbacks.forEach((cb) => cb(event));
}

export function subscribeToEvents(cb: (event: AgentEvent) => void): () => void {
  eventCallbacks.add(cb);
  return () => eventCallbacks.delete(cb);
}

// ── Send Message (real OpenCode call) ──────────────────────────────────────

let _abortController: AbortController | null = null;

export async function sendMessage(
  sessionId: string,
  content: string,
  opts?: { agentId?: string; model?: string },
): Promise<void> {
  const session = sessions.get(sessionId);
  if (!session) throw new Error(`Session ${sessionId} not found`);

  // Cancel any in-flight request
  if (_abortController) {
    try {
      _abortController.abort();
    } catch {}
  }
  _abortController = new AbortController();

  session.status = 'running';
  session.updatedAt = Date.now();

  // Emit user message
  emitEvent({
    id: `evt-${Date.now()}-user`,
    type: 'message',
    timestamp: Date.now(),
    sessionId,
    agentId: opts?.agentId,
    content: `[User] ${content}`,
  });

  // Emit thinking
  emitEvent({
    id: `evt-${Date.now()}-think`,
    type: 'thinking',
    timestamp: Date.now(),
    sessionId,
    agentId: opts?.agentId,
    content: 'Thinking...',
  });

  try {
    // Use OpenCode session ID if available, otherwise use local ID
    const ocSessionId = session.opencodeSessionId || sessionId;
    const resp = await ocFetch(`/session/${ocSessionId}/message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: content,
        model: opts?.model,
        agent: opts?.agentId,
        no_reply: false,
      }),
      signal: _abortController.signal,
    });

    const data = (await resp.json()) as { info?: any; parts?: any[] };

    // Parse the response parts into events
    if (data.parts) {
      for (const part of data.parts) {
        await parsePart(part, sessionId, opts?.agentId);
      }
    }

    if (data.info) {
      emitEvent({
        id: `evt-${Date.now()}-done`,
        type: 'completed',
        timestamp: Date.now(),
        sessionId,
        content: `Done.`,
      });
    }

    session.status = 'completed';
    if (session.messages.length > 0) {
      const firstUserMsg = session.messages.find((m) => m.content?.startsWith('[User]'));
      if (firstUserMsg) {
        session.title = firstUserMsg.content
          ? firstUserMsg.content.slice(6, 40) + (firstUserMsg.content.length > 40 ? '…' : '')
          : 'Session';
      }
    }
  } catch (e: any) {
    if (e.name === 'AbortError') {
      emitEvent({
        id: `evt-${Date.now()}-abort`,
        type: 'completed',
        timestamp: Date.now(),
        sessionId,
        content: 'Stopped.',
      });
      return;
    }
    emitEvent({
      id: `evt-${Date.now()}-err`,
      type: 'error',
      timestamp: Date.now(),
      sessionId,
      content: e?.message || 'Unknown error',
    });
    session.status = 'error';
  } finally {
    _abortController = null;
  }
}

/** Stop a running agent response. */
export function stopStreaming(): void {
  if (_abortController) {
    _abortController.abort();
    _abortController = null;
  }
}

// ── Part Parsing ────────────────────────────────────────────────────────────

interface OcPart {
  type: string;
  subtype?: string;
  content?: string;
  text?: string;
  tool_name?: string;
  tool_input?: Record<string, unknown>;
  tool_output?: string;
  tool_error?: string;
  status?: string;
  // File diff fields
  path?: string;
  diff?: string;
  old_content?: string;
  new_content?: string;
  // Todo fields
  todos?: Array<{ id: string; text: string; done: boolean }>;
  // Thinking fields
  thinking?: string;
}

async function parsePart(part: OcPart, sessionId: string, agentId?: string): Promise<void> {
  const base = { timestamp: Date.now(), sessionId, agentId } as const;

  switch (part.type) {
    case 'text':
    case 'assistant':
      if (part.thinking) {
        emitEvent({
          ...base,
          id: `evt-${Date.now()}-think`,
          type: 'thinking',
          content: part.thinking,
        });
      }
      if (part.text || part.content) {
        emitEvent({
          ...base,
          id: `evt-${Date.now()}-msg`,
          type: 'message',
          content: part.text || part.content,
        });
      }
      break;

    case 'tool_use':
      emitEvent({
        ...base,
        id: `evt-${Date.now()}-tool`,
        type: 'tool_call',
        tool: {
          name: part.tool_name || part.subtype || 'Tool',
          input: part.tool_input,
        },
      });
      break;

    case 'tool_result':
      emitEvent({
        ...base,
        id: `evt-${Date.now()}-tres`,
        type: 'tool_result',
        tool: {
          name: part.tool_name || 'Tool',
          output: part.text || part.content || part.tool_output,
          error: part.tool_error,
        },
      });
      break;

    case 'thinking':
      emitEvent({
        ...base,
        id: `evt-${Date.now()}-think2`,
        type: 'thinking',
        content: part.text || part.content || part.thinking,
      });
      break;

    case 'update':
      if (part.todos) {
        const session = sessions.get(sessionId);
        if (session) session.todos = part.todos;
        emitEvent({
          ...base,
          id: `evt-${Date.now()}-todo`,
          type: 'todo_update',
          todos: part.todos,
        });
      }
      break;

    case 'diff':
    case 'file_write':
      emitEvent({
        ...base,
        id: `evt-${Date.now()}-diff`,
        type: 'diff',
        file: { path: part.path || '', diff: part.diff || part.new_content || '' },
      });
      break;

    case 'error':
      emitEvent({
        ...base,
        id: `evt-${Date.now()}-err2`,
        type: 'error',
        content: part.text || part.content || 'An error occurred',
      });
      break;

    default:
      // For unknown types, emit as a message if there's content
      if (part.text || part.content) {
        emitEvent({
          ...base,
          id: `evt-${Date.now()}-unknown`,
          type: 'message',
          content: `${part.type}: ${part.text || part.content}`,
        });
      }
  }
}

// ── Agents ─────────────────────────────────────────────────────────────────

// Fallback agents shown when the OpenCode server is unreachable. IDs must match
// REAL OpenCode agent names — a fabricated id (e.g. 'main') makes the server
// reject messages with 400 "agent not found". 'build' is opencode's default.
const FALLBACK_AGENTS: Agent[] = [
  {
    id: 'build',
    name: 'Main Agent',
    description: 'General-purpose coding assistant (default opencode agent)',
    model: '',
    icon: '🤖',
    color: '#3b9cff',
    status: 'idle',
  },
  {
    id: 'planner',
    name: 'Research Agent',
    description: 'Deep dive and analysis specialist',
    model: '',
    icon: '🔬',
    color: '#a78bfa',
    status: 'idle',
  },
  {
    id: 'uiux-agent',
    name: 'Frontend Agent',
    description: 'UI/UX and frontend specialist',
    model: '',
    icon: '🎨',
    color: '#34d399',
    status: 'idle',
  },
  {
    id: 'python-backend',
    name: 'Backend Agent',
    description: 'API and infrastructure specialist',
    model: '',
    icon: '⚙️',
    color: '#fbbf24',
    status: 'idle',
  },
];

let _agents: Agent[] = FALLBACK_AGENTS;

export async function refreshAgents(): Promise<Agent[]> {
  try {
    const resp = await fetch(`${apiBase()}/api/opencode/agents`);
    const data = (await resp.json()) as Array<{
      id: string;
      name: string;
      description?: string;
      icon?: string;
      color?: string;
    }>;
    if (Array.isArray(data) && data.length > 0) {
      _agents = data.map((a, i) => ({
        id: a.id,
        name: a.name,
        description: a.description || '',
        model: '',
        icon: a.icon || ['🤖', '🔬', '🎨', '⚙️'][i % 4],
        color: a.color || ['#3b9cff', '#a78bfa', '#34d399', '#fbbf24'][i % 4],
        status: 'idle' as const,
      }));
    }
  } catch {
    // Keep fallback agents
  }
  return _agents;
}

// ── Handoffs ────────────────────────────────────────────────────────────────

const handoffs = new Map<string, AgentHandoff>();

export function createHandoff(opts: {
  sourceAgentId: string;
  targetAgentId: string;
  task: string;
  context?: string;
  parentSessionId?: string;
  parentMessageId?: string;
}): AgentHandoff {
  const handoff: AgentHandoff = {
    id: `handoff-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    ...opts,
    status: 'queued',
    createdAt: new Date().toISOString(),
  };
  handoffs.set(handoff.id, handoff);

  // Emit as an event too
  emitEvent({
    id: `evt-${Date.now()}-handoff`,
    type: 'handoff',
    timestamp: Date.now(),
    sessionId: opts.parentSessionId || '',
    handoff,
  });

  return handoff;
}

export function getHandoffs(sessionId?: string): AgentHandoff[] {
  if (sessionId) {
    return Array.from(handoffs.values()).filter((h) => h.parentSessionId === sessionId);
  }
  return Array.from(handoffs.values());
}

export function updateHandoffStatus(id: string, status: AgentHandoff['status']): void {
  const h = handoffs.get(id);
  if (h) h.status = status;
}

// ── Load existing OpenCode sessions ────────────────────────────────────────

export async function syncSessions(): Promise<AgentSession[]> {
  const alive = await checkOpencodeHealth();
  if (!alive) return listSessions();

  try {
    const resp = await ocFetch('/sessions');
    const data = (await resp.json()) as Array<{
      id: string;
      title?: string;
      created_at?: number;
      updated_at?: number;
    }>;
    for (const s of data) {
      // Only import if not already in our local map
      const local = sessions.get(s.id);
      if (!local) {
        const session: AgentSession = {
          id: s.id,
          title: s.title || 'Untitled',
          agentId: 'main',
          createdAt: s.created_at || Date.now(),
          updatedAt: s.updated_at || Date.now(),
          messages: [],
          todos: [],
          status: 'idle',
          opencodeSessionId: s.id,
        };
        sessions.set(s.id, session);
      }
    }
  } catch {
    // Ignore — server may not be running yet
  }
  return listSessions();
}

// ── Polling for real-time updates ──────────────────────────────────────────

let _pollTimer: ReturnType<typeof setInterval> | null = null;

export function startPolling(refreshCallback: () => void): () => void {
  _pollTimer = setInterval(async () => {
    const alive = await checkOpencodeHealth();
    if (alive) {
      try {
        const resp = await ocFetch('/sessions/status');
        const statuses = (await resp.json()) as Record<string, { state?: string }>;
        for (const [sid, status] of Object.entries(statuses)) {
          const session = sessions.get(sid);
          if (session && status.state) {
            if (status.state === 'running') session.status = 'running';
            else if (status.state === 'completed') session.status = 'completed';
            else if (status.state === 'error') session.status = 'error';
          }
        }
        refreshCallback();
      } catch {
        /* ignore */
      }
    }
  }, 3000);
  return () => {
    if (_pollTimer) clearInterval(_pollTimer);
  };
}

// ── Public API ─────────────────────────────────────────────────────────────

export const OpenCodeAdapter = {
  // Health
  checkHealth: checkOpencodeHealth,
  pollHealth,
  // Sessions
  createSession,
  getSession,
  listSessions,
  deleteSession,
  syncSessions,
  // Events
  emitEvent,
  subscribeToEvents,
  // Actions
  sendMessage,
  stopStreaming,
  // Agents
  get agents() {
    return _agents;
  },
  refreshAgents,
  // Handoffs
  createHandoff,
  getHandoffs,
  updateHandoffStatus,
  // Polling
  startPolling,
};
