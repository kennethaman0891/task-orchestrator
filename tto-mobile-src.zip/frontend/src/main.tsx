import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles.css';

// ---- Diagnostic: capture errors so we can see why the page is blank ----
try {
  const origError = console.error;
  (console as any).error = (...args: any[]) => {
    try {
      fetch('http://127.0.0.1:8765/api/diag-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source: 'console.error', args: args.map(String) }),
      }).catch(() => {});
    } catch {}
    origError.apply(console, args);
  };
  window.addEventListener('error', (e) => {
    try {
      fetch('http://127.0.0.1:8765/api/diag-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source: 'window.error',
          message: e.message,
          stack: e.error?.stack || '',
        }),
      }).catch(() => {});
    } catch {}
  });
  window.addEventListener('unhandledrejection', (e) => {
    try {
      fetch('http://127.0.0.1:8765/api/diag-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source: 'unhandledrejection', reason: String(e.reason) }),
      }).catch(() => {});
    } catch {}
  });
  // Also log successful boot
  fetch('http://127.0.0.1:8765/api/diag-log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source: 'boot', message: 'main.tsx loaded, mounting React' }),
  }).catch(() => {});
} catch {}

// Nuke any legacy PWA service worker (removed in v1.5): it served stale cached
// CSS/JS that made the dashboard look broken after updates.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker
    .getRegistrations()
    .then((regs) => {
      regs.forEach((r) => r.unregister());
    })
    .catch(() => {});
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
