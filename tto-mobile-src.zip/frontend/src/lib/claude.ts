/**
 * Claude Code "always fresh" command normalizer (frontend twin of
 * backend/main.py::normalize_claude_fresh).
 *
 * Anywhere a full command line is dispatched toward a native (Rust) TTY in
 * Tauri mode, we must guarantee that launching Claude Code starts a FRESH
 * session — never resume an existing one. The backend normalizer only covers
 * commands that flow through FastAPI /api/terminals/{tty}/command and
 * /launch. The Tauri → Rust PTY path bypasses FastAPI entirely, so this helper
 * provides the same stripping at the frontend dispatch points.
 *
 * It is CONSERVATIVE: it only transforms commands that actually LAUNCH claude.
 * A command that merely mentions claude (e.g. `echo hello claude`,
 * `cat ~/claude/notes.md`) is left untouched.
 */

// Runners that can launch a CLI binary, where the launched tool is determined
// by the first non-runner argument (e.g. `npx claude`, `bunx claude`).
const CLAUDE_RUNNERS = new Set([
  'npx',
  'npx.cmd',
  'npmx',
  'bunx',
  'bun',
  'npm',
  'yarn',
  'pnpm',
  'node',
  'deno',
  'bunx.cmd',
  'npx-cli',
]);

// Flags that cause Claude Code to resume / fork an existing session. These are
// stripped so a launch ALWAYS starts a fresh session. Flags that take a value
// (session id / prompt) consume their following token too.
const CLAUDE_RESUME_FLAGS = new Set(['--continue', '-c', '--resume', '-r']);
// Value-less resume-related flags.
const CLAUDE_RESUME_SINGLE_FLAGS = new Set(['--fork-session', '--append-system-prompt']);

/** basename + lowercase, mirroring Python's os.path.basename(...).lower(). */
function baseName(p: string): string {
  // Handle both POSIX and Windows separators.
  const trimmed = p.replace(/[\\/]+$/, '');
  const last = Math.max(trimmed.lastIndexOf('/'), trimmed.lastIndexOf('\\'));
  return (last >= 0 ? trimmed.slice(last + 1) : trimmed).toLowerCase();
}

/**
 * Tokenize a shell command line with simple single/double-quote handling.
 * Falls back to a whitespace split on malformed quotes so we never throw.
 */
function shellSplit(command: string): string[] {
  const tokens: string[] = [];
  let cur = '';
  let quote: "'" | '"' | null = null;
  let started = false;
  for (let i = 0; i < command.length; i++) {
    const ch = command[i];
    if (quote) {
      if (ch === quote) {
        quote = null;
      } else {
        cur += ch;
      }
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      started = true;
      continue;
    }
    if (ch === ' ' || ch === '\t' || ch === '\n') {
      if (started) {
        tokens.push(cur);
        cur = '';
        started = false;
      }
      continue;
    }
    cur += ch;
    started = true;
  }
  if (started) tokens.push(cur);
  // If a quote was left open, tokens may be imperfect — still return what we
  // parsed; _isClaudeLaunch is conservative about it.
  return tokens;
}

/** Join tokens back into a shell command line (quote-aware when needed). */
function shellJoin(tokens: string[]): string {
  return tokens
    .map((t) => (/[\s'"]/.test(t) || t === '' ? `'${t.replace(/'/g, "'\\''")}'` : t))
    .join(' ');
}

/** Return true if the parsed token list actually launches Claude Code. */
function isClaudeLaunch(tokens: string[]): boolean {
  if (!tokens || tokens.length === 0) return false;
  const base = baseName(tokens[0]);
  if (base === 'claude' || base === 'claude.exe') return true;
  if (CLAUDE_RUNNERS.has(base)) {
    for (let i = 1; i < tokens.length; i++) {
      const low = tokens[i].toLowerCase();
      // Skip the runner's own flags/values conservatively.
      if (low.startsWith('-')) continue;
      if (low === 'exec' || low === 'dlx' || low === 'run' || low === '--' || low === 'x') continue;
      const argBase = baseName(tokens[i]);
      if (argBase === 'claude' || argBase === 'claude-code' || argBase.includes('claude')) {
        return true;
      }
      // First non-flag, non-runner token that isn't claude-linked => not a claude launch.
      return false;
    }
  }
  return false;
}

/**
 * If `command` launches Claude Code, return a version that ALWAYS starts a
 * fresh session (stripping/neutralizing any resume behavior). If the command
 * does not launch claude, return it unchanged.
 */
export function normalizeClaudeFresh(command: string): string {
  const trimmed = (command ?? '').trim();
  if (!trimmed) return command;

  const tokens = shellSplit(trimmed);
  if (tokens.length === 0) return command;
  if (!isClaudeLaunch(tokens)) return command;

  const out: string[] = [];
  let i = 0;
  const n = tokens.length;
  while (i < n) {
    const tok = tokens[i];
    const low = tok.toLowerCase();
    if (CLAUDE_RESUME_FLAGS.has(low)) {
      // Resume/continue flag. Consume a following value if present and not a flag.
      i += 1;
      if (i < n && tokens[i] && !tokens[i].startsWith('-')) i += 1; // drop session-id value
      continue;
    }
    if (CLAUDE_RESUME_SINGLE_FLAGS.has(low)) {
      i += 1;
      continue;
    }
    if (low.startsWith('--resume')) {
      // --resume=abc123 form.
      i += 1;
      continue;
    }
    out.push(tok);
    i += 1;
  }

  return shellJoin(out);
}
