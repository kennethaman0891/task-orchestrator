/**
 * Best-effort source-file resolution.
 *
 * Strategies (none guarantee a result; we never fabricate):
 *
 * 1. React DevTools fiber _debugSource (most reliable, dev only)
 * 2. Vite module URL hints from script tags in the document
 * 3. Class-name → filename convention mapping (hand-maintained)
 *
 * Returns `null` fields when nothing could be determined.
 */

import { getSourceFromFiber } from './react-finder';

// ── Hand-maintained mapping of common class-prefixes to TSX files ─────────────
// Updated manually as the app grows.  Only used when DevTools data is
// unavailable (production / no DevTools hook).
const CLASS_TO_SOURCE: Record<string, string> = {
  sidebar: 'src/components/Sidebar.tsx',
  wsbar: 'src/components/WorkspaceBar.tsx',
  stats: 'src/components/StatsBar.tsx',
  'terminal-pane': 'src/terminal/TerminalPane.tsx',
  'cmd-palette': 'src/components/CommandPalette.tsx',
  'settings-modal': 'src/components/SettingsModal.tsx',
  toast: 'src/components/Toast.tsx',
  'kanban-board': 'src/components/KanbanBoard.tsx',
  'code-editor': 'src/components/CodeEditor.tsx',
  'file-browser': 'src/components/FileBrowser.tsx',
  'workspace-wizard': 'src/components/WorkspaceWizard.tsx',
  'split-view': 'src/components/SplitView.tsx',
};

/**
 * Try to resolve a source file from the given DOM element.
 * Always returns `exact: false` when falling back to the class map.
 */
export function resolveSourceFile(el: HTMLElement): {
  sourceFile?: string;
  sourceLine?: number;
  sourceColumn?: number;
  exact: boolean;
} {
  // Priority 1: React DevTools fiber source
  const fiberResult = getSourceFromFiber(el);
  if (fiberResult.exact && fiberResult.sourceFile) {
    return fiberResult;
  }

  // Priority 2: Look for Vite data attributes on ancestors
  let ancestor: HTMLElement | null = el;
  while (ancestor) {
    const viteModuleId = ancestor.getAttribute('data-vite-module-id');
    if (viteModuleId) {
      const file = viteModuleId.replace(/.*\/src\//, 'src/');
      return { sourceFile: file, exact: false };
    }
    ancestor = ancestor.parentElement;
  }

  // Priority 3: Class-name convention map
  const classes = (el.className as string | undefined)?.split(/\s+/) || [];
  for (const cls of classes) {
    const mapped = CLASS_TO_SOURCE[cls];
    if (mapped) return { sourceFile: mapped, exact: false };
  }

  return { exact: false };
}

/**
 * Check whether source maps are likely available in the current build.
 */
export function isSourceMapAvailable(): boolean {
  if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) return true;
  const scripts = document.querySelectorAll<HTMLScriptElement>('script[src$=".js"]');
  for (const script of scripts) {
    if (
      script.src.includes('.js.map') ||
      (script as unknown as Record<string, unknown>)['data-srcmap'] === 'true'
    ) {
      return true;
    }
  }
  return false;
}
