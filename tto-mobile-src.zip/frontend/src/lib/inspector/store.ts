/**
 * Inspector store — module-scoped singleton (no React context needed).
 *
 * All components read/write through these functions.  Annotations are
 * persisted to localStorage under `tto-inspector-annotations` so they survive
 * a page reload but NOT an app restart (intentional: inspection is session-only
 * unless the user pins them via the annotation panel).
 */

import type { Annotation, InspectedElement, InspectorMode } from '../../types';

const STORAGE_KEY = 'tto-inspector-annotations';

// ── Public state ──────────────────────────────────────────────────────────────

let mode: InspectorMode = 'normal';
let hoveredEl: InspectedElement | null = null;
let selectedEl: InspectedElement | null = null;
let annotations: Annotation[] = [];
let listeners: Set<() => void> = new Set();

// ── Persisted annotations ─────────────────────────────────────────────────────

function loadAnnotations(): Annotation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Annotation[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveAnnotations() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(annotations));
  } catch {
    /* storage full or private mode — ignore */
  }
}

// ── Dispatch ──────────────────────────────────────────────────────────────────

type Action =
  | { type: 'SET_MODE'; mode: InspectorMode }
  | { type: 'SET_HOVERED'; element: InspectedElement | null }
  | { type: 'SELECT_ELEMENT'; element: InspectedElement }
  | { type: 'CLEAR_SELECTION' }
  | { type: 'ADD_ANNOTATION'; annotation: Annotation }
  | { type: 'EDIT_ANNOTATION'; id: string; comment: string }
  | { type: 'REMOVE_ANNOTATION'; id: string }
  | { type: 'CLEAR_ANNOTATIONS' }
  | { type: 'SYNC'; annotations: Annotation[] };

function dispatch(action: Action) {
  switch (action.type) {
    case 'SET_MODE':
      mode = action.mode;
      break;
    case 'SET_HOVERED':
      hoveredEl = action.element;
      break;
    case 'SELECT_ELEMENT':
      selectedEl = action.element;
      mode = 'selected';
      break;
    case 'CLEAR_SELECTION':
      selectedEl = null;
      mode = 'hover';
      break;
    case 'ADD_ANNOTATION':
      annotations = [...annotations, action.annotation];
      saveAnnotations();
      break;
    case 'EDIT_ANNOTATION':
      annotations = annotations.map((a) =>
        a.id === action.id ? { ...a, userComment: action.comment } : a,
      );
      saveAnnotations();
      break;
    case 'REMOVE_ANNOTATION':
      annotations = annotations.filter((a) => a.id !== action.id);
      saveAnnotations();
      break;
    case 'CLEAR_ANNOTATIONS':
      annotations = [];
      saveAnnotations();
      break;
    case 'SYNC':
      annotations = action.annotations;
      break;
  }
  notifyListeners();
}

function notifyListeners() {
  for (const fn of listeners) fn();
}

// ── Getters (called by components each render) ────────────────────────────────

export function getStore() {
  return { mode, hoveredEl, selectedEl, annotations };
}

// ── Action creators ───────────────────────────────────────────────────────────

export const inspectorActions = {
  setMode: (m: InspectorMode) => dispatch({ type: 'SET_MODE', mode: m }),
  setHovered: (el: InspectedElement | null) => dispatch({ type: 'SET_HOVERED', element: el }),
  selectElement: (el: InspectedElement) => dispatch({ type: 'SELECT_ELEMENT', element: el }),
  clearSelection: () => dispatch({ type: 'CLEAR_SELECTION' }),
  addAnnotation: (ann: Annotation) => dispatch({ type: 'ADD_ANNOTATION', annotation: ann }),
  editAnnotation: (id: string, comment: string) =>
    dispatch({ type: 'EDIT_ANNOTATION', id, comment }),
  removeAnnotation: (id: string) => dispatch({ type: 'REMOVE_ANNOTATION', id }),
  clearAnnotations: () => dispatch({ type: 'CLEAR_ANNOTATIONS' }),
  syncAnnotations: (anns: Annotation[]) => dispatch({ type: 'SYNC', annotations: anns }),
};

// ── Initialise from storage on import ─────────────────────────────────────────

annotations = loadAnnotations();
