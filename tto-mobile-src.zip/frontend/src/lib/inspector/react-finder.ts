/**
 * React fiber tree inspector.
 *
 * Walks backwards from a DOM node through the React fiber chain to discover
 * the component displayName.  Works with React 18+ DevTools hooks when
 * present (development builds).  Returns null gracefully when DevTools is
 * absent (production builds).
 *
 * NEVER fabricates a component name — returns null when unknown.
 */

// ── Types borrowed from React internals (safe to reference, not mutate) ───────

interface FiberNode {
  tag: number;
  type: unknown;
  elementType: unknown;
  key: string | null;
  stateNode: unknown;
  pendingProps: Record<string, unknown>;
  memoizedProps: Record<string, unknown>;
  child?: FiberNode | null;
  sibling?: FiberNode | null;
  return?: FiberNode | null;
  debugContext?: unknown;
  _debugOwner?: FiberNode | null;
  _debugSource?: { fileName?: string; lineNumber?: number; columnNumber?: number } | null;
}

interface ReactDevToolsHook {
  overrideProps?: (source: unknown, props: Record<string, unknown>) => void;
  rendererPackageName?: string;
  overrides?: {
    getFiber?: (hostInstance: HTMLElement) => FiberNode | null;
  };
  fibers?: Map<HTMLElement, FiberNode>;
}

declare global {
  interface Window {
    __REACT_DEVTOOLS_GLOBAL_HOOK__?: ReactDevToolsHook & {
      renderers?: Map<number, { getFiberNow?: (el: HTMLElement) => FiberNode | null }>;
    };
    __REACT_DEVTOOLS_COMPONENT_STACK_ACCESS_ENABLED__?: boolean;
  }
}

// ── Resolve a DOM element → React fiber ───────────────────────────────────────

function getFiber(el: HTMLElement): FiberNode | null {
  const hook = window.__REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (hook?.overrides?.getFiber) {
    try {
      const fiber = hook.overrides.getFiber(el);
      if (fiber) return fiber;
    } catch {
      /* hook may throw in locked-down environments */
    }
  }

  if (hook?.fibers instanceof Map) {
    const fiber = hook.fibers.get(el);
    if (fiber) return fiber;
  }

  return fallbackGetFiber(el);
}

function fallbackGetFiber(el: HTMLElement): FiberNode | null {
  // React attaches __reactFiber* or _reactInternals* to host nodes.
  for (const key of Object.keys(el)) {
    if (
      (key.startsWith('__react') || key.startsWith('_react')) &&
      key !== 'innerHTML' &&
      key !== 'outerHTML'
    ) {
      const val = (el as unknown as Record<string, unknown>)[key];
      if (val && typeof val === 'object' && 'tag' in (val as object)) {
        return val as FiberNode;
      }
    }
  }
  return null;
}

// ── Extract component name from a fiber ───────────────────────────────────────

export function findComponentName(el: HTMLElement): string | null {
  const fiber = getFiber(el);
  if (!fiber) return null;

  let current: FiberNode | undefined = fiber;
  while (current) {
    const type = current.type;
    if (typeof type === 'function') {
      return type.name || null;
    }
    if (typeof type === 'string') {
      break;
    }
    current = current.return ?? undefined;
  }

  const stateNode = fiber.stateNode;
  if (stateNode && typeof stateNode === 'object' && 'constructor' in stateNode) {
    const ctor = (stateNode as { constructor?: { name?: string } }).constructor;
    if (ctor?.name) return ctor.name;
  }

  return null;
}

/**
 * Best-effort source file + line from the fiber's debug metadata.
 * Only populated when React DevTools is active (dev builds).
 */
export function getSourceFromFiber(el: HTMLElement): {
  sourceFile?: string;
  sourceLine?: number;
  sourceColumn?: number;
  exact: boolean;
} {
  const fiber = getFiber(el);
  if (!fiber) return { exact: false };

  let current: FiberNode | undefined = fiber;
  while (current) {
    if (current._debugSource?.fileName) {
      return {
        sourceFile: current._debugSource.fileName,
        sourceLine: current._debugSource.lineNumber,
        sourceColumn: current._debugSource.columnNumber,
        exact: true,
      };
    }
    current = current.return ?? undefined;
  }

  const props = fiber.memoizedProps;
  if (props?.src && typeof props.src === 'string') {
    return { sourceFile: props.src, exact: false };
  }

  return { exact: false };
}

/**
 * Human-readable label suitable for the tooltip:
 * "WorkspaceButton" or "button" or "div.sidebar".
 */
export function getElementLabel(el: HTMLElement): string {
  const componentName = findComponentName(el);
  if (componentName) return componentName;

  const tag = el.tagName.toLowerCase();
  const cls = (el.className as string | undefined)?.trim();
  if (cls) {
    const firstClass = cls.split(/\s+/)[0];
    if (firstClass && !firstClass.startsWith('css-') && !firstClass.startsWith('sc-')) {
      return `${tag}.${firstClass}`;
    }
  }
  return tag;
}
