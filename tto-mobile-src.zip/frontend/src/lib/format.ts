import type { TerminalEntry } from '../types';

/** Last path segment — works with both POSIX (/foo/bar) and Windows (C:\\foo\\bar) separators. */
export function baseName(p: string): string {
  if (!p) return '';
  const trimmed = p.replace(/[\\/]+$/, '');
  // Find the last separator (either / or \\)
  const lastSlash = Math.max(trimmed.lastIndexOf('/'), trimmed.lastIndexOf('\\'));
  return lastSlash >= 0 ? trimmed.slice(lastSlash + 1) : trimmed;
}

/** Platform-aware modifier key label: "⌘" on macOS, "Ctrl" elsewhere. */
export function modifierLabel(): string {
  return navigator.platform.toLowerCase().includes('mac') ? '⌘' : 'Ctrl';
}

/** Split a path into segments regardless of separator style. */
export function splitPath(p: string): string[] {
  if (!p) return [];
  return p.split(/[\\/]/).filter(Boolean);
}

export function formatTime(ts?: number | null): string {
  if (!ts) return '—';
  return new Date(ts * 1000).toLocaleString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function formatTokens(n: number): string {
  if (!n) return '0';
  if (n >= 1000000000) return (n / 1000000000).toFixed(2).replace(/\.?0+$/, '') + 'B';
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

export function cleanModel(model: string): string {
  return model.replace(/\{"id":"([^"]+)".*/, '$1');
}

/**
 * Shell-quote a single token for POSIX shells (bash, zsh, sh, dash).
 *
 * The result is safe to splice into a `cmd` string that will be typed into
 * a terminal. Uses single-quotes and escapes any embedded single quotes
 * via the standard `'\''` trick — so the token is treated as a literal
 * value by the shell: no metacharacters (`;`, `&`, `|`, `$`, `` ` ``, `*`,
 * `?`, `~`, redirects, etc.) inside the token can break out of quoting.
 *
 * Use this for anything from user/UI/API input that gets concatenated into
 * a command string typed into a terminal — especially model keys, file
 * paths, project paths, and terminal commands.
 */
export function shellQuote(token: string): string {
  if (token == null) return "''";
  const s = String(token);
  if (s === '') return "''";
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

/**
 * Reject any model key that contains shell metacharacters. The backend
 * also re-validates (`_safe_model`); this is a defence-in-depth filter so
 * a tampered UI value cannot become `` opencode -m <weird> `` and inject
 * a second command when typed into a terminal.
 *
 * Allowed: letters, digits, slash, dot, dash, underscore, colon, plus.
 * (Provider / model key chars: `openai/gpt-4o`, `opencode/deepseek-v4`,
 *  `claude-3-5-sonnet:free`, `gemini-2.5_pro+exp`, etc.)
 */
export function isSafeModelKey(model: string): boolean {
  if (!model) return false;
  return /^[A-Za-z0-9_./:+\-]{1,128}$/.test(model) && !model.includes('..');
}

export function isClosed(t: TerminalEntry): boolean {
  return (t.agent || '').includes('closed') || t.is_live === false;
}
