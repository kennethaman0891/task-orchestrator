export type TemplateKey = 1 | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16;

/**
 * Grid arrangement mode — presentation only, never touches sessions.
 * - `auto`    (default) columns adapt to viewport + terminal count
 * - `grid`    legacy template-designed fixed columns (backward compat)
 * - `compact` smaller minimum terminals so more fit on screen
 * - `large`   fewer, larger terminals
 */
export type GridMode = 'auto' | 'grid' | 'compact' | 'large';

export const GRID_MODES: { key: GridMode; label: string; hint: string }[] = [
  { key: 'auto', label: 'Auto', hint: 'Columns adapt to viewport + terminal count' },
  { key: 'grid', label: 'Grid', hint: 'Template-designed fixed columns' },
  { key: 'compact', label: 'Compact', hint: 'Smaller terminals, more on screen' },
  { key: 'large', label: 'Large', hint: 'Fewer, larger terminals' },
];

/** Gap between grid cells (px) — kept in sync with .ws-grid. */
export const GRID_GAP = 8;

export interface GridMins {
  minW: number;
  minH: number;
}

/**
 * Minimum usable terminal pane size per layout mode.
 * Once the viewport can't fit more panes at this size the workspace SCROLLS
 * instead of compressing terminals below a usable canvas.
 */
export function gridMins(mode: GridMode): GridMins {
  switch (mode) {
    case 'compact':
      return { minW: 260, minH: 160 };
    case 'large':
      return { minW: 480, minH: 300 };
    case 'grid':
      return { minW: MIN_PANE_W, minH: MIN_PANE_H };
    default:
      return { minW: 320, minH: 220 };
  }
}

/** Hard cap on grid columns per mode (legacy maxColumns overrides). */
const GRID_CAPS: Record<GridMode, number> = {
  auto: 5,
  grid: 8,
  compact: 6,
  large: 4,
};

export interface WorkspacePane {
  id: string;
  tty: string | null;
}

export interface Workspace {
  id: string;
  name: string;
  color: string;
  template: TemplateKey;
  panes: WorkspacePane[];
  projectPath?: string;
  command?: string;
  /** Auto-expand a pane to full workspace when a full-screen CLI starts. */
  autoExpandTui?: boolean;
  /**
   * Maximum number of grid columns (0 = auto / unlimited, 2 = BridgeSpace
   * style). When set, `computeGridLayout` clamps cols and lets the grid
   * scroll vertically for the remaining rows.
   */
  maxColumns?: number;
  /** Grid arrangement mode (see GridMode). Defaults to 'auto'. */
  layoutMode?: GridMode;
  /**
   * Weighted grid tracks (default all 1 = equal columns/rows).
   * Enlarging a track's weight makes the neighbors shrink proportionally
   * (CSS `fr` rebalance); used by the proportional expand + drag-resize.
   * Sized to the CURRENT layout cols/rows; reset by setTemplate().
   */
  trackCols?: number[];
  trackRows?: number[];
}

/**
 * Minimum pane track sizes (px) so every pane keeps a usable terminal canvas.
 * Kept LOW so ALL templates (1–16 terminals) fit inside a normal window with
 * `fr` slack — otherwise drag-resize / proportional expand have no room to
 * work (the grid scrolls instead). xterm's FitAddon scales fonts to the pane,
 * so smaller default panes are fine: pick a pane → ⤢ Expand / drag to grow it.
 */
export const MIN_PANE_W = 180;
export const MIN_PANE_H = 110;

export const TEMPLATES: Record<TemplateKey, { label: string; cols: number }> = {
  1: { label: 'Single', cols: 1 },
  2: { label: 'Split', cols: 2 },
  4: { label: 'Quad', cols: 2 },
  6: { label: 'Six', cols: 3 },
  8: { label: 'Eight', cols: 4 },
  10: { label: 'Ten', cols: 5 },
  12: { label: 'Twelve', cols: 4 },
  14: { label: 'Fourteen', cols: 7 },
  16: { label: 'Sixteen', cols: 4 },
};

/** Grid columns for a terminal count — falls back to a sensible layout for custom counts. */
export function templateCols(t: number): number {
  return TEMPLATES[t as TemplateKey]?.cols ?? Math.max(1, Math.min(4, Math.ceil(Math.sqrt(t))));
}

/** Label for a terminal count — falls back to "Custom (N)". */
export function templateLabel(t: number): string {
  return TEMPLATES[t as TemplateKey]?.label ?? `Custom (${t})`;
}

export const TAB_COLORS = [
  '#4a9eff',
  '#4ade80',
  '#facc15',
  '#f87171',
  '#c084fc',
  '#ff4fd8',
  '#00e5ff',
  '#ffa500',
];

export interface ThemeDef {
  name: string;
  dark: boolean;
  colors: Record<string, string>;
}

export const THEMES: ThemeDef[] = [
  {
    name: 'Void',
    dark: true,
    colors: {
      '--bg': '#000000',
      '--panel': '#0a0a0a',
      '--border': '#1e1e1e',
      '--text': '#e8e8e8',
      '--muted': '#a0a0a0',
      '--accent': '#4a9eff',
      '--green': '#4ade80',
      '--yellow': '#facc15',
      '--red': '#f87171',
      '--purple': '#c084fc',
    },
  },
  {
    name: 'Neon Tokyo',
    dark: true,
    colors: {
      '--bg': '#0d0221',
      '--panel': '#150a33',
      '--border': '#3b1f6e',
      '--text': '#f0eaff',
      '--muted': '#a99ec7',
      '--accent': '#00e5ff',
      '--green': '#00ff88',
      '--yellow': '#ffe600',
      '--red': '#ff2e88',
      '--purple': '#b56bff',
    },
  },
  {
    name: 'Synthwave',
    dark: true,
    colors: {
      '--bg': '#120d2b',
      '--panel': '#1a1233',
      '--border': '#3a2a6a',
      '--text': '#ffe8ff',
      '--muted': '#b0a0c8',
      '--accent': '#ff4fd8',
      '--green': '#2dff9a',
      '--yellow': '#ffe66d',
      '--red': '#ff3860',
      '--purple': '#7f5af0',
    },
  },
  {
    name: 'Dracula',
    dark: true,
    colors: {
      '--bg': '#282a36',
      '--panel': '#21222c',
      '--border': '#44475a',
      '--text': '#f8f8f2',
      '--muted': '#a9a9c4',
      '--accent': '#6272a4',
      '--green': '#50fa7b',
      '--yellow': '#f1fa8c',
      '--red': '#ff5555',
      '--purple': '#bd93f9',
    },
  },
  {
    name: 'Carbon',
    dark: true,
    colors: {
      '--bg': '#1c1c1c',
      '--panel': '#232323',
      '--border': '#3a3a3a',
      '--text': '#f0f0f0',
      '--muted': '#9a9a9a',
      '--accent': '#ff6c5c',
      '--green': '#5ff28e',
      '--yellow': '#ffd60a',
      '--red': '#ff3b30',
      '--purple': '#bf5af2',
    },
  },
  {
    name: 'Obsidian',
    dark: true,
    colors: {
      '--bg': '#1a1b26',
      '--panel': '#1f2130',
      '--border': '#3b4261',
      '--text': '#c0caf5',
      '--muted': '#7aa2f7',
      '--accent': '#89b4fa',
      '--green': '#9ece6a',
      '--yellow': '#e0af68',
      '--red': '#f7768e',
      '--purple': '#bb9af7',
    },
  },
  {
    name: 'Paper',
    dark: false,
    colors: {
      '--bg': '#ffffff',
      '--panel': '#f6f6f4',
      '--border': '#e0e0dd',
      '--text': '#1a1a1a',
      '--muted': '#666664',
      '--accent': '#2563eb',
      '--green': '#16a34a',
      '--yellow': '#d97706',
      '--red': '#dc2626',
      '--purple': '#7c3aed',
    },
  },
];

const WS_KEY = 'tto-workspaces';
const ACTIVE_KEY = 'tto-active-workspace';
const THEME_KEY = 'tto-theme';

export function newWorkspace(name?: string, template: TemplateKey = 4): Workspace {
  const id = 'ws-' + Math.random().toString(36).slice(2, 8);
  const panes: WorkspacePane[] = Array.from({ length: template }, (_, i) => ({
    id: `p-${id}-${i}`,
    tty: null,
  }));
  const cols = templateCols(template);
  const rows = Math.max(1, Math.ceil(template / cols));
  return {
    id,
    name: name || `Workspace ${template === 4 ? 'Quad' : template}`,
    color: TAB_COLORS[Math.floor(Math.random() * TAB_COLORS.length)],
    template,
    panes,
    autoExpandTui: true,
    layoutMode: 'auto',
    trackCols: Array.from({ length: cols }, () => 1),
    trackRows: Array.from({ length: rows }, () => 1),
  };
}

export function loadWorkspaces(): Workspace[] {
  try {
    const raw = localStorage.getItem(WS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Workspace[];
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    /* ignore */
  }
  return [newWorkspace()];
}

export function saveWorkspaces(ws: Workspace[]) {
  try {
    localStorage.setItem(WS_KEY, JSON.stringify(ws));
  } catch {
    /* ignore */
  }
}

export function loadActiveWs(): string {
  try {
    return localStorage.getItem(ACTIVE_KEY) || '';
  } catch {
    return '';
  }
}

export function saveActiveWs(id: string) {
  try {
    localStorage.setItem(ACTIVE_KEY, id);
  } catch {
    /* ignore */
  }
}

export function loadTheme(): string {
  try {
    return localStorage.getItem(THEME_KEY) || 'Void';
  } catch {
    return 'Void';
  }
}

export function saveTheme(name: string) {
  try {
    localStorage.setItem(THEME_KEY, name);
  } catch {
    /* ignore */
  }
}

export function applyTheme(name: string) {
  const t = THEMES.find((x) => x.name === name) || THEMES[0];
  const root = document.documentElement;
  for (const [k, v] of Object.entries(t.colors)) root.style.setProperty(k, v);
  root.style.colorScheme = t.dark ? 'dark' : 'light';
}

/* ------------------------------------------------------------------ */
/* Grid layout — template-driven, stable                               */
/* ------------------------------------------------------------------ */

export interface GridLayout {
  cols: number;
  rows: number;
}

/**
 * Return the grid layout for a workspace template.
 *
 * The grid dimensions are FIXED by the template — e.g. Eight (8 terminals,
 * 4 cols) always renders a 4×2 grid. Terminal count NEVER changes row or
 * column tracks. Adding T5 fills the pre-existing row-2 cell without
 * touching row-1 dimensions.
 *
 * Columns expand up to the template's design: 1 terminal → 1 col (full
 * width), 2 → 2 cols, … templateCols → full grid width. Once the first
 * row is full (count > cols), extra terminals flow into the second row.
 *
 * Grid template: repeat(cols, minmax(0, 1fr)) × repeat(rows, minmax(0, 1fr))
 *
 * @returns { cols, rows } — caller builds the CSS grid template inline.
 */
export function computeGridLayout(
  _activeCount: number,
  templateCols: number,
  templateSize: number,
  maxColumns?: number,
): GridLayout {
  // Clamp columns to the workspace's maxColumns setting (0 = auto).
  // When clamped, extra columns become rows — the grid scrolls vertically
  // instead of compressing panes horizontally.
  const cols = maxColumns && maxColumns > 0 ? Math.min(templateCols, maxColumns) : templateCols;

  const rows = Math.max(1, Math.ceil(templateSize / cols));

  return { cols, rows };
}

/* ------------------------------------------------------------------ */
/* Responsive grid engine — terminal count NEVER breaks the UI         */
/* ------------------------------------------------------------------ */

export interface ResponsiveLayout extends GridLayout {
  minW: number;
  minH: number;
}

export interface ResponsiveLayoutOpts {
  /** Number of terminals (panes) in the workspace. */
  count: number;
  /** Available workspace width in px (0 → falls back to window.innerWidth). */
  width: number;
  mode: GridMode;
  /** Cell gap in px (see GRID_GAP). */
  gap: number;
  /** Legacy manual column override (0 = engine decides). */
  maxColumns?: number;
  /** Template-design columns (used only by the legacy `grid` mode). */
  templateCols?: number;
}

/**
 * Pick the grid arrangement from the VIEWPORT + terminal count, not from a
 * static template.
 *
 * Core invariant: `cols * (minW + gap) <= width` — so columns NEVER exceed
 * the available width and the workspace NEVER gains horizontal overflow.
 * When `rows * minH` exceeds the height the grid just SCROLLS vertically —
 * panes are never compressed below their usable minimum.
 *
 *   auto    → floor(width / minW) columns, capped (5 default)
 *   compact → same math with tighter minimums (fits more on screen)
 *   large   → same math with bigger minimums (fewer, larger terminals)
 *   grid    → legacy template-designed columns (backward compat)
 */
export function computeResponsiveLayout(opts: ResponsiveLayoutOpts): ResponsiveLayout {
  const { count, mode, gap, maxColumns = 0, templateCols = 4 } = opts;
  const width = opts.width > 0 ? opts.width : window.innerWidth;

  if (mode === 'grid') {
    const cols = maxColumns > 0 ? Math.min(templateCols, maxColumns) : templateCols;
    const rows = Math.max(1, Math.ceil(count / cols));
    const { minW, minH } = gridMins('grid');
    return { cols, rows, minW, minH };
  }

  const { minW, minH } = gridMins(mode);
  // Columns that fit at the minimum size — no horizontal overflow by design.
  const fitCols = Math.max(1, Math.floor((width + gap) / (minW + gap)));
  const cap = maxColumns > 0 ? maxColumns : GRID_CAPS[mode];
  // Fewer panes than columns → collapse so 1 terminal spans the full workspace
  // (and 2 sit side by side, 3 in a row), matching the reference layouts.
  const cols = Math.max(1, Math.min(fitCols, cap, count));
  // Rows flow naturally; the workspace scrolls when they exceed the height.
  const rows = Math.max(1, Math.ceil(count / cols));

  return { cols, rows, minW, minH };
}
