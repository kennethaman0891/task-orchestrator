import { useCallback, useEffect, useRef, useState } from 'react';
import { TerminalManager } from './TerminalManager';
import { isTauri } from './channels';
import { normalizeClaudeFresh } from '../lib/claude';

/** Shared drop-routing flags (set by TerminalInput, read by App's drop handler). */
declare global {
  interface Window {
    /** True while the cursor is over this command line — App routes OS drops here. */
    __tto_dragOverTerminalInput?: boolean;
    /** Insert shell-escaped paths into the focused command line. */
    __tto_insertIntoTerminalInput?: (paths: string[]) => void;
  }
}

/** Shell-escape an absolute path for use in a shell command line. */
function shellQuote(p: string): string {
  return `'${p.replace(/'/g, `'\\''`)}'`;
}

/**
 * Always-visible prompt bar at the bottom of the focused terminal (workspace
 * view). Type a command + Enter to send it to the PTY — no need to find xterm
 * focus. Also accepts file drops: dragging a file from the File Browser (or
 * the OS) onto this field types its shell-quoted path into the line so the
 * user can see/adjust it before pressing Enter (it does NOT auto-execute).
 *
 * A 🎤 voice button (Web Speech API) lets you dictate the command instead of
 * typing it — the transcript lands in the field and you press Enter to send.
 */
export function TerminalInput({ sessionId }: { sessionId: string }) {
  const [val, setVal] = useState('');
  const ref = useRef<HTMLInputElement>(null);

  // ── Voice input (Web Speech API; works in the Tauri webview too) ──
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const stopListening = useCallback(() => {
    try {
      recognitionRef.current?.stop?.();
    } catch {
      /* noop */
    }
    recognitionRef.current = null;
    setListening(false);
  }, []);

  const toggleVoice = useCallback(() => {
    if (listening) {
      stopListening();
      return;
    }
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      window.alert('Voice input is not supported in this browser');
      return;
    }
    try {
      const rec = new SR();
      rec.lang = 'en-US';
      rec.interimResults = true;
      rec.continuous = true;
      rec.onresult = (e: any) => {
        let text = '';
        for (let i = 0; i < e.results.length; i++) {
          text += e.results[i][0]?.transcript ?? '';
        }
        if (text) setVal(text.trim());
      };
      rec.onend = () => setListening(false);
      rec.onerror = () => setListening(false);
      recognitionRef.current = rec;
      rec.start();
      setListening(true);
    } catch {
      setListening(false);
    }
  }, [listening, stopListening]);

  // Stop listening when the input unmounts.
  useEffect(() => {
    return () => stopListening();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const send = useCallback(() => {
    if (!val || !isTauri()) return;
    // Append \r (Enter) — same as typing in a real terminal.
    // Guarantee Claude Code launches a fresh session (strip resume) before
    // the full line reaches the native PTY (which bypasses the backend
    // normalizer in Tauri mode).
    const normalized = normalizeClaudeFresh(val + '\r');
    TerminalManager.write(sessionId, normalized);
    setVal('');
    ref.current?.focus();
  }, [val, sessionId]);

  /** Pull the dropped path out of whatever drag format the source used. */
  const extractDropPaths = useCallback((dt: DataTransfer): string[] => {
    // Sidebar / File Browser drags use these two formats with the absolute path.
    const custom = dt.getData('application/x-tto-file');
    if (custom) return [custom.trim()];
    const text = dt.getData('text/plain');
    if (text) {
      // URLs get dropped as text/plain too; only take plain filesystem paths.
      if (!/^[a-z]+:\/\//i.test(text.trim())) return [text.trim()];
    }
    // OS file drags (browser/webview fallback where dataTransfer.files is set).
    const files = Array.from(dt.files || [])
      .map((f: any) => f.path || f.name)
      .filter(Boolean);
    return files;
  }, []);

  /** Append shell-quoted paths (joined with spaces) to the field. */
  const insertPaths = useCallback((paths: string[]) => {
    if (paths.length === 0) return;
    const escaped = paths.map(shellQuote).join(' ');
    setVal((prev) => (prev.endsWith(' ') || prev === '' ? prev + escaped : prev + ' ' + escaped));
  }, []);

  const markDragActive = useCallback((active: boolean) => {
    if (typeof window !== 'undefined') window.__tto_dragOverTerminalInput = active;
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLFormElement>) => {
      e.preventDefault();
      e.stopPropagation();
      markDragActive(false);
      insertPaths(extractDropPaths(e.dataTransfer));
      ref.current?.focus();
    },
    [extractDropPaths, insertPaths, markDragActive],
  );

  const handleDragOver = useCallback(
    (e: React.DragEvent<HTMLFormElement>) => {
      // Allow the drop (and keep the cursor a copy rather than 'no-drop').
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
      markDragActive(true);
    },
    [markDragActive],
  );

  const handleDragLeave = useCallback(() => markDragActive(false), [markDragActive]);

  // Expose the shared "insert into the focused command line" function so App's
  // window-level / tauri://drag-drop handler can route OS file drops here.
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.__tto_insertIntoTerminalInput = insertPaths;
    }
    return () => markDragActive(false);
  }, [insertPaths, markDragActive]);

  if (!isTauri()) return null;

  return (
    <form
      className={`ws-input${listening ? ' listening' : ''}`}
      onSubmit={(e) => {
        e.preventDefault();
        send();
      }}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
    >
      <span className="ws-input-prompt">❯</span>
      <input
        ref={ref}
        className="ws-input-field"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        placeholder={
          listening ? 'Listening… speak your command' : 'type a command… (or drop a file in)'
        }
        spellCheck={false}
        autoComplete="off"
      />
      <button
        type="button"
        className={`ws-input-voice${listening ? ' listening' : ''}`}
        onClick={toggleVoice}
        title={listening ? 'Stop voice input' : 'Speak a command instead of typing'}
        aria-label={listening ? 'Stop voice input' : 'Voice command input'}
      >
        {listening ? '🔴' : '🎤'}
      </button>
    </form>
  );
}
