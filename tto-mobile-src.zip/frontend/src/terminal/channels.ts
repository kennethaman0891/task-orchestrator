// Tauri IPC channel layer (spec §36).
// Terminal DATA flows through binary channels (never React state); metadata
// flows through cheap command invocations.

import { invoke, Channel } from '@tauri-apps/api/core';
import type { SessionDiag, SessionMeta } from './types';

/** True when running inside the Tauri webview. */
export const isTauri = (): boolean =>
  typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

export const tauri = {
  // --- terminal lifecycle ---
  create(cwd?: string, workspaceId?: string, cols = 120, rows = 30): Promise<SessionMeta> {
    return invoke<SessionMeta>('terminal_create', { cwd, workspaceId, cols, rows });
  },
  attach(id: string, onOutput: Channel<number[]>, onExit: Channel<unknown>): Promise<void> {
    return invoke<void>('terminal_attach', { id, onOutput, onExit });
  },
  detach(id: string): Promise<void> {
    return invoke<void>('terminal_detach', { id });
  },
  /** Return the full persistent scrollback so a recreated renderer can replay it. */
  getScrollback(id: string): Promise<number[]> {
    return invoke<number[]>('terminal_get_scrollback', { id });
  },
  list(): Promise<SessionMeta[]> {
    return invoke<SessionMeta[]>('terminal_list');
  },
  close(id: string): Promise<void> {
    return invoke<void>('terminal_close', { id });
  },
  restart(id: string): Promise<void> {
    return invoke<void>('terminal_restart', { id });
  },

  // --- input / control ---
  write(id: string, data: Uint8Array): Promise<void> {
    return invoke<void>('terminal_write', { id, data: Array.from(data) });
  },
  sendCommand(id: string, command: string): Promise<void> {
    return invoke<void>('terminal_send_command', { id, command });
  },
  /** Shell-escape and inject dropped file paths into the terminal PTY. */
  dropFiles(id: string, paths: string[]): Promise<void> {
    return invoke<void>('terminal_drop_files', { id, paths });
  },
  resize(id: string, cols: number, rows: number): Promise<void> {
    return invoke<void>('terminal_resize', { id, cols, rows });
  },

  // --- scheduler hints (spec §10) ---
  setTitle(id: string, title: string): Promise<void> {
    return invoke<void>('terminal_set_title', { id, title });
  },
  setTui(id: string, active: boolean): Promise<void> {
    return invoke<void>('terminal_set_tui', { id, active });
  },
  setFocus(id: string, focused: boolean): Promise<void> {
    return invoke<void>('terminal_set_focus', { id, focused });
  },
  setVisible(id: string, visible: boolean): Promise<void> {
    return invoke<void>('terminal_set_visible', { id, visible });
  },
  diagnostics(): Promise<SessionDiag[]> {
    return invoke<SessionDiag[]>('terminal_diagnostics');
  },

  // --- workspace index (spec §22/§29) ---
  indexSet(workspaceId: string, sessionIds: string[]): Promise<void> {
    return invoke<void>('workspace_index_set', { workspaceId, sessionIds });
  },
  indexGet(workspaceId: string): Promise<string[]> {
    return invoke<string[]>('workspace_index_get', { workspaceId });
  },

  // --- Python sidecar ---
  sidecarStatus(): Promise<boolean> {
    return invoke<boolean>('sidecar_status');
  },

  // --- workspace wizard ---
  pickFolder(): Promise<string | null> {
    return invoke<string | null>('pick_folder');
  },

  // --- launch CWD (the directory the user ran `tto` from) ---
  getLaunchCwd(): Promise<string | null> {
    return invoke<string | null>('get_launch_cwd');
  },

  // --- ego-lite browser automation ---
  egoLiteStatus(): Promise<EgoLiteStatus> {
    return invoke<EgoLiteStatus>('ego_lite_status');
  },
};

export interface EgoLiteStatus {
  app_installed: boolean;
  skill_installed: boolean;
  skill_path: string | null;
}

/** Create a binary output channel. Messages arrive as number[] (Vec<u8>). */
export function outputChannel(onMessage: (data: number[]) => void): Channel<number[]> {
  const ch = new Channel<number[]>();
  ch.onmessage = onMessage;
  return ch;
}

/** Create an exit-notify channel. */
export function exitChannel(onExit: () => void): Channel<unknown> {
  const ch = new Channel<unknown>();
  ch.onmessage = onExit;
  return ch;
}

/** Listen to a Rust-emitted event (e.g. terminal-updated). */
export function listenEvent<T>(name: string, cb: (payload: T) => void): Promise<() => void> {
  return import('@tauri-apps/api/event').then(({ listen }) =>
    listen<T>(name, (e) => cb(e.payload)),
  );
}
