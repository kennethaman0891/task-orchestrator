import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Terminal, type ILink } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { SearchAddon } from '@xterm/addon-search';
import { WebLinksAddon } from '@xterm/addon-web-links';
import '@xterm/xterm/css/xterm.css';
import { TerminalManager } from './TerminalManager';
import { isTauri } from './channels';
import { extractDropPaths, gateDragOver, routeTerminalDrop } from './dropPaths';
import { normalizeClaudeFresh } from '../lib/claude';

/** Cross-platform monospace font stack. */
const MONO_FONT =
  '"SF Mono", Menlo, Monaco, "Fira Code", "Cascadia Mono", Consolas, "Liberation Mono", monospace';

/** Default terminal font size (px). Configurable via SettingsModal.
 *  Kept at a SMALL 11px on purpose: full-screen CLIs (opencode, vim, htop)
 *  must fit many columns/rows inside the workspace cards (esp. compact mode).
 *  Raising this shrinks the usable grid and makes TUIs wrap/overflow/clip. */
const DEFAULT_TERMINAL_FONT = 11;
const TERMINAL_FONT_KEY = 'terminalFontSize';

/** Scrollback limit. Set very high to ensure NO terminal history is ever lost.
 *  The Rust side maintains a 64 MB persistent scrollback for reattach replay,
 *  but the frontend xterm.js buffer is what the user scrolls through. */
const SCROLLBACK_LIMIT = 100000;

/** Read the user's chosen terminal font size (persisted), clamped 8–20. */
function readTerminalFontSize(): number {
  try {
    const v = parseInt(localStorage.getItem(TERMINAL_FONT_KEY) || '', 10);
    if (!Number.isNaN(v)) return Math.max(8, Math.min(20, v));
  } catch {
    /* ignore */
  }
  return DEFAULT_TERMINAL_FONT;
}

interface Props {
  /** Rust session id (pane.tty). */
  sessionId: string;
  /** Stable pane id (React key / DOM identity). */
  paneId: string;
  onToast?: (msg: string, error?: boolean) => void;
  /** Fires when a full-screen TUI (alternate screen) starts/stops. Receives the
   *  pane id so parents can keep a STABLE callback identity (memo-friendly). */
  onTuiChange?: (active: boolean, paneId: string) => void;
  onRestart?: (sessionId: string) => void;
  onKill?: (sessionId: string) => void;
  onNewTerminal?: () => void;
  visible?: boolean;
  focused?: boolean;
  /** Called when terminal output contains a clickable file-path link or URL. */
  onLinkClick?: (target: string, lineNumber?: number, isUrl?: boolean) => void;
  /** Handle files dragged into terminal */
  onDrop?: (files: string[]) => void;
}

interface MenuPos {
  x: number;
  y: number;
}

// Regex matches Unix-style absolute paths and relative paths.
// Captures: group 1 = base path, group 2 = optional line number.
const PATH_LINK_RE =
  /((?:\/(?:home|Users)[^\s;|&]{2,}|(?:\.\/|\.\.\/)[^\s;|&]{2,}))[:\s]*(\d+)?(?=[\s;|&]|$)/g;

/**
 * A persistent native terminal renderer (spec §7, §36).
 */
export function TerminalPane({
  sessionId,
  paneId,
  onToast,
  onTuiChange,
  onRestart,
  onKill,
  onNewTerminal,
  visible = true,
  focused = false,
  onLinkClick,
  onDrop,
}: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [recoveryTick, setRecoveryTick] = useState(0);
  const [menu, setMenu] = useState<MenuPos | null>(null);
  const [searchVisible, setSearchVisible] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const onTuiChangeRef = useRef(onTuiChange);
  onTuiChangeRef.current = onTuiChange;
  const onLinkClickRef = useRef(onLinkClick);
  onLinkClickRef.current = onLinkClick;
  const paneIdRef = useRef(paneId);
  paneIdRef.current = paneId;

  const closeMenu = useCallback(() => setMenu(null), []);
  const onDropRef = useRef(onDrop);
  onDropRef.current = onDrop;

  const handleDragOver = useCallback((e: React.DragEvent) => {
    gateDragOver(e.nativeEvent);
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  // Single routing point for the React-synthetic layer — shares the exact
  // same extraction + routing as the native layers below.
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      routeTerminalDrop(e, onDrop);
      setDragOver(false);
    },
    [onDrop],
  );

  // Native DOM drag-and-drop listeners on the host element.
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const onDragOver = (e: DragEvent) => {
      gateDragOver(e);
      setDragOver(true);
    };
    const onDragLeave = (e: DragEvent) => {
      e.preventDefault();
      setDragOver(false);
    };
    const onDropNative = (e: DragEvent) => {
      routeTerminalDrop(e, onDropRef.current);
      setDragOver(false);
    };

    host.addEventListener('dragover', onDragOver, { capture: true });
    host.addEventListener('dragleave', onDragLeave, { capture: true });
    host.addEventListener('drop', onDropNative, { capture: true });

    const parent = host.parentElement;
    if (parent && parent !== host) {
      parent.addEventListener('dragover', onDragOver, { capture: true });
      parent.addEventListener('drop', onDropNative, { capture: true });
    }

    return () => {
      host.removeEventListener('dragover', onDragOver, { capture: true });
      host.removeEventListener('dragleave', onDragLeave, { capture: true });
      host.removeEventListener('drop', onDropNative, { capture: true });
      if (parent && parent !== host) {
        parent.removeEventListener('dragover', onDragOver, { capture: true });
        parent.removeEventListener('drop', onDropNative, { capture: true });
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keyboard: Cmd+F → show search bar.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'f') {
        const el = hostRef.current;
        if (el && el.contains(document.activeElement)) {
          e.preventDefault();
          setSearchVisible(true);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Close menu on outside click.
  useEffect(() => {
    if (!menu) return;
    const handler = (e: MouseEvent) => {
      const el = (e.target as HTMLElement).closest('.tp-menu');
      if (!el) closeMenu();
    };
    window.addEventListener('mousedown', handler);
    return () => window.removeEventListener('mousedown', handler);
  }, [menu, closeMenu]);

  useEffect(() => {
    const host = hostRef.current;
    if (!host || !isTauri()) return;

    const term = new Terminal({
      cursorBlink: true,
      fontFamily: MONO_FONT,
      fontSize: readTerminalFontSize(),
      lineHeight: 1.25,
      // FIX: Use a realistic scrollback limit (50k lines ≈ 4 MB). xterm.js 6
      // silently caps absurdly large values (1e9) which can cause unpredictable
      // truncation or memory allocation failures. 50,000 lines is far beyond
      // any real session's output and matches native terminal behavior.
      scrollback: SCROLLBACK_LIMIT,
      allowProposedApi: true,
      customGlyphs: false,
      // When a TUI clears the screen (ED2), push erased content to scrollback
      // instead of destroying it. Preserves OpenCode/vim/htop output history.
      scrollOnEraseInDisplay: true,
      theme: {
        background: '#000000',
        foreground: '#e8e8e8',
        cursor: '#4a9eff',
        selectionBackground: 'rgba(74,158,255,0.3)',
        black: '#000000',
        red: '#f87171',
        green: '#4ade80',
        yellow: '#facc15',
        blue: '#60a5fa',
        magenta: '#c084fc',
        cyan: '#22d3ee',
        white: '#e8e8e8',
        brightBlack: '#555555',
        brightRed: '#f87171',
        brightGreen: '#4ade80',
        brightYellow: '#facc15',
        brightBlue: '#93c5fd',
        brightMagenta: '#d8b4fe',
        brightCyan: '#67e8f9',
        brightWhite: '#ffffff',
      },
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    const search = new SearchAddon();
    term.loadAddon(search);

    // ── Click-to-open links (URLs + file paths) ───────────────────────────
    // The official web-links addon fires onLinkClick ONLY on user activation
    // (click), never at output-write time. This replaces the old term.write
    // wrapper + scanForLinks hack that auto-opened the embedded browser tab as
    // soon as any output printed an http(s) URL (e.g. Django runserver citing
    // http://127.0.0.1:8000) — without the user clicking anything.
    const webLinks = new WebLinksAddon((_event, uri) => {
      onLinkClickRef.current?.(
        uri,
        undefined,
        uri.startsWith('http://') || uri.startsWith('https://'),
      );
    });
    term.loadAddon(webLinks);

    // File-path links (/Users/…/file.py:12, ./file.py) keep the same
    // click-to-open behavior via a custom link provider — WebLinksAddon
    // dropped the old customMatchers option in 0.8.0, and a registered
    // ILinkProvider is the supported equivalent. Fires on click only.
    term.registerLinkProvider({
      provideLinks: (bufferLineNumber, callback) => {
        const bufLine = term.buffer.active.getLine(bufferLineNumber - 1);
        if (!bufLine) {
          callback(undefined);
          return;
        }
        const text = bufLine.translateToString(true);
        const links: ILink[] = [];
        const re = new RegExp(PATH_LINK_RE.source, 'g');
        let m: RegExpExecArray | null;
        while ((m = re.exec(text)) !== null) {
          const rawPath = m[1];
          const cleanPath = rawPath.replace(/:\d+$/, '');
          if (cleanPath.length < 3) continue;
          const lineNum = m[2] ? parseInt(m[2], 10) : undefined;
          links.push({
            text: cleanPath,
            range: {
              start: { x: m.index + 1, y: bufferLineNumber },
              end: { x: m.index + m[0].length, y: bufferLineNumber },
            },
            activate: () => onLinkClickRef.current?.(cleanPath, lineNum, false),
          });
        }
        callback(links.length ? links : undefined);
      },
    });
    term.open(host);
    (host as unknown as { _tto?: unknown })._tto = { term, search };

    // ── Drop acceptance ON the xterm surface (WebKit fix) ────────────────
    // xterm 6.0.0 attaches NO drag listeners of its own (DragAndDropObserver
    // is dead code in this build), so when the pointer is over the terminal
    // rows, only the .term-pane CAPTURE handler above cancels dragover. The
    // real Tauri webview (WKWebView on macOS) is stricter about drop
    // acceptance than Chromium: it hit-tests the element chain under the
    // cursor and can present a "no drop" target — the drop never fires.
    // Bind capture-phase listeners DIRECTLY on the .xterm root so the drop
    // target itself accepts the drag. The pane capture handler still runs
    // FIRST (capture travels top-down) and stops propagation, so these are
    // a backstop for engines where the surface must self-accept; the
    // exactly-once guarantee is enforced by App.handleDrop's dedupe.
    const xtermSurface = host.querySelector('.xterm');
    const onXtermDragOver = (e: Event) => gateDragOver(e as DragEvent);
    const onXtermDragLeave = (e: Event) => {
      (e as DragEvent).preventDefault();
      setDragOver(false);
    };
    const onXtermDrop = (e: Event) => {
      const de = e as DragEvent;
      de.preventDefault();
      setDragOver(false);
      const paths = extractDropPaths(de.dataTransfer);
      if (paths.length > 0) onDropRef.current?.(paths);
    };
    if (xtermSurface) {
      xtermSurface.addEventListener('dragover', onXtermDragOver, { capture: true });
      xtermSurface.addEventListener('dragleave', onXtermDragLeave, { capture: true });
      xtermSurface.addEventListener('drop', onXtermDrop, { capture: true });
    }

    // Ensure the viewport is scrollable after creation. xterm.js v6 may set
    // overflow:hidden on .xterm-viewport which blocks scrolling through
    // terminal history. Force-remove it so xterm's internal scroll works.
    // xterm renders its own custom scrollbar which we style via CSS.
    const ensureViewportScrollable = () => {
      const viewport = host.querySelector('.xterm-viewport') as HTMLElement | null;
      if (viewport) viewport.style.removeProperty('overflow');
    };

    // Use requestAnimationFrame to ensure DOM is ready, then apply fix.
    // Also use a secondary timeout as fallback for cases where xterm
    // initializes asynchronously.
    requestAnimationFrame(() => {
      ensureViewportScrollable();
      setTimeout(ensureViewportScrollable, 100);
    });

    // MutationObserver: watch for xterm adding/removing overflow on viewport.
    // This catches cases where xterm re-applies overflow after our initial fix.
    let viewportObserver: MutationObserver | null = null;
    if (typeof MutationObserver !== 'undefined') {
      viewportObserver = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type === 'attributes' && m.attributeName === 'style') {
            ensureViewportScrollable();
          }
        }
      });
      // Observe after a brief delay to ensure viewport element exists.
      setTimeout(() => {
        const vp = host.querySelector('.xterm-viewport') as HTMLElement | null;
        if (vp && viewportObserver) {
          viewportObserver.observe(vp, { attributes: true, attributeFilter: ['style'] });
        }
      }, 50);
    }

    // FIX: Use the DOM renderer instead of WebGL.
    // The WebGL canvas rasterizer garbles box-drawing and block characters
    // (▄ ▀ █ ╔═╗║╚╝) at small font sizes (≤12px). The cell-grid alignment
    // in the WebGL texture atlas doesn't match the actual font metrics,
    // producing fragmented/overlapping tiles — exactly what was breaking the
    // OpenCode banner and TUI status bars. The DOM renderer renders every
    // codepoint cleanly using CSS font metrics and is fast enough for
    // workspace-card-sized terminals (50–100 visible rows).

    let tuiActive = false;

    /** Fit xterm to the container using FitAddon. */
    const fitTerm = (_force = false): boolean => {
      const w = host.clientWidth;
      const h = host.clientHeight;
      if (w < 20 || h < 20) return false;
      try {
        fit.fit();
      } catch {
        return false;
      }
      return true;
    };

    // Persistent watcher: re-fit when container size changes.
    // Throttled to 500ms — fast enough for layout transitions, slow enough
    // to avoid resize storms during CSS grid reflows.
    let lastFitW = -1;
    let lastFitH = -1;
    const fitWatcher = window.setInterval(() => {
      const w = host.clientWidth;
      const h = host.clientHeight;
      if (w !== lastFitW || h !== lastFitH) {
        const landed = fitTerm();
        if (landed) {
          lastFitW = w;
          lastFitH = h;
        }
      }
    }, 500);

    TerminalManager.register({
      sessionId,
      term,
      host,
      onExit: () => onToast?.('Process exited — restart from the pane menu'),
      onStall: () => {
        onToast?.('Renderer stalled — recovering session', true);
        setRecoveryTick((t) => t + 1);
      },
      onTuiChange: (active) => onTuiChangeRef.current?.(active, paneIdRef.current),
    });

    // Input → PTY (bypasses React).
    const dataDispose = term.onData((d) => TerminalManager.write(sessionId, d));

    // Persist scroll position per session for view-switch restoration.
    const scrollDispose = term.onScroll(() => {
      try {
        sessionStorage.setItem(`tto-scroll-${sessionId}`, String(term.buffer.active.viewportY));
      } catch {
        /* noop */
      }
    });

    // ── Keyboard scroll shortcuts ────────────────────────────────────────
    // Cmd+Up/Down: scroll terminal up/down by one page.
    // Cmd+Shift+Up/Down: scroll to top/bottom of terminal history.
    // These work when the terminal host has focus. Prevents the default
    // browser behavior and avoids triggering CLI-specific scroll-up actions
    // (e.g. Claude Code's "resume session").
    const onScrollKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey)) return;
      const active = document.activeElement;
      if (!active || (!host.contains(active) && active !== host)) return;
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        e.stopPropagation();
        if (e.shiftKey) term.scrollToTop();
        else term.scrollLines(-term.rows);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        e.stopPropagation();
        if (e.shiftKey) term.scrollToBottom();
        else term.scrollLines(term.rows);
      } else if (e.key === 'Home' || (e.key === 'ArrowUp' && e.altKey)) {
        e.preventDefault();
        term.scrollToTop();
      } else if (e.key === 'End' || (e.key === 'ArrowDown' && e.altKey)) {
        e.preventDefault();
        term.scrollToBottom();
      }
    };
    window.addEventListener('keydown', onScrollKey, { capture: true });

    // Resize → PTY.
    let resizeTimeout: number | undefined;
    const pushSize = () => {
      if (term.cols > 2 && term.rows > 2) {
        TerminalManager.resize(sessionId, term.cols, term.rows);
      }
    };
    const resizeDispose = term.onResize(() => {
      clearTimeout(resizeTimeout);
      if (tuiActive) {
        pushSize();
      } else {
        resizeTimeout = window.setTimeout(pushSize, 120);
      }
    });

    // Title (OSC 0/2) → Rust metadata.
    const titleDispose = term.onTitleChange((title) => {
      if (title) TerminalManager.setTitle(sessionId, title);
    });

    // Expose fitTerm/pushSize to the visibility-change effect via refs.
    fitRef.current = fitTerm;
    pushSizeRef.current = pushSize;

    // Debounced fit scheduler for ResizeObserver / window resize.
    // Uses rAF + 16ms debounce to batch rapid layout changes into a single fit.
    let fitFrame = 0;
    let fitDebounce: number | undefined;
    const scheduleFit = (force = false) => {
      if (fitFrame) return;
      fitFrame = window.requestAnimationFrame(() => {
        fitFrame = 0;
        clearTimeout(fitDebounce);
        fitDebounce = window.setTimeout(() => {
          try {
            fitTerm(force);
          } catch {
            /* noop */
          }
          pushSize();
        }, 16);
      });
    };

    // Debounced ResizeObserver: batches rapid layout changes.
    let roDebounce: number | undefined;
    const refit = () => {
      clearTimeout(roDebounce);
      roDebounce = window.setTimeout(() => {
        const w = host.clientWidth;
        const h = host.clientHeight;
        if (w !== lastSizeRef.current.w || h !== lastSizeRef.current.h) {
          lastSizeRef.current = { w, h };
          if (w >= 20 && h >= 20) scheduleFit();
        }
      }, 30);
    };
    const ro = new ResizeObserver(refit);
    ro.observe(host);
    window.addEventListener('resize', refit);

    // Initial fit: retry until a fit lands, but at a slower cadence (100ms)
    // to avoid resize storms. Cap at 1.5s.
    let initialFitTimer = 0;
    const tryInitialFit = () => {
      try {
        const w = host.clientWidth;
        const h = host.clientHeight;
        if (w >= 20 && h >= 20) {
          lastSizeRef.current = { w: -1, h: -1 };
          lastFitW = -1;
          lastFitH = -1;
          const landed = fitTerm(true);
          if (landed) {
            pushSize();
            return;
          }
        }
      } catch {
        /* noop */
      }
      initialFitTimer = window.setTimeout(tryInitialFit, 100);
    };
    initialFitTimer = window.setTimeout(tryInitialFit, 100);
    const initialFitCap = window.setTimeout(() => {
      window.clearTimeout(initialFitTimer);
    }, 1500);

    // DPR change handler: schedule a fit but do NOT clear the texture atlas.
    // clearTextureAtlas wipes the entire GPU render cache, forcing xterm to
    // rebuild every glyph from scratch — this causes content to flash
    // "submerged"/blank during the rebuild. Let xterm handle the DPR change
    // internally through its normal resize/refresh cycle.
    let dprQuery: MediaQueryList | undefined;
    const watchDpr = () => {
      dprQuery?.removeEventListener('change', onDprChange);
      dprQuery = window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`);
      dprQuery.addEventListener('change', onDprChange);
    };
    const onDprChange = () => {
      scheduleFit(true);
      watchDpr();
    };
    watchDpr();

    TerminalManager.setVisible(sessionId, visible);
    TerminalManager.setFocus(sessionId, focused);

    const TUI_CLASS = 'tui-active';

    /** Refit when a TUI starts or exits. One forced fit + PTY push is all we
     *  need — the persistent fitWatcher handles any remaining settling. The old
     *  convergence loop (12x fitTerm at 80ms) caused a resize storm: each
     *  resize reflowed the buffer, each refresh rebuilt the texture atlas, and
     *  the rapid succession caused xterm.js to lose track of which lines were
     *  in the viewport vs. scrollback — the root cause of "content submerged". */
    const refitOnTuiChange = () => {
      // Fix: When a TUI exits, xterm.js may leave an inline
      // overflow:hidden on .xterm-viewport (set while in alternate screen).
      // This locks the viewport and prevents scrolling through history.
      // Force-remove it so xterm's internal scroll and custom scrollbar work.
      ensureViewportScrollable();
      lastFitW = -1;
      lastFitH = -1;
      lastSizeRef.current = { w: -1, h: -1 };
      try {
        fitTerm(true);
      } catch {
        /* noop */
      }
      pushSize();
      try {
        const core = (term as any)._core;
        core?._charSizeService?.measure();
      } catch {
        /* noop */
      }
    };

    // MutationObserver: fires IMMEDIATELY when the TUI class is toggled.
    let tuiObserver: MutationObserver | null = null;
    if (typeof MutationObserver !== 'undefined') {
      tuiObserver = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type === 'attributes' && m.attributeName === 'class') {
            const hasTui = host.classList.contains(TUI_CLASS);
            if (hasTui !== tuiActive) {
              tuiActive = hasTui;
              refitOnTuiChange();
            }
          }
        }
      });
      tuiObserver.observe(host, { attributes: true, attributeFilter: ['class'] });
    }

    // Fallback poll for TUI detection.
    const pollTui = window.setInterval(() => {
      try {
        const active = term.buffer.active.type === 'alternate';
        if (active !== tuiActive) {
          tuiActive = active;
          host.classList.toggle(TUI_CLASS, active);
          refitOnTuiChange();
        }
      } catch {
        /* disposed */
      }
    }, 300);

    return () => {
      window.clearInterval(fitWatcher);
      window.clearInterval(pollTui);
      clearTimeout(initialFitTimer);
      clearTimeout(roDebounce);
      clearTimeout(fitDebounce);
      host.classList.remove(TUI_CLASS);
      fitRef.current = null;
      pushSizeRef.current = null;
      clearTimeout(resizeTimeout);
      window.clearTimeout(initialFitCap);
      if (fitFrame) window.cancelAnimationFrame(fitFrame);
      tuiObserver?.disconnect();
      viewportObserver?.disconnect();
      ro.disconnect();
      window.removeEventListener('resize', refit);
      dprQuery?.removeEventListener('change', onDprChange);
      window.removeEventListener('keydown', onScrollKey, { capture: true });
      dataDispose.dispose();
      scrollDispose.dispose();
      resizeDispose.dispose();
      titleDispose.dispose();
      if (xtermSurface) {
        xtermSurface.removeEventListener('dragover', onXtermDragOver, { capture: true });
        xtermSurface.removeEventListener('dragleave', onXtermDragLeave, { capture: true });
        xtermSurface.removeEventListener('drop', onXtermDrop, { capture: true });
      }
      TerminalManager.detach(sessionId).catch(() => {});
      TerminalManager.unregister(sessionId);
      try {
        term.dispose();
      } catch {
        /* noop */
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId, recoveryTick]);

  // Push visibility/focus changes to Rust whenever they change.
  useEffect(() => {
    if (!isTauri()) return;
    TerminalManager.setVisible(sessionId, visible);
    TerminalManager.setFocus(sessionId, focused);
  }, [sessionId, visible, focused]);

  // Force a refit when the terminal becomes visible after being hidden, or
  // when the pane is re-anchored (paneId changes). Debounced to prevent
  // resize cascade when the grid reflows multiple panes simultaneously.
  const fitRef = useRef<((force?: boolean) => void) | null>(null);
  const pushSizeRef = useRef<(() => void) | null>(null);
  const lastSizeRef = useRef({ w: -1, h: -1 });
  // Tracks the previous `visible` value so we can detect the hidden→visible
  // transition (parked slot → live slot) and force a repaint even when the
  // container dimensions did not change.
  const prevVisibleRef = useRef(visible);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    // Detect the hidden→visible transition BEFORE the early returns so
    // prevVisibleRef always tracks the raw `visible` value. TerminalHost
    // parks offscreen slots at FULL size (left:-99999px), so an unparked pane
    // usually has IDENTICAL dimensions before/after the switch — the
    // dimension fast-path alone would skip the fit and xterm's renderer would
    // stay stale, leaving the pane blank / the zsh prompt missing.
    const becameVisible = visible && !prevVisibleRef.current;
    prevVisibleRef.current = visible;

    if (!visible || !isTauri()) return;

    let rafId = 0;
    const runFit = () => {
      rafId = 0;
      // Re-measure char size
      const handle = (host as unknown as { _tto?: { term?: Terminal } })._tto?.term;
      if (handle) {
        try {
          const core = (handle as any)._core;
          core?._charSizeService?.measure();
        } catch {
          /* noop */
        }
      }
      // Force a fit when the container dimensions changed (resize fast path)
      // OR when this run is the hidden→visible transition. On the transition
      // we repaint unconditionally — the parked pane kept its size, so the
      // dims are identical and the fast-path would otherwise skip the repaint
      // and xterm would never repaint (blank pane / missing zsh prompt).
      const w = host.clientWidth;
      const h = host.clientHeight;
      const changed = w !== lastSizeRef.current.w || h !== lastSizeRef.current.h;
      if (becameVisible || changed) {
        lastSizeRef.current = { w: -1, h: -1 };
        fitRef.current?.(true);
        pushSizeRef.current?.();
        // Key missing call: force xterm to redraw the FULL viewport
        // (0 → rows-1). fit.fit() is a no-op when cols/rows are unchanged, so
        // after DOM reparenting the renderer may never repaint and the pane
        // stays blank. refresh() schedules the render pass that brings the
        // buffer (incl. the zsh prompt) back on screen.
        if (becameVisible && handle && handle.rows > 0) {
          try {
            handle.refresh(0, handle.rows - 1);
          } catch {
            /* noop */
          }
        }
      }
      // Restore scroll position after viewport repaint.
      if (handle && handle.buffer.active) {
        try {
          const saved = sessionStorage.getItem(`tto-scroll-${sessionId}`);
          if (saved != null) {
            const pos = parseInt(saved, 10);
            const maxScroll =
              handle.buffer.active.baseY + handle.buffer.active.length - handle.rows;
            // Only restore if the saved position is valid; otherwise scroll to bottom
            // but only if the user hasn't recently scrolled up (indicated by saved pos > 0)
            if (pos > 0 && pos <= maxScroll) {
              handle.scrollToLine(pos);
            } else if (pos <= 0) {
              // Saved position is at or above top of buffer — restore it
              handle.scrollToLine(0);
            } else {
              // Saved position is below bottom — scroll to bottom
              handle.scrollToBottom();
            }
          } else {
            // No saved position — scroll to bottom
            handle.scrollToBottom();
          }
        } catch {
          /* noop */
        }
      }
    };
    // Use a short delay instead of immediate rAF to debounce rapid paneId
    // changes during grid reflows (e.g. switching layout modes).
    const timer = window.setTimeout(runFit, 50);
    rafId = window.requestAnimationFrame(() => {}); // track for cleanup
    return () => {
      window.clearTimeout(timer);
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [visible, sessionId, paneId]);

  // TUI wheel gesture handling.
  // IMPORTANT: Only intercept wheel events when a TUI (alternate screen) is
  // active. In normal terminal mode, let xterm.js handle scrolling natively
  // so the user can scroll through their full history. The old code called
  // preventDefault() before the isTui check, which broke normal scrolling.
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let wheelRemainder = 0;
    const onWheel = (e: WheelEvent) => {
      const term = (host as unknown as { _tto?: { term?: Terminal } })._tto?.term;
      const isTui = term?.buffer.active.type === 'alternate';
      if (!isTui) return; // Normal mode: let xterm.js / browser handle scroll

      e.preventDefault();
      e.stopPropagation();
      const delta =
        e.deltaMode === WheelEvent.DOM_DELTA_LINE
          ? e.deltaY * 16
          : e.deltaMode === WheelEvent.DOM_DELTA_PAGE
            ? e.deltaY * host.clientHeight
            : e.deltaY;
      wheelRemainder += delta;
      const PAGE_DELTA = 40;
      while (Math.abs(wheelRemainder) >= PAGE_DELTA) {
        TerminalManager.write(sessionId, wheelRemainder < 0 ? '\x15' : '\x04');
        wheelRemainder += wheelRemainder < 0 ? PAGE_DELTA : -PAGE_DELTA;
      }
    };
    host.addEventListener('wheel', onWheel, { passive: false, capture: true });
    return () => host.removeEventListener('wheel', onWheel, { capture: true });
  }, [sessionId]);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setMenu({ x: e.clientX, y: e.clientY });
  }, []);

  const term = (hostRef.current as unknown as { _tto?: { term?: Terminal } })?._tto?.term;
  const selectedText = term?.getSelection() || '';

  const runSearch = useCallback((query: string, prev = false) => {
    if (!query) return;
    const el = hostRef.current;
    const search = (el as unknown as { _tto?: { search?: SearchAddon } })?._tto?.search;
    if (search) {
      if (prev) search.findPrevious(query);
      else search.findNext(query);
    }
  }, []);

  return (
    <>
      <div
        className={`term-pane ${dragOver ? 'drag-over' : ''}`}
        ref={hostRef}
        onContextMenu={handleContextMenu}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {searchVisible && (
          <div className="tp-search-bar">
            <input
              autoFocus
              className="tp-search-input"
              placeholder="Find..."
              value={searchQuery}
              onChange={(e) => {
                const q = e.target.value;
                setSearchQuery(q);
                runSearch(q);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') runSearch(searchQuery, e.shiftKey);
                if (e.key === 'Escape') {
                  setSearchVisible(false);
                  setSearchQuery('');
                }
              }}
            />
            <button
              className="tp-search-btn"
              onClick={() => runSearch(searchQuery, true)}
              title="Previous"
            >
              ↑
            </button>
            <button className="tp-search-btn" onClick={() => runSearch(searchQuery)} title="Next">
              ↓
            </button>
            <button
              className="tp-search-btn"
              onClick={() => {
                setSearchVisible(false);
                setSearchQuery('');
              }}
              title="Close (Esc)"
            >
              ✕
            </button>
          </div>
        )}
      </div>
      {menu &&
        createPortal(
          <div className="tp-menu" style={{ left: menu.x, top: menu.y }}>
            <button
              className="tp-menu-item"
              onClick={() => {
                term?.focus();
                navigator.clipboard.writeText(selectedText);
                closeMenu();
              }}
              disabled={!selectedText}
            >
              Copy
            </button>
            <button
              className="tp-menu-item"
              onClick={() => {
                navigator.clipboard
                  .readText()
                  .then((t) => TerminalManager.write(sessionId, normalizeClaudeFresh(t)))
                  .catch(() => {});
                closeMenu();
              }}
            >
              Paste
            </button>
            <button
              className="tp-menu-item"
              onClick={() => {
                term?.focus();
                term?.clear();
                closeMenu();
              }}
            >
              Clear
            </button>
            <div className="tp-menu-sep" />
            <button
              className="tp-menu-item"
              onClick={() => {
                setSearchVisible(true);
                closeMenu();
              }}
            >
              Search
            </button>
            <div className="tp-menu-sep" />
            <button
              className="tp-menu-item"
              onClick={() => {
                onRestart?.(sessionId);
                closeMenu();
              }}
            >
              Restart
            </button>
            <button
              className="tp-menu-item danger"
              onClick={() => {
                onKill?.(sessionId);
                closeMenu();
              }}
            >
              Kill
            </button>
            <div className="tp-menu-sep" />
            <button
              className="tp-menu-item"
              onClick={() => {
                onNewTerminal?.();
                closeMenu();
              }}
            >
              New Terminal
            </button>
          </div>,
          document.body,
        )}
    </>
  );
}
