// Types mirroring the Rust IPC contract (src-tauri/src/terminal/session.rs).

export interface SessionMeta {
  id: string;
  workspace_id: string;
  shell: string;
  cwd: string;
  title: string;
  status: 'running' | 'exited' | 'killed' | 'restarting';
  agent: string;
  created_at: number;
  last_activity: number;
  cols: number;
  rows: number;
  tui_active: boolean;
  pid: number;
  /** Slave tty name (e.g. "ttys004") — links the session to the sidecar map. */
  tty: string;
}

export interface SessionDiag {
  id: string;
  queue_len: number;
  dropped_bytes: number;
  chunks_sent: number;
  mode: 'focused' | 'visible' | 'background';
}
