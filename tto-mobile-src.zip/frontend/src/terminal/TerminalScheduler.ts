// Frontend render scheduler (spec §10, §31, §43).
//
// Complements the Rust scheduler:
// - TUI detection via xterm's buffer type (replaces the old tmux subprocess
//   poll) — cheap, no subprocess, no server round-trip.
// - Background/hidden renderers flush on a throttled cadence.
// - Focused/visible state is pushed to Rust so the PTY-side scheduler gives
//   the focused terminal the biggest render budget.
//
// ONLY rendering is throttled here — the PTY/agent always runs.

import { TerminalManager } from './TerminalManager';

const TUI_CHECK_MS = 500; // alternate-screen check cadence
const FOCUS_CHECK_MS = 100; // focus push cadence

export class TerminalScheduler {
  private tuiState = new Map<string, boolean>();
  private focusState = new Map<string, boolean>();
  private running = false;
  private timer: number | null = null;

  start(): void {
    if (this.running) return;
    this.running = true;
    const loop = () => {
      if (!this.running) return;
      this.tick();
      this.timer = window.setTimeout(loop, TUI_CHECK_MS);
    };
    loop();
  }

  stop(): void {
    this.running = false;
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  /** Push focus changes to Rust (focused terminal gets priority budget). */
  updateFocus(sessionId: string, focused: boolean): void {
    const prev = this.focusState.get(sessionId) ?? false;
    if (prev !== focused) {
      this.focusState.set(sessionId, focused);
      TerminalManager.setFocus(sessionId, focused);
    }
  }

  private tick(): void {
    for (const handle of TerminalManager.all()) {
      if (!handle.attached) continue;

      // TUI detection (spec: no tmux poll). Alternate buffer => full-screen TUI.
      let tui = false;
      try {
        tui = handle.term.buffer.active.type === 'alternate';
      } catch {
        /* terminal disposed — ignore */
      }
      const prevTui = this.tuiState.get(handle.sessionId) ?? false;
      if (prevTui !== tui) {
        this.tuiState.set(handle.sessionId, tui);
        TerminalManager.setTui(handle.sessionId, tui);
      }

      // Background throttle: coalesce-flush hidden/background renderers.
      if (!handle.visible || !handle.focused) {
        handle.queue.flushNow();
      }
    }

    // Push visibility to Rust so hidden panes get the background budget there.
    const now = Date.now();
    if (now % FOCUS_CHECK_MS < TUI_CHECK_MS) {
      for (const handle of TerminalManager.all()) {
        TerminalManager.setVisible(handle.sessionId, handle.visible);
      }
    }
  }
}

export const Scheduler = new TerminalScheduler();
