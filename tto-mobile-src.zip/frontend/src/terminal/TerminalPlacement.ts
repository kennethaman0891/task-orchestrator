/**
 * TerminalPlacement — the registry that connects the always-mounted terminal
 * host (TerminalHost.tsx) with the view-level anchors where terminals appear.
 *
 * Architecture:
 * - TerminalHost renders every session's <TerminalPane> exactly once, forever,
 *   inside a per-session "slot" div (a plain DOM node it renders into via a
 *   STABLE React portal). It registers those slot nodes here.
 * - Views (grid cells, workspace `.tw-pane-slot`s) render lightweight
 *   <TerminalAnchor> divs and register THEM here as the slot's destination.
 * - TerminalAnchor physically MOVES the session's slot node into itself on
 *   mount (and returns it to the offscreen parking area on unmount).
 *
 * Because a slot node is an opaque portal container to React, reparenting it is
 * invisible to React's reconciliation — the TerminalPane inside NEVER remounts,
 * so xterm instances and their scrollback survive every view/panel switch.
 * (Verified empirically: React 19 remounts portal children if the container
 * CHANGES, so the container per session is kept stable and moved instead.)
 *
 * This also guarantees TerminalManager never sees two simultaneous register()
 * calls for a sessionId (it keys renderers by sessionId and a second register
 * would replace the first) — there is exactly ONE <TerminalPane> per session,
 * in the shared host.
 */
const slotNodes = new Map<string, HTMLElement>();
const anchors = new Map<string, HTMLElement>();

/** Register (or clear, with null) the offscreen parking area for anchor-less
 *  sessions. Created lazily so it is available to components at any phase. */
let parkingEl: HTMLElement | null = null;
export function getParkingElement(): HTMLElement {
  if (!parkingEl) {
    parkingEl = document.createElement('div');
    parkingEl.className = 'th-parking';
    parkingEl.setAttribute('aria-hidden', 'true');
    document.body.appendChild(parkingEl);
  }
  return parkingEl;
}

/** The slot div that hosts a session's xterm (created by TerminalHost). */
export function setSlotNode(sessionId: string, el: HTMLElement | null): void {
  if (el) {
    // Guard: if a slot already exists for this sessionId, remove it from its
    // current parent before re-registering. This prevents stale references
    // from causing slots to be orphaned or double-registered.
    const existing = slotNodes.get(sessionId);
    if (existing && existing !== el && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
    slotNodes.set(sessionId, el);
  } else {
    slotNodes.delete(sessionId);
  }
}

export function getSlotNode(sessionId: string): HTMLElement | null {
  return slotNodes.get(sessionId) ?? null;
}

/** Register (or clear, with null) the slot destination a view renders. */
export function setTerminalAnchor(sessionId: string, el: HTMLElement | null): void {
  if (el) {
    // Guard: if an anchor already exists for this sessionId, remove it first.
    // This handles the case where React reuses a DOM element for a different
    // session (e.g. during view switches or pane reassignment).
    const existing = anchors.get(sessionId);
    if (existing && existing !== el) {
      // Return any slot that was sitting in the old anchor back to parking
      const oldSlot = slotNodes.get(sessionId);
      if (oldSlot && oldSlot.parentNode === existing) {
        getParkingElement().appendChild(oldSlot);
      }
    }
    anchors.set(sessionId, el);
  } else {
    anchors.delete(sessionId);
  }
}

/** Get the currently registered anchor for a session, if any. */
export function getTerminalAnchor(sessionId: string): HTMLElement | null {
  return anchors.get(sessionId) ?? null;
}
