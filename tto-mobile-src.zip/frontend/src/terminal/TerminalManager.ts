// TerminalManager (spec §7, §28, §36).
//
// Owns one persistent renderer handle per terminal session. Creating T5 never
// rebuilds T1–T4: each session has its own xterm instance, its own write queue,
// its own Tauri output channel.
//
// Responsibilities:
// - attach/detach channels per session (Rust keeps the PTY alive either way)
// - forward input/resize/title/tui/focus/visibility to Rust
// - watchdog recovery: recreate the renderer if xterm stalls (PTY untouched)
// - expose per-session diagnostics

import type { Terminal } from '@xterm/xterm';
import { tauri, outputChannel, exitChannel } from './channels';
import { WriteQueue } from './writeQueue';
import { SynchronizedOutputFilter } from './synchronizedOutputFilter';
import { normalizeClaudeFresh } from '../lib/claude';

export interface RendererHandle {
  sessionId: string;
  term: Terminal;
  host: HTMLDivElement;
  queue: WriteQueue;
  attached: boolean;
  focused: boolean;
  visible: boolean;
  onExit: (() => void) | null;
  /** Fires on TUI (alternate-screen) transitions — used for auto-expand layout. */
  onTuiChange: ((active: boolean) => void) | null;
  /** Unix ms of the most recent terminal→xterm write (output activity). */
  lastOutputAt: number;
  /** Whether the session is currently in an alternate-screen TUI. */
  tuiActive: boolean;
}

class TerminalManagerImpl {
  private renderers = new Map<string, RendererHandle>();

  /**
   * Register a freshly-created xterm instance for a session and open the
   * Tauri output channel. Idempotent: re-registering the same session id
   * replaces the handle (recovery path).
   */
  register(opts: {
    sessionId: string;
    term: Terminal;
    host: HTMLDivElement;
    onExit?: () => void;
    onStall?: (sessionId: string) => void;
    onTuiChange?: (active: boolean) => void;
  }): RendererHandle {
    const prev = this.renderers.get(opts.sessionId);
    if (prev) {
      // Recovery path: dispose the old renderer wiring, keep the session.
      prev.queue.reset();
    }

    const synchronizedOutput = new SynchronizedOutputFilter();
    const handle = {
      sessionId: opts.sessionId,
      term: opts.term,
      host: opts.host,
      attached: false,
      focused: false,
      visible: true,
      onExit: opts.onExit ?? null,
      onTuiChange: opts.onTuiChange ?? null,
      lastOutputAt: Date.now(),
      tuiActive: false,
    } as RendererHandle;
    const queue = new WriteQueue({
      deliver: (data, done) => {
        const filtered = synchronizedOutput.filter(data);
        // The filter can intentionally remove a complete ED2 sequence. xterm
        // would not call its write callback for an empty payload, so settle the
        // queue synchronously in that case.
        handle.lastOutputAt = Date.now();
        if (filtered.byteLength === 0) done();
        else opts.term.write(filtered, done);
      },
      onStall: () => opts.onStall?.(opts.sessionId),
    });
    handle.queue = queue;

    this.renderers.set(opts.sessionId, handle);
    this.attach(handle).catch(() => {});
    return handle;
  }

  /** Open the Tauri channel for a renderer handle (reattach-safe). */
  async attach(handle: RendererHandle): Promise<void> {
    const onOutput = outputChannel((data) => {
      // Output bypasses React entirely: straight into the serialized write queue.
      handle.queue.push(Uint8Array.from(data));
    });
    const onExit = exitChannel(() => {
      handle.onExit?.();
    });

    await tauri.attach(handle.sessionId, onOutput, onExit);
    handle.attached = true;
  }

  /** Detach renderer from the Rust session. PTY keeps running (spec §28). */
  async detach(sessionId: string): Promise<void> {
    const handle = this.renderers.get(sessionId);
    if (!handle) return;
    handle.attached = false;
    try {
      await tauri.detach(sessionId);
    } catch {
      /* session may already be gone */
    }
  }

  unregister(sessionId: string): void {
    const handle = this.renderers.get(sessionId);
    if (!handle) return;
    handle.queue.reset();
    this.renderers.delete(sessionId);
  }

  has(sessionId: string): boolean {
    return this.renderers.has(sessionId);
  }

  get(sessionId: string): RendererHandle | undefined {
    return this.renderers.get(sessionId);
  }

  all(): RendererHandle[] {
    return Array.from(this.renderers.values());
  }

  /** Keyboard input → PTY (bypasses React). */
  write(sessionId: string, data: string): void {
    const enc = new TextEncoder();
    tauri.write(sessionId, enc.encode(data)).catch(() => {});
  }

  /**
   * Fetch the full persistent output history for a session (FIX: full-history
   * replay). Called after (re)creating a renderer so the terminal shows the
   * ENTIRE output instead of only the newest buffered chunks.
   */
  async getScrollback(sessionId: string): Promise<Uint8Array | null> {
    try {
      const raw = await tauri.getScrollback(sessionId);
      return Uint8Array.from(raw);
    } catch {
      return null;
    }
  }

  sendCommand(sessionId: string, command: string): void {
    // Guarantee Claude Code launches a fresh session (strips resume flags).
    // This central dispatch covers every sendCommand caller (workspace launch,
    // quick-launch, task center) with the native Rust PTY path that bypasses
    // the backend normalizer. Harmless & idempotent for non-claude commands.
    tauri.sendCommand(sessionId, normalizeClaudeFresh(command)).catch(() => {});
  }

  resize(sessionId: string, cols: number, rows: number): void {
    tauri.resize(sessionId, cols, rows).catch(() => {});
  }

  setTitle(sessionId: string, title: string): void {
    tauri.setTitle(sessionId, title).catch(() => {});
  }

  setTui(sessionId: string, active: boolean): void {
    // Notify the renderer owner (App layout) on TUI transitions — used for
    // auto-expanding the pane so the CLI gets a full-workspace canvas.
    const handle = this.renderers.get(sessionId);
    if (handle) {
      handle.tuiActive = active;
      handle.onTuiChange?.(active);
    }
    tauri.setTui(sessionId, active).catch(() => {});
  }

  /** Whether a session is currently in an alternate-screen TUI (full-screen CLI
   *  like opencode / vim / htop) — a key signal for "asking a question". */
  isTui(sessionId: string): boolean {
    return this.renderers.get(sessionId)?.tuiActive ?? false;
  }

  /** Unix ms of the last terminal output delivered to xterm (0 = unknown). */
  outputAt(sessionId: string): number {
    return this.renderers.get(sessionId)?.lastOutputAt ?? 0;
  }

  /** True if the session produced terminal output within the given window. */
  recentlyActive(sessionId: string, windowMs = 4000): boolean {
    const handle = this.renderers.get(sessionId);
    if (!handle) return false;
    return Date.now() - handle.lastOutputAt < windowMs;
  }

  /** Last N rendered lines of a session's active xterm buffer (for showing the
   *  question text while a CLI awaits input). Empty when unavailable. */
  lastLines(sessionId: string, n = 3): string[] {
    const handle = this.renderers.get(sessionId);
    if (!handle) return [];
    try {
      const buf = handle.term.buffer.active;
      const out: string[] = [];
      for (let i = buf.length - 1; i >= Math.max(0, buf.length - n); i--) {
        out.unshift(buf.getLine(i)?.translateToString(true) ?? '');
      }
      return out.filter((l) => l.trim().length > 0);
    } catch {
      return [];
    }
  }

  setFocus(sessionId: string, focused: boolean): void {
    const handle = this.renderers.get(sessionId);
    if (handle) handle.focused = focused;
    tauri.setFocus(sessionId, focused).catch(() => {});
  }

  setVisible(sessionId: string, visible: boolean): void {
    const handle = this.renderers.get(sessionId);
    if (handle) handle.visible = visible;
    tauri.setVisible(sessionId, visible).catch(() => {});
  }

  /** Watchdog recovery: recreate the renderer (spec §9/§28). */
  recover(sessionId: string): void {
    const handle = this.renderers.get(sessionId);
    if (!handle) return;
    // Detach from Rust (session keeps running), reset queue state.
    this.detach(sessionId).catch(() => {});
    handle.queue.reset();
    // The owning React component re-registers via register() when it detects
    // the recovery flag; meanwhile the Rust side re-buffers output.
    handle.attached = false;
  }

  async diagnostics(): Promise<unknown[]> {
    try {
      const diags = await tauri.diagnostics();
      return diags.map((d) => ({
        ...d,
        frontend_dropped: this.renderers.get(d.id)?.queue.dropped ?? 0,
        frontend_flushed: this.renderers.get(d.id)?.queue.flushed ?? 0,
      }));
    } catch {
      return [];
    }
  }
}

export const TerminalManager = new TerminalManagerImpl();
