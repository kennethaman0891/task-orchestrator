/**
 * Shared file-drop extraction + routing for terminal surfaces.
 *
 * Every terminal drop layer (pane native capture listener, pane React
 * synthetic handler, xterm-surface capture listener, workspace handler)
 * funnels through these two helpers so the data format and the routing
 * behavior are IDENTICAL everywhere — a single source of truth.
 *
 * Path sources, in priority order:
 *  1. OS file drags  → `dataTransfer.files[].path` (web builds). In the
 *     Tauri webview OS drags are intercepted natively (dt.files is empty)
 *     and delivered via the `tto://drag-drop` event instead, so this branch
 *     is a no-op there — by design.
 *  2. Sidebar HTML5 drags → `text/plain` / `application/x-tto-file`
 *     (absolute file path set by FileBrowser on dragstart).
 *  3. WebKit drop support → `text/uri-list` (file:// URIs). Whatever else
 *     WebKit decides to scrub from a drag, uri-list is the one format it
 *     preserves for file-like drags.
 */

/** Extract absolute file paths from a DataTransfer (empty when nothing usable). */
export function extractDropPaths(dt: DataTransfer | null): string[] {
  if (!dt) return [];

  // 1) OS file drag
  const files = Array.from(dt.files);
  const filePaths = files
    .map((f: any) => (typeof f.path === 'string' && f.path ? f.path : f.name || ''))
    .filter(Boolean);
  if (filePaths.length > 0) return filePaths;

  // 2) Sidebar drag: absolute path in text data
  const plain = dt.getData('text/plain') || dt.getData('application/x-tto-file');
  if (plain && plain.trim()) return [plain.trim()];

  // 3) WebKit text/uri-list fallback (file:// URIs or bare paths)
  const uriList = dt.getData('text/uri-list');
  if (uriList) {
    const paths = uriList
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith('#'))
      .map((line) => {
        if (line.startsWith('file://')) {
          const raw = line.slice('file://'.length);
          try {
            return decodeURIComponent(raw);
          } catch {
            return raw;
          }
        }
        if (line.startsWith('file:')) {
          const raw = line.slice('file:'.length);
          try {
            return decodeURIComponent(raw);
          } catch {
            return raw;
          }
        }
        return line;
      })
      .filter(Boolean);
    if (paths.length > 0) return paths;
  }

  return [];
}

/** Shape of anything that can carry a drop (native DragEvent or React.DragEvent). */
export interface DropLike {
  preventDefault(): void;
  stopPropagation(): void;
  dataTransfer: DataTransfer | null;
}

/**
 * THE single routing point for a terminal drop: prevent the browser
 * default, stop the event from reaching the recovery layers further up,
 * extract paths and hand them to the pane's `onDrop`.
 *
 * Returns true when a path was routed.
 */
export function routeTerminalDrop(
  e: DropLike,
  onDrop: ((paths: string[]) => void) | undefined,
): boolean {
  e.preventDefault();
  e.stopPropagation();
  const paths = extractDropPaths(e.dataTransfer);
  if (paths.length > 0 && onDrop) {
    onDrop(paths);
    return true;
  }
  return false;
}

/**
 * Capture-phase `dragover` gate: cancel the default (which REJECTS the
 * drop in the browser) and advertise a copy action. Kept as a plain
 * function so it can be attached to native elements and reused.
 */
export function gateDragOver(e: DragEvent): void {
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
}
