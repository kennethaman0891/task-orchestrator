import { useEffect, useRef, useState } from 'react';
import {
  getGitStatus,
  getGitDiff,
  stageFiles,
  unstageFiles,
  commitGit,
  initGitRepo,
  type GitStatus,
} from '../api/client';
import { fileIcon } from './CodeEditor';

interface Props {
  onToast?: (msg: string, error?: boolean) => void;
  onOpenFile?: (path: string, name: string, lineNumber?: number) => void;
  /** Workspace project path — git commands run against THIS repo (not $HOME). */
  workspacePath?: string;
}

export function GitSourceControl({ onToast, onOpenFile, workspacePath }: Props) {
  const [gitStatus, setGitStatus] = useState<GitStatus | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [diffContent, setDiffContent] = useState<string>('');
  const [commitMessage, setCommitMessage] = useState('');
  const [isCommitting, setIsCommitting] = useState(false);
  // Guards against stale diff responses landing after a newer selection/unmount.
  const diffReqId = useRef(0);

  // Refresh git status periodically
  useEffect(() => {
    const refresh = async () => {
      try {
        const status = await getGitStatus(workspacePath || '');
        setGitStatus(status);
      } catch {}
    };
    refresh();
    const interval = setInterval(refresh, 30000);
    return () => clearInterval(interval);
  }, [workspacePath]);

  // Load diff when file selected
  useEffect(() => {
    if (!selectedFile || !gitStatus?.in_repo) {
      setDiffContent('');
      return;
    }
    const id = ++diffReqId.current;
    getGitDiff(selectedFile, workspacePath || '')
      .then((data) => {
        if (id !== diffReqId.current) return; // stale — newer selection superseded this
        setDiffContent(data.diff ?? '(No changes)');
      })
      .catch(() => {
        if (id !== diffReqId.current) return;
        setDiffContent('(Error loading diff)');
      });
  }, [selectedFile, gitStatus]);

  // Stage/unstage mutate the real git index — always re-read status afterwards
  // instead of tracking a client-side fiction that desyncs from the repo.
  const refreshStatus = async () => {
    try {
      const status = await getGitStatus(workspacePath || '');
      setGitStatus(status);
    } catch {
      /* keep last known status */
    }
  };

  const handleStage = async (filePath: string) => {
    try {
      await stageFiles(filePath, workspacePath || '');
      onToast?.(`Staged ${filePath}`);
      await refreshStatus();
    } catch (e: any) {
      onToast?.(e.message || 'Failed to stage', true);
    }
  };

  const handleUnstage = async (filePath: string) => {
    try {
      await unstageFiles(filePath, workspacePath || '');
      onToast?.(`Unstaged ${filePath}`);
      await refreshStatus();
    } catch (e: any) {
      onToast?.(e.message || 'Failed to unstage', true);
    }
  };

  const handleCommit = async () => {
    if (!commitMessage.trim()) {
      onToast?.('Please enter a commit message', true);
      return;
    }
    setIsCommitting(true);
    try {
      const data = await commitGit(commitMessage, workspacePath || '');
      onToast?.(data.message || 'Committed successfully');
      setCommitMessage('');
      await refreshStatus();
    } catch (e: any) {
      onToast?.(e.message || 'Commit failed', true);
    } finally {
      setIsCommitting(false);
    }
  };

  const [isInitializing, setIsInitializing] = useState(false);

  const handleInitRepo = async () => {
    if (!workspacePath) {
      onToast?.('No workspace folder selected', true);
      return;
    }
    setIsInitializing(true);
    try {
      const res = await initGitRepo(workspacePath);
      if (res.ok) {
        onToast?.(res.message || 'Repository initialized');
        await refreshStatus();
      } else {
        onToast?.(res.message || 'Failed to initialize repository', true);
      }
    } catch (e: any) {
      onToast?.(e.message || 'Failed to initialize repository', true);
    } finally {
      setIsInitializing(false);
    }
  };

  if (!gitStatus?.in_repo) {
    return (
      <div className="git-panel">
        <div className="git-header">
          <span className="git-icon">⎇</span>
          <span>Source Control</span>
        </div>
        <div className="git-empty">
          <div>This folder is not a git repository yet.</div>
          <button
            className="git-init-btn"
            onClick={handleInitRepo}
            disabled={isInitializing || !workspacePath}
            title={workspacePath ? `Initialize git in ${workspacePath}` : 'No workspace folder'}
          >
            {isInitializing ? 'Initializing…' : '+ Initialize Repository'}
          </button>
        </div>
      </div>
    );
  }

  // Backend reports untracked files with status 'untracked' (porcelain '?' is
  // mapped in main.py) — matching on the API word, not the raw porcelain char.
  const stagedFiles = gitStatus.files.filter((f) => f.staged);
  const changedFiles = gitStatus.files.filter((f) => !f.staged && f.status !== 'untracked');
  const untrackedFiles = gitStatus.files.filter((f) => f.status === 'untracked');

  return (
    <div className="git-panel">
      <div className="git-header">
        <span className="git-icon">⎇</span>
        <span>Source Control</span>
        {gitStatus.branch && <span className="git-branch">{gitStatus.branch}</span>}
      </div>

      {/* Staged files (real index state from the backend) */}
      {stagedFiles.length > 0 && (
        <div className="git-section">
          <div className="git-section-title">Staged Changes</div>
          {stagedFiles.slice(0, 20).map((f) => (
            <div key={f.path} className="git-file-row staged">
              <span className="git-file-icon">{fileIcon(f.path)}</span>
              <span
                className="git-file-name"
                onClick={() => {
                  setSelectedFile(f.path);
                  onOpenFile?.(f.path, f.path.split('/').pop() || f.path);
                }}
              >
                {f.path}
              </span>
              <button
                className="git-action-btn"
                onClick={() => handleUnstage(f.path)}
                title="Unstage"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Changed (unstaged) files */}
      {changedFiles.length > 0 && (
        <div className="git-section">
          <div className="git-section-title">Changes ({changedFiles.length})</div>
          {changedFiles.slice(0, 20).map((f) => (
            <div key={f.path} className="git-file-row">
              <span className="git-status-tag">{f.status}</span>
              <span className="git-file-icon">{fileIcon(f.path)}</span>
              <span
                className="git-file-name"
                onClick={() => {
                  setSelectedFile(f.path);
                  onOpenFile?.(f.path, f.path.split('/').pop() || f.path);
                }}
              >
                {f.path}
              </span>
              <button className="git-action-btn" onClick={() => handleStage(f.path)} title="Stage">
                +
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Untracked files */}
      {untrackedFiles.length > 0 && (
        <div className="git-section">
          <div className="git-section-title">Untracked ({untrackedFiles.length})</div>
          {untrackedFiles.slice(0, 10).map((f) => (
            <div key={f.path} className="git-file-row untracked">
              <span className="git-file-icon">{fileIcon(f.path)}</span>
              <span className="git-file-name">{f.path}</span>
              <button className="git-action-btn" onClick={() => handleStage(f.path)}>
                +
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Diff viewer */}
      {selectedFile && (
        <div className="git-diff-section">
          <div className="git-diff-header">
            <span>{selectedFile}</span>
            <button className="git-close-btn" onClick={() => setSelectedFile(null)}>
              ×
            </button>
          </div>
          <pre className="git-diff-content">{diffContent}</pre>
        </div>
      )}

      {/* Commit section */}
      <div className="git-commit-section">
        <textarea
          className="git-commit-input"
          value={commitMessage}
          onChange={(e) => setCommitMessage(e.target.value)}
          placeholder="Commit message..."
          rows={3}
        />
        <div className="git-commit-actions">
          <button
            className="git-commit-btn"
            onClick={handleCommit}
            disabled={isCommitting || !commitMessage.trim()}
          >
            {isCommitting ? 'Committing...' : 'Commit'}
          </button>
          <button className="git-stage-all-btn" onClick={() => stageFiles('', workspacePath || '')}>
            Stage All
          </button>
        </div>
      </div>
    </div>
  );
}
