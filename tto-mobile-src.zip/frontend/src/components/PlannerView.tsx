import { useState } from 'react';
import type { Workspace } from '../workspace';
import type { UnifiedTerminal } from '../types';
import { CEOScheduler } from './CEOScheduler';
import { WorkspaceMemory } from './WorkspaceMemory';

interface Props {
  workspaces: Workspace[];
  activeId: string;
  terminals: Record<string, UnifiedTerminal>;
  onToast: (msg: string, error?: boolean) => void;
}

type PlannerTab = 'scheduler' | 'memory';

/**
 * Combined Planner view — CEO Scheduler and Workspace Memory in a single
 * tabbed panel. Reduces sidebar clutter while keeping both tools accessible.
 */
export function PlannerView({ workspaces, activeId, terminals, onToast }: Props) {
  const [tab, setTab] = useState<PlannerTab>('scheduler');

  return (
    <div className="combined-panel">
      <div className="combined-tabs">
        <button
          className={`combined-tab ${tab === 'scheduler' ? 'active' : ''}`}
          onClick={() => setTab('scheduler')}
        >
          📅 CEO Scheduler
        </button>
        <button
          className={`combined-tab ${tab === 'memory' ? 'active' : ''}`}
          onClick={() => setTab('memory')}
        >
          🧠 Workspace Memory
        </button>
      </div>
      <div className="combined-body">
        {tab === 'scheduler' ? (
          <CEOScheduler
            workspaces={workspaces}
            activeId={activeId}
            terminals={terminals}
            onToast={onToast}
          />
        ) : (
          <WorkspaceMemory workspaces={workspaces} activeId={activeId} onToast={onToast} />
        )}
      </div>
    </div>
  );
}
