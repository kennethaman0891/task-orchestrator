import { useState, useCallback } from 'react';
import { apiBase } from '../api/base';
import { shellQuote } from '../lib/format';

interface Props {
  /** Current active file path */
  activeFile?: string | null;
  /** Current active file name */
  activeFileName?: string;
  /** Unified terminals keyed by tty */
  terminals?: Record<string, any>;
  /** Callback to send command to a terminal */
  onSendCommand?: (tty: string, command: string) => void;
  /** Preferred terminal (active workspace's first tty) — used over ttys[0] */
  preferredTty?: string;
}

/** Map file extensions to their run commands. Every user-controlled path is
 *  shell-quoted (single quotes) so `$`, backticks and spaces in filenames can
 *  never break out into shell metacharacters. */
const RUN_COMMANDS: Record<string, (file: string) => string> = {
  // Python
  py: (f) => `python3 ${shellQuote(f)}`,
  pyi: (f) => `python3 ${shellQuote(f)}`,
  // JavaScript / TypeScript (mjs: --experimental-modules was removed in
  // modern node — plain `node` handles .mjs natively)
  js: (f) => `node ${shellQuote(f)}`,
  mjs: (f) => `node ${shellQuote(f)}`,
  cjs: (f) => `node ${shellQuote(f)}`,
  ts: (f) => `npx tsx ${shellQuote(f)}`,
  tsx: (f) => `npx tsx ${shellQuote(f)}`,
  jsx: (f) => `npx tsx ${shellQuote(f)}`,
  // Go
  go: (f) => `go run ${shellQuote(f)}`,
  // Rust (unique output path so parallel runs never clobber each other;
  // rustc -o already marks the binary executable, no chmod needed)
  rs: (f) => {
    const out = `/tmp/tto-run-${Date.now()}`;
    return `rustc ${shellQuote(f)} -o ${out} && ${out}`;
  },
  // Shell
  sh: (f) => `bash ${shellQuote(f)}`,
  bash: (f) => `bash ${shellQuote(f)}`,
  zsh: (f) => `zsh ${shellQuote(f)}`,
  // Ruby
  rb: (f) => `ruby ${shellQuote(f)}`,
  // HTML (open in browser)
  html: (f) => `open ${shellQuote(f)}`,
  htm: (f) => `open ${shellQuote(f)}`,
  // PHP
  php: (f) => `php ${shellQuote(f)}`,
  // C / C++ (compile to a per-run binary in /tmp, then execute)
  c: (f) => {
    const out = `/tmp/tto-c-${Date.now()}`;
    return `gcc ${shellQuote(f)} -o ${out} && ${out}`;
  },
  cpp: (f) => {
    const out = `/tmp/tto-cpp-${Date.now()}`;
    return `g++ ${shellQuote(f)} -o ${out} && ${out}`;
  },
  // Java: javac writes Foo.class next to the source, then `java Foo` runs it.
  java: (f) => {
    const parts = f.split('/');
    const file = parts.pop() || 'Main.java';
    const dir = parts.join('/');
    const base = file.replace(/\.java$/i, '');
    return `cd ${shellQuote(dir || '.')} && javac ${shellQuote(file)} && java ${shellQuote(base)}`;
  },
  // Swift (interpreter mode)
  swift: (f) => `swift ${shellQuote(f)}`,
};

/** Detect language from filename. */
function detectLanguage(filename: string): { lang: string; cmd: ((f: string) => string) | null } {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  const langMap: Record<string, string> = {
    py: 'Python',
    pyi: 'Python',
    js: 'JavaScript',
    mjs: 'JavaScript',
    cjs: 'JavaScript',
    ts: 'TypeScript',
    tsx: 'TypeScript',
    jsx: 'TypeScript',
    go: 'Go',
    rs: 'Rust',
    sh: 'Shell',
    bash: 'Shell',
    zsh: 'Shell',
    rb: 'Ruby',
    php: 'PHP',
    html: 'HTML',
    htm: 'HTML',
    c: 'C',
    cpp: 'C++',
    java: 'Java',
    swift: 'Swift',
    // Read-only formats — recognized, but no run command (UI shows "Cannot run")
    css: 'CSS',
    json: 'JSON',
  };
  return {
    lang: langMap[ext] || ext.toUpperCase() || 'Unknown',
    cmd: RUN_COMMANDS[ext] || null,
  };
}

interface OutputLine {
  type: 'stdout' | 'stderr' | 'info';
  text: string;
}

export function CodeRunner({
  activeFile,
  activeFileName,
  terminals,
  onSendCommand,
  preferredTty,
}: Props) {
  const [output, setOutput] = useState<OutputLine[]>([]);
  const [running, setRunning] = useState(false);
  const [exitCode, setExitCode] = useState<number | null>(null);

  const fileName = activeFileName || activeFile?.split('/').pop() || '';
  const { lang, cmd } = detectLanguage(fileName);
  const canRun = !!cmd && !!activeFile;

  const handleRun = useCallback(async () => {
    if (!cmd || !activeFile) return;
    setRunning(true);
    setOutput([{ type: 'info', text: `▶ Running ${fileName} (${lang})...` }]);
    setExitCode(null);

    const command = cmd(activeFile);

    try {
      // Prefer the ACTIVE workspace's terminal (threaded via preferredTty);
      // fall back to ttys[0] ONLY when exactly one terminal exists.
      const ttys = terminals ? Object.keys(terminals) : [];
      const targetTty =
        preferredTty && ttys.includes(preferredTty)
          ? preferredTty
          : ttys.length === 1
            ? ttys[0]
            : '';

      // When a real terminal target exists (any mode), hand the command to the
      // PTY so it runs interactively (servers, watch loops, etc all work).
      if (targetTty && onSendCommand) {
        onSendCommand(targetTty, command);
        setOutput((prev) => [
          ...prev,
          { type: 'info', text: `Sent to terminal: ${targetTty}` },
          { type: 'stdout', text: `$ ${command}` },
        ]);
        // We can't capture output when sending to terminal — just show what we sent
        setRunning(false);
        setExitCode(0);
        return;
      }

      // No terminal target — fall back to the backend /api/run (BLOCKING
      // capture). Works in web mode AND in Tauri when no terminal exists, so
      // the "No terminal available" dead end is gone.
      const res = await fetch(`${apiBase()}/api/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, cwd: activeFile.split('/').slice(0, -1).join('/') }),
      });
      if (!res.ok) {
        // Surface non-2xx instead of failing inside res.json() with a cryptic error
        let msg = `Run failed (HTTP ${res.status})`;
        try {
          const j = await res.json();
          if (j.detail) msg = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail);
          else if (j.message) msg = j.message;
        } catch {
          /* non-JSON body */
        }
        throw new Error(msg);
      }
      const data = await res.json();
      const lines: OutputLine[] = [{ type: 'info', text: 'No terminal — ran via /api/run' }];
      if (data.stdout) lines.push({ type: 'stdout', text: data.stdout });
      if (data.stderr) lines.push({ type: 'stderr', text: data.stderr });
      if (!data.stdout && !data.stderr) lines.push({ type: 'info', text: '(no output)' });
      // The 90s timeout case: tell the user to use the in-IDE terminal instead
      if (data.timeout) {
        lines.push({
          type: 'info',
          text: 'Command timed out after 90s — use the in-IDE terminal for long-running servers',
        });
      }
      setOutput((prev) => [...prev, ...lines]);
      setExitCode(data.exit_code ?? data.exitCode ?? 0);
      setRunning(false);
    } catch (e: any) {
      setOutput((prev) => [...prev, { type: 'stderr', text: e?.message || 'Run failed' }]);
      setRunning(false);
      setExitCode(1);
    }
  }, [activeFile, cmd, lang, fileName, terminals, onSendCommand, preferredTty]);

  const handleClear = useCallback(() => {
    setOutput([]);
    setExitCode(null);
  }, []);

  return (
    <div className="code-runner-panel">
      <div className="code-runner-header">
        <span className="code-runner-title">Run / Compile</span>
        {canRun && <span className="code-runner-lang">{lang}</span>}
        {running ? (
          <button className="code-runner-run" disabled>
            <span className="spinner" /> Running...
          </button>
        ) : (
          <button
            className="code-runner-run"
            onClick={handleRun}
            disabled={!canRun}
            title={canRun ? `Run ${fileName}` : 'No runnable file selected'}
          >
            ▶ Run
          </button>
        )}
      </div>
      {!canRun && activeFile && (
        <div style={{ fontSize: 11, color: 'var(--muted)', padding: '4px 0' }}>
          Cannot run {fileName} — no run command configured for .{fileName.split('.').pop()}
        </div>
      )}
      {!activeFile && (
        <div style={{ fontSize: 11, color: 'var(--muted)', padding: '4px 0' }}>
          Open a file to see run options
        </div>
      )}
      {output.length > 0 && (
        <>
          <div className="code-runner-output">
            {output.map((line, i) => (
              <div key={i} className={`runner-line ${line.type}`}>
                {line.text}
              </div>
            ))}
          </div>
          <div className="code-runner-status">
            {exitCode !== null && (
              <>
                {exitCode === 0 ? (
                  <span className="runner-exit ok">✓ Exit 0</span>
                ) : (
                  <span className="runner-exit fail">✗ Exit {exitCode}</span>
                )}
              </>
            )}
            <div style={{ flex: 1 }} />
            <button
              className="go-live-refresh"
              onClick={handleClear}
              style={{ fontSize: 10, padding: '2px 6px' }}
            >
              Clear
            </button>
          </div>
        </>
      )}
    </div>
  );
}
