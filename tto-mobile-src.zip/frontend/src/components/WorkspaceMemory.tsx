import { useState, useEffect, useRef, useCallback } from 'react';
import type { Workspace } from '../workspace';
import { modifierLabel } from '../lib/format';

export interface MemoryEntry {
  id: string;
  workspace_id: string;
  kind: 'note' | 'todo' | 'context';
  content: string;
  done: boolean;
  created_at: number;
  updated_at: number;
}

interface Props {
  workspaces: Workspace[];
  activeId?: string;
  onToast: (msg: string, error?: boolean) => void;
}

const STORAGE_KEY = 'tto-workspace-memory';

function loadMemory(): MemoryEntry[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveMemory(entries: MemoryEntry[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
}

function genId(): string {
  return `mem-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function WorkspaceMemory({ workspaces, activeId, onToast }: Props) {
  const ws = workspaces.find((w) => w.id === activeId) || workspaces[0];
  const [entries, setEntries] = useState<MemoryEntry[]>(() => loadMemory());
  const [newText, setNewText] = useState('');
  const [newKind, setNewKind] = useState<'note' | 'todo' | 'context'>('todo');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [filterKind, setFilterKind] = useState<'all' | 'note' | 'todo' | 'context'>('all');
  const [showDone, setShowDone] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const editRef = useRef<HTMLTextAreaElement>(null);

  // Persist whenever entries change
  useEffect(() => {
    saveMemory(entries);
  }, [entries]);

  // Auto-focus new entry input
  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, [ws?.id]);

  const wsEntries = entries
    .filter((e) => e.workspace_id === ws?.id)
    .filter((e) => filterKind === 'all' || e.kind === filterKind)
    .filter((e) => showDone || !e.done)
    .sort((a, b) => b.created_at - a.created_at);

  const addEntry = useCallback(() => {
    const text = newText.trim();
    if (!text || !ws) return;
    const entry: MemoryEntry = {
      id: genId(),
      workspace_id: ws.id,
      kind: newKind,
      content: text,
      done: false,
      created_at: Date.now(),
      updated_at: Date.now(),
    };
    setEntries((prev) => [entry, ...prev]);
    setNewText('');
    onToast(
      `${newKind === 'todo' ? '✅ TODO' : newKind === 'note' ? '📝 Note' : '🧠 Context'} added to ${ws.name}`,
    );
  }, [newText, newKind, ws, onToast]);

  const toggleDone = useCallback((id: string) => {
    setEntries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, done: !e.done, updated_at: Date.now() } : e)),
    );
  }, []);

  const deleteEntry = useCallback(
    (id: string) => {
      setEntries((prev) => prev.filter((e) => e.id !== id));
      onToast('Entry deleted');
    },
    [onToast],
  );

  const startEdit = useCallback((entry: MemoryEntry) => {
    setEditingId(entry.id);
    setEditText(entry.content);
    setTimeout(() => editRef.current?.focus(), 50);
  }, []);

  const saveEdit = useCallback(() => {
    if (!editingId) return;
    setEntries((prev) =>
      prev.map((e) =>
        e.id === editingId ? { ...e, content: editText, updated_at: Date.now() } : e,
      ),
    );
    setEditingId(null);
    setEditText('');
  }, [editingId, editText]);

  const exportMemory = useCallback(() => {
    const md = wsEntries
      .map((e) => {
        const check = e.done ? '[x]' : '[ ]';
        const icon = e.kind === 'todo' ? `- ${check} ` : e.kind === 'note' ? '> ' : '## ';
        return `${icon}${e.content}`;
      })
      .join('\n\n');
    navigator.clipboard.writeText(md).then(
      () => onToast(`📋 Copied ${wsEntries.length} entries as markdown`),
      () => onToast('Failed to copy', true),
    );
  }, [wsEntries, onToast]);

  const getMemoryContext = useCallback(() => {
    const allTodo = entries.filter(
      (e) => e.workspace_id === ws?.id && e.kind === 'todo' && !e.done,
    );
    const allContext = entries.filter((e) => e.workspace_id === ws?.id && e.kind === 'context');
    const parts: string[] = [];
    if (allContext.length) {
      parts.push('## Workspace Context\n' + allContext.map((e) => e.content).join('\n'));
    }
    if (allTodo.length) {
      parts.push('## Pending TODOs\n' + allTodo.map((e, i) => `${i + 1}. ${e.content}`).join('\n'));
    }
    return parts.join('\n\n');
  }, [entries, ws]);

  if (!ws) {
    return (
      <div className="mem-wrap">
        <div className="mem-empty">Open a workspace to view its memory</div>
      </div>
    );
  }

  const todoCount = entries.filter(
    (e) => e.workspace_id === ws.id && e.kind === 'todo' && !e.done,
  ).length;
  const noteCount = entries.filter((e) => e.workspace_id === ws.id && e.kind === 'note').length;
  const ctxCount = entries.filter((e) => e.workspace_id === ws.id && e.kind === 'context').length;

  return (
    <div className="mem-wrap">
      {/* Header */}
      <div className="mem-header">
        <div className="mem-header-left">
          <span className="logo">tto</span>
          <span className="mem-title">Memory</span>
          <span className="mem-ws-name">{ws.name}</span>
        </div>
        <div className="mem-header-stats">
          <span className="mem-stat" title="Pending TODOs">
            ✅ {todoCount}
          </span>
          <span className="mem-stat" title="Notes">
            📝 {noteCount}
          </span>
          <span className="mem-stat" title="Context">
            🧠 {ctxCount}
          </span>
          <button className="mem-btn" onClick={exportMemory} title="Copy all as markdown">
            📋 Export
          </button>
        </div>
      </div>

      {/* New entry composer */}
      <div className="mem-composer">
        <div className="mem-composer-row">
          <div className="mem-kind-tabs">
            <button
              className={`mem-kind-tab ${newKind === 'todo' ? 'active' : ''}`}
              onClick={() => setNewKind('todo')}
            >
              ✅ TODO
            </button>
            <button
              className={`mem-kind-tab ${newKind === 'note' ? 'active' : ''}`}
              onClick={() => setNewKind('note')}
            >
              📝 Note
            </button>
            <button
              className={`mem-kind-tab ${newKind === 'context' ? 'active' : ''}`}
              onClick={() => setNewKind('context')}
            >
              🧠 Context
            </button>
          </div>
        </div>
        <textarea
          ref={inputRef}
          className="mem-input"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
              e.preventDefault();
              addEntry();
            }
          }}
          placeholder={
            newKind === 'todo'
              ? `Add a TODO item... (${modifierLabel()}+Enter to save)`
              : newKind === 'note'
                ? `Write a note... (${modifierLabel()}+Enter to save)`
                : `Add workspace context for agents... (${modifierLabel()}+Enter to save)`
          }
          rows={2}
        />
        <div className="mem-composer-actions">
          <button className="mem-add-btn" onClick={addEntry} disabled={!newText.trim()}>
            + Add {newKind === 'todo' ? 'TODO' : newKind === 'note' ? 'Note' : 'Context'}
          </button>
          <span className="mem-hint">{modifierLabel()}+Enter to save</span>
        </div>
      </div>

      {/* Filters */}
      <div className="mem-filters">
        <button
          className={`mem-filter ${filterKind === 'all' ? 'active' : ''}`}
          onClick={() => setFilterKind('all')}
        >
          All
        </button>
        <button
          className={`mem-filter ${filterKind === 'todo' ? 'active' : ''}`}
          onClick={() => setFilterKind('todo')}
        >
          ✅ TODOs
        </button>
        <button
          className={`mem-filter ${filterKind === 'note' ? 'active' : ''}`}
          onClick={() => setFilterKind('note')}
        >
          📝 Notes
        </button>
        <button
          className={`mem-filter ${filterKind === 'context' ? 'active' : ''}`}
          onClick={() => setFilterKind('context')}
        >
          🧠 Context
        </button>
        <label className="mem-show-done">
          <input
            type="checkbox"
            checked={showDone}
            onChange={(e) => setShowDone(e.target.checked)}
          />
          Show done
        </label>
      </div>

      {/* Entries list */}
      <div className="mem-entries">
        {wsEntries.length === 0 && (
          <div className="mem-empty-state">
            <div className="mem-empty-icon">🧠</div>
            <div className="mem-empty-title">No memory yet</div>
            <div className="mem-empty-sub">
              Add TODOs, notes, and context for this workspace.
              <br />
              Agents in the orchestrator can read this memory when executing tasks.
            </div>
          </div>
        )}
        {wsEntries.map((entry) => (
          <div
            key={entry.id}
            className={`mem-entry mem-entry-${entry.kind} ${entry.done ? 'done' : ''}`}
          >
            <div className="mem-entry-left">
              {entry.kind === 'todo' && (
                <button
                  className={`mem-checkbox ${entry.done ? 'checked' : ''}`}
                  onClick={() => toggleDone(entry.id)}
                  title={entry.done ? 'Mark incomplete' : 'Mark done'}
                >
                  {entry.done ? '✓' : ''}
                </button>
              )}
              {entry.kind === 'note' && <span className="mem-entry-icon">📝</span>}
              {entry.kind === 'context' && <span className="mem-entry-icon">🧠</span>}
            </div>
            <div className="mem-entry-body">
              {editingId === entry.id ? (
                <div className="mem-edit-row">
                  <textarea
                    ref={editRef}
                    className="mem-edit-input"
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) saveEdit();
                      if (e.key === 'Escape') {
                        setEditingId(null);
                        setEditText('');
                      }
                    }}
                    rows={3}
                  />
                  <div className="mem-edit-actions">
                    <button className="mem-btn-sm" onClick={saveEdit}>
                      Save
                    </button>
                    <button
                      className="mem-btn-sm mem-btn-cancel"
                      onClick={() => {
                        setEditingId(null);
                        setEditText('');
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mem-entry-content" onClick={() => startEdit(entry)}>
                  {entry.content}
                </div>
              )}
              <div className="mem-entry-meta">
                <span className="mem-entry-time">
                  {new Date(entry.created_at).toLocaleString()}
                </span>
                {entry.updated_at !== entry.created_at && (
                  <span className="mem-entry-edited">(edited)</span>
                )}
              </div>
            </div>
            <div className="mem-entry-actions">
              <button className="mem-btn-icon" onClick={() => startEdit(entry)} title="Edit">
                ✏️
              </button>
              <button
                className="mem-btn-icon mem-btn-delete"
                onClick={() => deleteEntry(entry.id)}
                title="Delete"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Memory context preview (what agents see) */}
      {wsEntries.length > 0 && (
        <div className="mem-context-preview">
          <div
            className="mem-context-header"
            onClick={() => {
              const el = document.querySelector('.mem-context-body');
              if (el) el.classList.toggle('collapsed');
            }}
          >
            <span>🔍 What agents see (memory context)</span>
            <span className="mem-context-toggle">▼</span>
          </div>
          <pre className="mem-context-body">{getMemoryContext() || '(no pending items)'}</pre>
        </div>
      )}
    </div>
  );
}
