import { useState, useEffect, useRef } from 'react';
import { getGitStatus } from '../api/client';

interface Props {
  /** Workspace path relative to home, e.g. 'tto-web' */
  workspacePath?: string;
  /** Callback when user clicks the badge */
  onOpenInTerminal?: () => void;
}

interface GitInfo {
  branch: string | null;
  changedCount: number;
  isInRepo: boolean;
}

export function GitStatusBadge({ workspacePath, onOpenInTerminal }: Props) {
  const [info, setInfo] = useState<GitInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await getGitStatus(workspacePath || '');
      if (res && typeof res === 'object' && 'in_repo' in res) {
        const data = res as {
          in_repo: boolean;
          branch?: string | null;
          files?: Array<{ path: string; status: string }>;
        };
        setInfo({
          isInRepo: data.in_repo,
          branch: data.branch || null,
          changedCount: (data.files || []).filter((f) => f.status !== '?').length,
        });
      } else {
        setInfo(null);
      }
    } catch {
      setInfo(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    timerRef.current = setInterval(fetchStatus, 30000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [workspacePath]);

  if (!info?.isInRepo) return null;
  if (!info.branch) return null;

  const hasChanges = info.changedCount > 0;

  return (
    <button
      className="git-badge"
      onClick={onOpenInTerminal}
      title={`Git: ${info.branch}${hasChanges ? ` · ${info.changedCount} change${info.changedCount > 1 ? 's' : ''}` : ' · clean'}`}
    >
      <span className={`git-dot ${hasChanges ? 'dirty' : 'clean'}`} />
      <span className="git-branch">{info.branch}</span>
      {hasChanges && <span className="git-count">{info.changedCount}</span>}
      {loading && <span className="git-spinner">⟳</span>}
    </button>
  );
}
