import { useCallback, useEffect, useRef, useState } from 'react';
import { TerminalAnchor } from './TerminalHost';
import { TerminalInput } from '../terminal/TerminalInput';
import { TerminalManager } from '../terminal/TerminalManager';
import { isTauri } from '../terminal/channels';
import { extractDropPaths } from '../terminal/dropPaths';
import { cleanModel, isClosed } from '../lib/format';
import { normalizeClaudeFresh } from '../lib/claude';
import type { UnifiedTerminal } from '../types';
import { DropChipStrip, type DropChip } from './DroppedFileChip';

interface Props {
  /** Session id of the terminal to display (the "focused" terminal). */
  sessionId: string | null;
  /** Every workspace pane session id to keep MOUNTED (persistent panes across
   *  all workspaces). Only the focused one is visible; the rest are hidden via
   *  CSS so their xterm instances (and scrollback) survive tab switches. */
  sessionIds: string[];
  /** Session ids of the ACTIVE workspace's panes — rendered side-by-side in
   *  split mode (viewMode === 'split'). */
  splitSessionIds?: string[];
  /** Layout mode for the left panel: 'focus' shows one full terminal,
   *  'split' shows the active workspace's terminals side by side. */
  viewMode?: 'focus' | 'split';
  /** Click a split pane to focus it. */
  onSelectTerminal?: (sessionId: string) => void;
  /** All unified terminals for metadata lookups. */
  terminals: Record<string, UnifiedTerminal>;
  /** Restart a terminal. */
  onRestart?: (sessionId: string) => void;
  /** Kill a terminal. */
  onKill?: (sessionId: string) => void;
  /** Create a new terminal. */
  onNewTerminal?: () => void;
  /** Whether this workspace is currently visible (drives xterm visibility/focus). */
  visible: boolean;
  /** Number of pending new lines while user is scrolled up. */
  pendingLines: number;
  /** Callback when user scrolls to bottom (clears pending indicator). */
  onScrollToBottom?: () => void;
  /** Drop files into the focused terminal (called with session id + paths). */
  onDrop?: (sessionId: string, paths: string[]) => void;
  /** Toast notification callback. */
  onToast?: (msg: string, error?: boolean) => void;
  /** Attached-file chips (ChatGPT-style) pinned above the terminal input. */
  chips?: DropChip[];
  /** Dismiss a single chip (per-chip ✕). */
  onDismissChip?: (id: number) => void;
  /** Clear all chips for this terminal. */
  onClearChips?: () => void;
}

/**
 * The primary terminal viewport — occupies the LEFT side of the workspace.
 *
 * Structure:
 *   ┌──────────────────────────────────┐
 *   │ TERMINAL HEADER (fixed, ~36px)   │
 *   ├──────────────────────────────────┤
 *   │                                  │
 *   │  SCROLLABLE TERMINAL OUTPUT      │
 *   │  (xterm.js, full height)         │
 *   │                                  │
 *   │  No max-height.                  │
 *   │  No card wrapper.                │
 *   │  No content clipping.            │
 *   │                                  │
 *   ├──────────────────────────────────┤
 *   │ COMMAND INPUT (fixed, ~32px)     │
 *   └──────────────────────────────────┘
 *
 * The terminal output area uses `flex: 1; min-height: 0` to consume ALL
 * remaining vertical space.  xterm.js handles its own scrolling natively.
 */
export function TerminalWorkspace({
  sessionId,
  sessionIds,
  splitSessionIds,
  viewMode,
  onSelectTerminal,
  terminals,
  onRestart,
  onKill,
  onNewTerminal,
  visible,
  pendingLines,
  onScrollToBottom,
  onDrop,
  onToast,
  chips,
  onDismissChip,
  onClearChips,
}: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // `sessionId` is the Rust session id (== pane.tty in Tauri). `terminals`
  // (unifiedTerminals) is keyed by OS tty and carries the Rust id on its
  // `session_id` field — so `terminals[sessionId]` MISSES native sessions.
  // Fall back to a session_id match so the header shows agent/model/status
  // and the renamed title in Tauri.
  const entry = sessionId
    ? terminals[sessionId] || Object.values(terminals).find((u) => u.session_id === sessionId)
    : undefined;
  const agent = entry?.agent || '';
  const model = entry?.model || (entry as any)?.applied_model || '';
  const shortModel = model ? cleanModel(model) : '';
  const cwd = entry?.cwd || '';
  const title = entry?.session_name || sessionId || '';
  const isRunning = entry && !isClosed(entry);
  const statusText = isRunning ? 'Running' : entry ? 'Exited' : 'No terminal';
  const statusClass = isRunning ? 'running' : entry ? 'exited' : 'empty';

  // Split-pane header metadata: resolve a session id to its title/agent like
  // the focused header above does (unifiedTerminals is keyed by OS tty, with
  // session_id fallback for native sessions).
  const paneTitle = useCallback(
    (sid: string) => {
      const e = sid
        ? terminals[sid] || Object.values(terminals).find((u) => u.session_id === sid)
        : undefined;
      return e?.session_name || sid || 'Terminal';
    },
    [terminals],
  );

  // Context menu close on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handler);
    return () => window.removeEventListener('mousedown', handler);
  }, [menuOpen]);

  // Auto-focus the terminal when it becomes the focused terminal
  useEffect(() => {
    if (!sessionId || !visible) return;
    const handle = TerminalManager.get(sessionId);
    if (handle?.term) {
      try {
        handle.term.focus();
      } catch {
        /* disposed */
      }
    }
  }, [sessionId, visible]);

  const handleRestart = useCallback(() => {
    if (sessionId) {
      onRestart?.(sessionId);
      setMenuOpen(false);
    }
  }, [sessionId, onRestart]);

  const handleKill = useCallback(() => {
    if (!sessionId) return;
    const confirmed = window.confirm(
      `Kill terminal "${title || sessionId}"?\n\nThis destroys the running session and any in-progress agent work in it. This cannot be undone.`,
    );
    if (confirmed) {
      onKill?.(sessionId);
    }
    setMenuOpen(false);
  }, [sessionId, title, onKill]);

  const handleClear = useCallback(() => {
    if (!sessionId) return;
    const handle = TerminalManager.get(sessionId);
    if (handle?.term) {
      try {
        handle.term.clear();
      } catch {
        /* noop */
      }
    }
    setMenuOpen(false);
  }, [sessionId]);

  const handleCopy = useCallback(() => {
    if (!sessionId) return;
    const handle = TerminalManager.get(sessionId);
    if (handle?.term) {
      const sel = handle.term.getSelection();
      if (sel) navigator.clipboard.writeText(sel).catch(() => {});
    }
    setMenuOpen(false);
  }, [sessionId]);

  const handlePaste = useCallback(() => {
    if (!sessionId) return;
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text) TerminalManager.write(sessionId, normalizeClaudeFresh(text));
      })
      .catch(() => {});
    setMenuOpen(false);
  }, [sessionId]);

  // ── Persistent slot anchors ───────────────────────────────────────────
  // This view no longer renders xterm instances directly — TerminalHost (App
  // level, always mounted) owns ONE <TerminalPane> per session and physically
  // moves each session's slot div into the anchor rendered below. All anchors
  // stay mounted here across focus changes, so switching the focused terminal
  // is a pure CSS show/hide: no xterm is disposed, no scrollback is lost.
  // Anchors keep today's offscreen-parking semantics: the ACTIVE anchor is
  // displayed in place, the rest are parked OFFSCREEN at full size (never
  // display:none) — collapsing xterm's host to 0×0 invalidates its render
  // dimensions and the row cache never recovers.
  const mountedIds = Array.from(new Set([...sessionIds, ...(sessionId ? [sessionId] : [])]));

  // ── Drop zone: catch file drops from the sidebar ────────────────────────
  // The sidebar's FileBrowser sets text/plain data on dragstart. When the
  // user drops onto this workspace, we read the path and route it to the
  // focused terminal via onDrop. Without this, drops from the sidebar miss
  // the terminal pane's native handlers because xterm's canvas intercepts
  // the event before it reaches the .term-pane host.
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (!sessionId || !onDrop) return;
      const dt = e.dataTransfer;
      // Single extraction covers OS files, sidebar text drags and WebKit
      // uri-list drops (see terminal/dropPaths.ts). Routing through onDrop →
      // App.handleDrop, which dedupes, so this recovery layer is idempotent
      // even when a lower layer already routed the same drop.
      const paths = extractDropPaths(dt);
      if (paths.length > 0) {
        onDrop(sessionId, paths);
        onToast?.(`Dropped ${paths.length} file(s)`);
      }
    },
    [sessionId, onDrop, onToast],
  );

  return (
    <div
      className="terminal-workspace"
      data-tto-session={sessionId || ''}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* ── Fixed header ── */}
      <div className="tw-header">
        <span className={`tw-status-dot ${statusClass}`} />
        <span className="tw-title">
          {sessionId ? title : 'No Terminal Selected'}
          {agent && <span className="tw-agent">{agent}</span>}
          {shortModel && <span className="tw-model">{shortModel}</span>}
        </span>
        {sessionId && <span className="tw-status">{statusText}</span>}
        {cwd && (
          <span className="tw-cwd" title={cwd}>
            📁 {cwd}
          </span>
        )}

        <div className="tw-header-spacer" />

        {/* Pending lines indicator */}
        {pendingLines > 0 && sessionId && (
          <button
            className="tw-pending-indicator"
            onClick={() => {
              onScrollToBottom?.();
              // Scroll the xterm viewport to bottom
              const handle = TerminalManager.get(sessionId);
              if (handle?.term) {
                try {
                  handle.term.scrollToBottom();
                  handle.term.focus();
                } catch {
                  /* noop */
                }
              }
            }}
            title={`${pendingLines} new lines — click to scroll down`}
          >
            ↓ {pendingLines} new
          </button>
        )}

        {/* Context menu */}
        {sessionId && (
          <div className="tw-menu-wrap" ref={menuRef}>
            <button
              className="tw-menu-btn"
              onClick={() => setMenuOpen((o) => !o)}
              title="Terminal menu"
            >
              ⋮
            </button>
            {menuOpen && (
              <div className="tw-menu">
                <button className="tw-menu-item" onClick={handleCopy}>
                  Copy
                </button>
                <button className="tw-menu-item" onClick={handlePaste}>
                  Paste
                </button>
                <button className="tw-menu-item" onClick={handleClear}>
                  Clear
                </button>
                <div className="tw-menu-sep" />
                <button className="tw-menu-item" onClick={handleRestart}>
                  Restart
                </button>
                <button className="tw-menu-item danger" onClick={handleKill}>
                  Kill
                </button>
                {onNewTerminal && (
                  <>
                    <div className="tw-menu-sep" />
                    <button
                      className="tw-menu-item"
                      onClick={() => {
                        onNewTerminal();
                        setMenuOpen(false);
                      }}
                    >
                      New Terminal
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Persistent terminal panes ──
          FOCUS MODE: only the focused one is visible; the rest parked offscreen.
          SPLIT MODE:  the active workspace's panes render side-by-side in a
          responsive grid, each with its own mini header + anchor. */}
      <div className={`tw-output${viewMode === 'split' ? ' split' : ''}`}>
        {viewMode === 'split' && splitSessionIds && splitSessionIds.length > 0 ? (
          <div className="tw-split-grid">
            {splitSessionIds.map((sid, i) => {
              const active = sid === sessionId;
              return (
                <div
                  key={sid}
                  className={`tw-split-pane${active ? ' focused' : ''}`}
                  data-tto-session={sid}
                  onClick={() => {
                    if (!active) onSelectTerminal?.(sid);
                  }}
                  title={active ? undefined : 'Click to focus'}
                >
                  <div className="tw-split-pane-head">
                    <span className="tw-split-num">{String(i + 1).padStart(2, '0')}</span>
                    <span className="tw-split-name" title={paneTitle(sid)}>
                      {paneTitle(sid)}
                    </span>
                    {active && <span className="tw-split-focused-badge">ACTIVE</span>}
                  </div>
                  <TerminalAnchor sessionId={sid} />
                </div>
              );
            })}
          </div>
        ) : (
          mountedIds.map((sid) => {
            const active = sid === sessionId;
            return (
              <div
                key={sid}
                aria-hidden={!active}
                className="tw-pane-slot"
                data-tto-session={sid}
                style={
                  active
                    ? { display: 'flex', flexDirection: 'column', flex: '1 1 0%', minHeight: 0 }
                    : // Inactive panes are parked OFFSCREEN at full size rather than
                      // display:none. Collapsing the host to 0×0 invalidates xterm's
                      // render dimensions and its row cache never recovers → the pane
                      // comes back blank. Keeping real dimensions also means no
                      // resize fires on show/hide, so the CLI gets no SIGWINCH burst.
                      {
                        display: 'flex',
                        flexDirection: 'column',
                        position: 'absolute',
                        left: '-99999px',
                        top: 0,
                        width: '100%',
                        height: '100%',
                        minHeight: 0,
                        pointerEvents: 'none',
                      }
                }
              >
                <TerminalAnchor sessionId={sid} />
              </div>
            );
          })
        )}

        {/* Empty state overlays when nothing is focused, WITHOUT unmounting the
            hidden panes above (so other workspaces' terminals aren't disposed).
            Not shown in split mode — the split panes remain visible there. */}
        {!sessionId && viewMode !== 'split' && (
          <div className="tw-empty">
            <img src="/desktop-icon.png" alt="tto" className="tw-empty-logo" />
            <div className="tw-empty-title">Select a terminal</div>
            <div className="tw-empty-sub">
              Choose a terminal from the control panel on the right, or create a new one.
            </div>
            {onNewTerminal && (
              <button className="btn primary" onClick={onNewTerminal}>
                + New Terminal
              </button>
            )}
          </div>
        )}
      </div>

      {/* ── Attached-file chips (ChatGPT-style) pinned just above the input ── */}
      {chips && chips.length > 0 && (
        <DropChipStrip
          chips={chips}
          onDismiss={onDismissChip || (() => {})}
          onClearAll={onClearChips || (() => {})}
        />
      )}

      {/* ── Fixed command input ── */}
      {isTauri() && sessionId && (
        <div className="tw-input-bar">
          <TerminalInput sessionId={sessionId} />
        </div>
      )}
    </div>
  );
}
