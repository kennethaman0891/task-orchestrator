import { useEffect, useState } from 'react';

export function LiveClock() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="live-clock">
      <span className="pulse"></span>
      <span>
        {now.toLocaleTimeString()} ·{' '}
        {now.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
      </span>
    </div>
  );
}
