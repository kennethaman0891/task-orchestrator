import { useEffect, useRef, useState } from 'react';
import type { Workspace, TemplateKey, GridMode } from '../workspace';
import { TEMPLATES, THEMES, GRID_MODES, templateLabel } from '../workspace';
import { modifierLabel } from '../lib/format';

export type View =
  | 'workspace'
  | 'grid'
  | 'kanban'
  | 'cards'
  | 'memory'
  | 'ceo'
  | 'planner'
  | 'wizard'
  | 'ide'
  | 'django-reviewer'
  | 'agent';

interface Props {
  workspaces: Workspace[];
  activeId: string;
  theme: string;
  sidebarOpen: boolean;
  view: View;
  onSelect: (id: string) => void;
  onNew: () => void;
  onClose: (id: string) => void;
  onTemplate: (ws: Workspace, tpl: TemplateKey) => void;
  onTheme: (name: string) => void;
  onToggleAutoExpand: (id: string, enabled: boolean) => void;
  onSetLayoutMode: (id: string, mode: GridMode) => void;
  onAddTerminal: () => void;
  onToggleSidebar: () => void;
  onView: (v: View) => void;
}

export function WorkspaceBar({
  workspaces,
  activeId,
  theme,
  sidebarOpen,
  view,
  onSelect,
  onNew,
  onClose,
  onTemplate,
  onTheme,
  onToggleAutoExpand,
  onSetLayoutMode,
  onAddTerminal,
  onToggleSidebar,
  onView,
}: Props) {
  const active = workspaces.find((w) => w.id === activeId) || workspaces[0];
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);

  // Close the ⋯ More menu on outside click.
  useEffect(() => {
    if (!moreOpen) return;
    const handler = (e: MouseEvent) => {
      const el = moreRef.current;
      if (el && !el.contains(e.target as Node)) setMoreOpen(false);
    };
    window.addEventListener('mousedown', handler);
    return () => window.removeEventListener('mousedown', handler);
  }, [moreOpen]);

  // Secondary controls — shown inline on wide screens, inside ⋯ on narrow ones.
  const cliToggle = active && (
    <label
      key="cli"
      className="ws-cli-toggle"
      title="Auto-expand a pane to the full workspace when a full-screen CLI (opencode, vim, htop…) starts; restores when it exits"
    >
      <input
        type="checkbox"
        checked={active.autoExpandTui !== false}
        onChange={(e) => onToggleAutoExpand(active.id, e.target.checked)}
      />
      <span>CLI ⤢</span>
    </label>
  );
  const templateSelect = active && (
    <select
      key="tpl"
      className="ws-select"
      value={active.template}
      onChange={(e) => onTemplate(active, Number(e.target.value) as TemplateKey)}
      title="Workspace template — how many terminal panes"
    >
      {(Object.keys(TEMPLATES) as unknown as TemplateKey[]).map((k) => (
        <option key={k} value={k}>
          {TEMPLATES[k].label} ({k})
        </option>
      ))}
    </select>
  );
  const themeSelect = (
    <select
      key="theme"
      className="ws-select"
      value={theme}
      onChange={(e) => onTheme(e.target.value)}
      title="Theme"
    >
      {THEMES.map((t) => (
        <option key={t.name} value={t.name}>
          {t.name}
        </option>
      ))}
    </select>
  );

  return (
    <div className="wsbar">
      <button
        className={`ws-btn ${sidebarOpen ? 'active' : ''}`}
        onClick={onToggleSidebar}
        title="Toggle file sidebar"
      >
        ☰
      </button>
      <div className="ws-tabs">
        {workspaces.map((w) => (
          <div
            key={w.id}
            className={`ws-tab ${w.id === active?.id ? 'active' : ''}`}
            onClick={() => onSelect(w.id)}
            title={`${w.name} — ${templateLabel(w.template)} template`}
          >
            <span className="ws-dot" style={{ background: w.color }} />
            <span className="ws-name">{w.name}</span>
            <button
              className="ws-close"
              onClick={(e) => {
                e.stopPropagation();
                onClose(w.id);
              }}
              title="Close workspace"
            >
              ×
            </button>
          </div>
        ))}
        <button className="ws-new" onClick={onNew} title={`New workspace (${modifierLabel()}+T)`}>
          +
        </button>
      </div>
      <div className="ws-controls">
        <button className="ws-add" onClick={onAddTerminal} title="Create terminal">
          +
        </button>
        {active && (
          <select
            className="ws-select"
            value={active.layoutMode ?? 'auto'}
            onChange={(e) => onSetLayoutMode(active.id, e.target.value as GridMode)}
            title="Grid layout mode — Auto adapts columns to the window, Grid uses the template design, Compact fits more terminals, Large shows fewer bigger ones"
          >
            {GRID_MODES.map((m) => (
              <option key={m.key} value={m.key} title={m.hint}>
                ▦ {m.label}
              </option>
            ))}
          </select>
        )}
        <div className="ws-secondary">
          {cliToggle}
          {templateSelect}
          {themeSelect}
        </div>
        <div className="ws-more-wrap" ref={moreRef}>
          <button
            className={`ws-btn ws-more-btn${moreOpen ? ' active' : ''}`}
            onClick={() => setMoreOpen((o) => !o)}
            title="More controls"
          >
            ⋯
          </button>
          {moreOpen && (
            <div className="ws-more-menu">
              {cliToggle}
              {templateSelect}
              {themeSelect}
            </div>
          )}
        </div>
        <div className="ws-view">
          <button
            className={`ws-btn ${view === 'workspace' ? 'active' : ''}`}
            onClick={() => onView('workspace')}
            title="Editor + Terminal (Cmd+P for command palette)"
          >
            ⊞
          </button>
          <button
            className={`ws-btn ${view === 'grid' ? 'active' : ''}`}
            onClick={() => onView('grid')}
            title="Card grid layout"
          >
            ▦
          </button>
          <button
            className={`ws-btn ${view === 'kanban' ? 'active' : ''}`}
            onClick={() => onView('kanban')}
            title="Orchestrator board"
          >
            ◫
          </button>
          <button
            className={`ws-btn ${view === 'cards' ? 'active' : ''}`}
            onClick={() => onView('cards')}
            title="Task center"
          >
            ▤
          </button>
          <button
            className={`ws-btn ${view === 'planner' || view === 'memory' || view === 'ceo' ? 'active' : ''}`}
            onClick={() => onView('planner')}
            title="Planner (CEO Scheduler + Memory)"
          >
            📋
          </button>
          <button
            className={`ws-btn ${view === 'ide' ? 'active' : ''}`}
            onClick={() => onView('ide')}
            title="IDE (VS Code layout)"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
              <path d="M6 3v14" />
              <path d="M10 3v14" />
              <path d="M14 3v14" />
              <path d="M18 3v14" />
            </svg>
          </button>
          <button
            className={`ws-btn ${view === 'django-reviewer' ? 'active' : ''}`}
            onClick={() => onView('django-reviewer')}
            title="Django Project Reviewer"
          >
            ✦
          </button>
          <button
            className={`ws-btn ${view === 'agent' ? 'active' : ''}`}
            onClick={() => onView('agent')}
            title="Agent Workspace (OpenCode)"
          >
            🤖
          </button>
        </div>
      </div>
    </div>
  );
}
