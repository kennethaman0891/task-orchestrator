import { useEffect, useState, useRef } from 'react';
import { searchFiles, type SearchResult } from '../api/client';

interface Props {
  onClose: () => void;
  onOpenFile?: (path: string, name: string, lineNumber?: number) => void;
  /** Workspace root to scope search to; empty/undefined -> backend falls back to whole home dir. */
  searchPath?: string;
}

export function SearchPanel({ onClose, onOpenFile, searchPath }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Debounced search
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    setSearchError(null);
    const timer = setTimeout(async () => {
      try {
        const data = await searchFiles(query, searchPath);
        setResults(data.results || []);
      } catch (e: any) {
        setSearchError(e.message || 'Search failed');
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query, searchPath]);

  const handleResultClick = (result: SearchResult) => {
    // Backend may return absolute paths; if not, resolve against searchPath.
    const fullPath = result.file.startsWith('/')
      ? result.file
      : searchPath
        ? `${searchPath}/${result.file}`
        : result.file;
    const fileName = fullPath.split('/').pop() || fullPath;
    onOpenFile?.(fullPath, fileName, result.line);
    onClose();
  };

  return (
    <div className="search-overlay">
      <div className="search-panel">
        <div className="search-header">
          <input
            ref={inputRef}
            type="text"
            className="search-input"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search in files... (Cmd+Shift+F)"
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
            }}
          />
          <button className="search-close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="search-scope">
          🔍 {searchPath ? `in ${searchPath}` : 'Whole home directory'}
        </div>

        {loading && <div className="search-loading">Searching...</div>}
        {searchError && <div className="search-error">{searchError}</div>}
        {!loading && !searchError && query.trim() && results.length === 0 && (
          <div className="search-empty">No results found</div>
        )}

        <div className="search-results">
          {results.map((result, i) => (
            <div key={i} className="search-result-item" onClick={() => handleResultClick(result)}>
              <div className="search-result-file">
                <span className="search-result-path">{result.file}</span>
                <span className="search-result-line">Line {result.line}</span>
              </div>
              <div className="search-result-content">
                <span className="search-match">{result.match}</span>
                {result.content.slice(0, 100)}
              </div>
            </div>
          ))}
        </div>

        {!loading && !searchError && query.trim() && results.length > 0 && (
          <div className="search-footer">
            {results.length} results in {new Set(results.map((r) => r.file)).size} files
          </div>
        )}
      </div>
    </div>
  );
}
