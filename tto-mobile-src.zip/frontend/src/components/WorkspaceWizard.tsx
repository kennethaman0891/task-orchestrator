import { useEffect, useMemo, useRef, useState } from 'react';
import { tauri, isTauri } from '../terminal/channels';
import { templateCols } from '../workspace';
import { baseName } from '../lib/format';

export interface WizardConfig {
  projectPath: string;
  command: string;
  template: number;
}

interface Props {
  onCreate: (config: WizardConfig) => void;
  onClose: () => void;
}

const MAX_TERMINALS = 16;
const GRID_COLS = 4;
const DEFAULT_TEMPLATE = 4;

const CLI_SUGGESTIONS = ['opencode', 'claude', 'codex', 'gemini', 'aider', 'cursor', 'kilo'];

/* ── Inline line icons (stroke = currentColor) ────────────────────────────
   Small coherent 24px line-icon set matching the app's existing style. */
function IconFolder() {
  return (
    <svg className="wz2-ico" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M3 7a2 2 0 0 1 2-2h3.5l2 2H19a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function IconFolderOpen() {
  return (
    <svg className="wz2-ico" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M4 6.5a1 1 0 0 1 1-1h3.2l2 2H18a1 1 0 0 1 1 1V11"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3 11h17.1a1 1 0 0 1 .97 1.25l-1.4 5.5A1 1 0 0 1 18.7 18.5H5a1 1 0 0 1-1-1V11Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// HOME_DIR is resolved asynchronously once the Tauri app is ready.
let HOME_DIR = ''; // empty = unknown — expandTilde falls through to raw path
if (isTauri()) {
  import('@tauri-apps/api/core')
    .then(({ invoke }) => {
      invoke<string | null>('get_home_dir')
        .then((h) => {
          if (h) HOME_DIR = h;
        })
        .catch(() => {});
    })
    .catch(() => {});
}

/** Expand ~ to the actual home directory path (client-side). */
function expandTilde(p: string): string {
  if (!p || !HOME_DIR) return p;
  if (p === '~') return HOME_DIR;
  // Use the platform-appropriate separator
  const sep = HOME_DIR.includes('\\') ? '\\' : '/';
  if (p.startsWith(`~${sep}`)) return HOME_DIR + p.slice(1);
  if (p.startsWith('~')) return HOME_DIR + p.slice(1);
  return p;
}

/**
 * Recently used project paths, harvested from persisted workspaces.
 * Fully defensive — never throws, never returns junk.
 */
function loadRecentPaths(): string[] {
  try {
    const raw = localStorage.getItem('tto-workspaces');
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const seen = new Set<string>();
    const out: string[] = [];
    for (const w of parsed) {
      const p =
        typeof (w as { projectPath?: unknown })?.projectPath === 'string'
          ? (w as { projectPath: string }).projectPath.trim()
          : '';
      if (p && !seen.has(p)) {
        seen.add(p);
        out.push(p);
        if (out.length >= 4) break;
      }
    }
    return out;
  } catch {
    return [];
  }
}

/**
 * New Workspace dialog (v2 redesign).
 *
 * A centered modal overlay — single screen, three compact sections
 * (Project Path, Launch Command, Terminal Layout) plus a live summary
 * footer. Drag & drop upload was removed by design; paths come from
 * typing, the native folder picker, or one-click recents.
 */
export function WorkspaceWizard({ onCreate, onClose }: Props) {
  const [projectPath, setProjectPath] = useState('');
  const [command, setCommand] = useState('');
  const [template, setTemplate] = useState<number>(DEFAULT_TEMPLATE);
  const [hoverCell, setHoverCell] = useState<number | null>(null);
  const [error, setError] = useState('');
  const pathRef = useRef<HTMLInputElement>(null);

  const recentPaths = useMemo(loadRecentPaths, []);

  // Focus the path input on open — ready to type immediately.
  useEffect(() => {
    pathRef.current?.focus();
  }, []);

  // Populate project path from the app's launch working directory when available.
  // This ensures new workspaces get a sensible default instead of an empty path
  // that would cause FileBrowser to show all home-directory files.
  const [launchCwdReady, setLaunchCwdReady] = useState(false);
  useEffect(() => {
    if (!isTauri() || launchCwdReady) return;
    tauri
      .getLaunchCwd()
      .then((cwd) => {
        if (cwd) setProjectPath(cwd);
        setLaunchCwdReady(true);
      })
      .catch(() => {
        setLaunchCwdReady(true);
      });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const submit = () =>
    onCreate({ projectPath: expandTilde(projectPath.trim()), command: command.trim(), template });

  // Keyboard: Esc closes, Enter submits (unless a button has focus —
  // focused buttons already fire their own click on Enter).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      if (e.key === 'Enter') {
        const el = document.activeElement;
        if (el && el.tagName === 'BUTTON') return;
        e.preventDefault();
        submit();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectPath, command, template, onClose]);

  const browseFolder = async () => {
    if (!isTauri()) {
      setError('Folder picking is only available in the desktop app.');
      return;
    }
    try {
      const picked = await tauri.pickFolder();
      if (picked) {
        setProjectPath(picked);
        setError('');
      }
    } catch {
      setError('Failed to open folder picker.');
    }
  };

  // Grid semantics: hovering previews a count without committing it.
  const activeCount = hoverCell ?? template;
  const cols = Math.min(GRID_COLS, templateCols(activeCount));
  const rows = Math.max(1, Math.ceil(activeCount / cols));

  // Filtered CLI suggestions (typeahead-style narrowing).
  const q = command.trim().toLowerCase();
  const visibleSuggestions = q ? CLI_SUGGESTIONS.filter((s) => s.includes(q)) : CLI_SUGGESTIONS;

  const expandedPath = expandTilde(projectPath.trim());
  const summary = [
    baseName(expandedPath) || 'Blank',
    `${template} terminal${template === 1 ? '' : 's'}`,
    command.trim() ? `launch "${command.trim()}"` : '',
  ]
    .filter(Boolean)
    .join(' · ');

  return (
    <div
      className="wz2-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="wz2-modal" role="dialog" aria-modal="true" aria-label="New Workspace">
        {/* ── Header ── */}
        <header className="wz2-head">
          <div>
            <h2 className="wz2-title">New Workspace</h2>
            <p className="wz2-sub">Spin up an AI terminal grid for a project</p>
          </div>
          <button className="wz2-close" onClick={onClose} title="Close (Esc)" aria-label="Close">
            ×
          </button>
        </header>

        <div className="wz2-body">
          {/* ── Project Path ── */}
          <section className="wz2-sec">
            <label className="wz2-label" htmlFor="wz2-path">
              Project Path
            </label>
            <div className="wz2-pathrow">
              <input
                id="wz2-path"
                ref={pathRef}
                className="wz2-input wz2-mono"
                placeholder="~/projects/my-app"
                value={projectPath}
                onChange={(e) => setProjectPath(e.target.value)}
                spellCheck={false}
              />
              <button className="wz2-btn" onClick={browseFolder}>
                <IconFolder /> Browse
              </button>
            </div>

            {projectPath && (
              <div className="wz2-chosen" title={projectPath}>
                <IconFolderOpen />
                <span className="wz2-chosen-text">{expandTilde(projectPath)}</span>
                <button
                  onClick={() => setProjectPath('')}
                  title="Clear path"
                  aria-label="Clear path"
                >
                  ✕
                </button>
              </div>
            )}

            {recentPaths.length > 0 && (
              <div className="wz2-recent">
                <span className="wz2-mini">Recent</span>
                {recentPaths.map((p) => (
                  <button
                    key={p}
                    className="wz2-chip wz2-mono"
                    title={p}
                    onClick={() => {
                      setProjectPath(p);
                      setError('');
                    }}
                  >
                    {baseName(p)}
                  </button>
                ))}
              </div>
            )}

            {error && <div className="wz2-error">{error}</div>}
          </section>

          {/* ── Launch Command ── */}
          <section className="wz2-sec">
            <label className="wz2-label" htmlFor="wz2-cmd">
              Launch Command
            </label>
            <p className="wz2-hint">
              Runs in every terminal the moment it opens — pick an AI CLI below, or leave blank for
              plain shells.
            </p>
            <input
              id="wz2-cmd"
              className="wz2-input wz2-mono"
              placeholder="e.g. opencode"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              spellCheck={false}
            />
            {visibleSuggestions.length > 0 && (
              <div className="wz2-sugg">
                {visibleSuggestions.map((s) => (
                  <button key={s} className="wz2-chip wz2-mono" onClick={() => setCommand(s)}>
                    {s}
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* ── Terminal Layout ── */}
          <section className="wz2-sec">
            <div className="wz2-labelrow">
              <label className="wz2-label" id="wz2-grid-label">
                Terminal Layout
              </label>
              <span className="wz2-count">
                {activeCount} terminal{activeCount === 1 ? '' : 's'} · {rows} × {cols}
              </span>
            </div>
            <div
              className="wz2-grid"
              role="group"
              aria-labelledby="wz2-grid-label"
              onMouseLeave={() => setHoverCell(null)}
            >
              {Array.from({ length: MAX_TERMINALS }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  className={`wz2-cell ${n <= activeCount ? 'on' : ''}`}
                  onMouseEnter={() => setHoverCell(n)}
                  onClick={() => {
                    setTemplate(n);
                    setError('');
                  }}
                  aria-label={`${n} terminal${n === 1 ? '' : 's'}`}
                  aria-pressed={n <= template}
                >
                  {n}
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* ── Footer ── */}
        <footer className="wz2-foot">
          <span className="wz2-summary" title={summary}>
            {summary}
          </span>
          <button className="wz2-create" onClick={submit}>
            Create Workspace
          </button>
        </footer>
      </div>
    </div>
  );
}
