import { useEffect, useRef, useState } from 'react';

interface Props {
  left: React.ReactNode;
  right: React.ReactNode;
  initialRatio?: number;
  minLeft?: number;
  minRight?: number;
  storageKey?: string;
  orientation?: 'horizontal' | 'vertical';
  onResize?: (ratio: number) => void;
}

export function SplitView({
  left,
  right,
  initialRatio = 0.5,
  minLeft = 200,
  minRight = 200,
  storageKey,
  orientation = 'horizontal',
  onResize,
}: Props) {
  const [ratio, setRatio] = useState(() => {
    if (storageKey) {
      const saved = parseFloat(localStorage.getItem(storageKey) ?? '');
      if (!isNaN(saved) && saved > 0 && saved < 1) return saved;
    }
    return initialRatio;
  });
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  // Persist ratio to localStorage
  useEffect(() => {
    if (storageKey) {
      localStorage.setItem(storageKey, String(ratio));
    }
    onResize?.(ratio);
  }, [ratio, storageKey, onResize]);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    document.body.style.cursor = orientation === 'horizontal' ? 'col-resize' : 'row-resize';
    document.body.style.userSelect = 'none';

    const onMove = (ev: MouseEvent) => {
      if (!isDragging.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      let newRatio: number;
      if (orientation === 'horizontal') {
        newRatio = (ev.clientX - rect.left) / rect.width;
      } else {
        newRatio = (ev.clientY - rect.top) / rect.height;
      }
      // Clamp using min pixel sizes
      const clamped = Math.max(minLeft / rect.width, Math.min(1 - minRight / rect.width, newRatio));
      setRatio(clamped);
    };

    const onUp = () => {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Touch support
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const startX = orientation === 'horizontal' ? touch.clientX : touch.clientY;
    const startRatio = ratio;

    isDragging.current = true;
    document.body.style.cursor = orientation === 'horizontal' ? 'col-resize' : 'row-resize';
    document.body.style.userSelect = 'none';

    const onMove = (ev: TouchEvent) => {
      if (!isDragging.current || !containerRef.current) return;
      const t = ev.touches[0];
      const pos = orientation === 'horizontal' ? t.clientX : t.clientY;
      const size = orientation === 'horizontal' ? rect.width : rect.height;
      const delta = (pos - startX) / size;
      const newRatio = Math.max(
        minLeft / rect.width,
        Math.min(1 - minRight / rect.width, startRatio + delta),
      );
      setRatio(newRatio);
    };

    const onEnd = () => {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
    };

    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('touchend', onEnd);
  };

  const leftPct = `${ratio * 100}%`;
  const rightPct = `${(1 - ratio) * 100}%`;

  return (
    <div
      ref={containerRef}
      className={`split-view split-view-${orientation}`}
      style={{
        display: 'flex',
        flexDirection: orientation === 'horizontal' ? 'row' : 'column',
        height: '100%',
        width: '100%',
        overflow: 'hidden',
      }}
    >
      <div
        className="split-view-left"
        style={{
          flex: `0 0 ${leftPct}`,
          minWidth: 0,
          minHeight: 0,
          overflow: 'hidden',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {left}
      </div>
      <div
        className="split-view-handle"
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        role="separator"
        aria-orientation={orientation === 'horizontal' ? 'vertical' : 'horizontal'}
        tabIndex={0}
        title="Drag to resize"
      >
        <div className="split-view-handle-lines">
          <span />
          <span />
          <span />
        </div>
      </div>
      <div
        className="split-view-right"
        style={{
          flex: `0 0 ${rightPct}`,
          minWidth: 0,
          minHeight: 0,
          overflow: 'hidden',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {right}
      </div>
    </div>
  );
}
