import { useEffect, useState, useRef, useCallback } from 'react';
import { CodeEditor, fileIcon } from './CodeEditor';
import { SearchPanel } from './SearchPanel';
import { GitSourceControl } from './GitSourceControl';
import { SettingsModal } from './SettingsModal';
import { GoLivePanel } from './GoLivePanel';
import { CodeRunner } from './CodeRunner';
import { EmbeddedBrowser } from './EmbeddedBrowser';
import { TerminalAnchor } from './TerminalHost';
import { TerminalManager } from '../terminal/TerminalManager';
import { listFiles, findDjangoRoot } from '../api/client';
import { apiBase } from '../api/base';
import type { FileEntry } from '../api/client';
import type { TerminalEntry } from '../types';
import type { Workspace } from '../workspace';
import { extractDropPaths } from '../terminal/dropPaths';

type SidebarTab = 'explorer' | 'search' | 'git' | 'settings' | 'golive' | 'runner' | 'browser';

interface TreeNode {
  name: string;
  path: string;
  isDir: boolean;
  children?: TreeNode[];
  size?: number | null;
  mtime?: number;
}

// Simple in-memory cache to avoid re-fetching

interface Props {
  openFiles: { path: string; name: string; dirty?: boolean }[];
  activeFile: string | null;
  setActiveFile: (path: string) => void;
  setOpenFiles: React.Dispatch<
    React.SetStateAction<{ path: string; name: string; dirty?: boolean }[]>
  >;
  handleOpenFile: (path: string, name: string, lineNumber?: number) => void;
  onToast: (msg: string, error?: boolean) => void;
  /** Workspace project path — file tree loads from this directory */
  projectPath?: string;
  /** ALL workspaces for the dropdown selector */
  workspaces?: Workspace[];
  /** Currently active workspace ID */
  activeId?: string;
  /** Callback invoked when user clicks "Send" in the send-to-terminal panel */
  onSendToTerminal?: (tty: string, filePath: string) => void | Promise<void>;
  /** Unified terminals keyed by tty (for agent-name lookup in terminal display) */
  terminals?: Record<string, TerminalEntry>;
  /** Switch the active workspace (sidebar + IDE file tree update) */
  onSelectWorkspace?: (id: string) => void;
  /** Send a raw command string to a terminal (Tauri: write to PTY; web: POST to backend) */
  onSendCommand?: (tty: string, command: string) => void | Promise<void>;
  /** Ensure a live terminal exists in the active workspace — auto-opens one if needed. Returns session id. */
  onEnsureTerminal?: () => Promise<string | null>;
  /** Session id of the active workspace's FOCUSED terminal — mounted in the
   *  in-IDE bottom terminal panel so the user can run long-lived commands
   *  (runserver, migrate, shell...) right inside the editor. */
  terminalSessionId?: string;
  /** Close an open file (confirms when dirty, picks the neighbour tab). */
  closeFile: (path: string) => boolean;
  /** Bumped whenever a goto-line jump is requested — forces editor remount. */
  gotoNonce?: number;
}

export function IDEView({
  openFiles,
  activeFile,
  setActiveFile,
  setOpenFiles,
  handleOpenFile,
  onToast,
  projectPath,
  workspaces,
  activeId,
  onSendToTerminal,
  terminals,
  onSelectWorkspace,
  onSendCommand,
  onEnsureTerminal,
  terminalSessionId,
  closeFile,
  gotoNonce = 0,
}: Props) {
  const [sidebarTab, setSidebarTab] = useState<SidebarTab>('explorer');
  const [sidebarHidden, setSidebarHidden] = useState(false);
  const [cursorPos, setCursorPos] = useState<{ line: number; col: number } | null>(null);
  // Browser state
  const [browserUrl, setBrowserUrl] = useState<string>('https://duckduckgo.com');
  const [browserHistory, setBrowserHistory] = useState<string[]>(['https://duckduckgo.com']);
  const [browserHistoryIndex, setBrowserHistoryIndex] = useState<number>(0);
  // Large browser overlay — when true, the EmbeddedBrowser fills the editor
  // center as a big usable view (instead of the tiny 240px sidebar iframe).
  const [browserOpen, setBrowserOpen] = useState(false);
  const [fileTree, setFileTree] = useState<TreeNode[]>([]);
  const [treeLoading, setTreeLoading] = useState(false);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());
  const [loadingDirs, setLoadingDirs] = useState<Set<string>>(new Set());
  const [sidebarWidth, setSidebarWidth] = useState(240);
  const [settingsOpen, setSettingsOpen] = useState(false);
  // True while a drag (file from sidebar/OS) hovers the editor-center area —
  // drives the dashed "Drop to open file" overlay (see .ide-editor-drop).
  const [editorDragOver, setEditorDragOver] = useState(false);

  // In-IDE terminal panel collapse state.
  const [termCollapsed, setTermCollapsed] = useState(false);
  // Terminal panel height state (persisted to localStorage)
  const [termPanelHeight, setTermPanelHeight] = useState(() => {
    try {
      const stored = localStorage.getItem('termPanelHeight');
      if (stored) {
        const h = parseInt(stored, 10);
        if (!isNaN(h) && h >= 80 && h <= window.innerHeight * 0.6) return h;
      }
    } catch {}
    return 180; // default
  });
  // Large Go Live preview (mounted over the editor center) — url + port are
  // handed up from GoLivePanel once the server starts.
  const [livePreview, setLivePreview] = useState(false);
  const [livePreviewUrl, setLivePreviewUrl] = useState('');
  const [livePreviewRefreshKey, setLivePreviewRefreshKey] = useState(0);

  // Send-to-terminal state
  const [selectedTty, setSelectedTty] = useState('');
  const [selectedFilePath, setSelectedFilePath] = useState('');
  const [sending, setSending] = useState(false);

  // Terminal comment/command input state
  const [terminalCommand, setTerminalCommand] = useState('');
  const [commandSending, setCommandSending] = useState(false);
  const commandInputRef = useRef<HTMLInputElement>(null);

  // ── Voice-to-terminal (Web Speech API; works in the Tauri webview too) ──
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const stopListening = useCallback(() => {
    try {
      recognitionRef.current?.stop?.();
    } catch {
      /* noop */
    }
    recognitionRef.current = null;
    setListening(false);
  }, []);

  const toggleVoice = useCallback(() => {
    if (listening) {
      stopListening();
      return;
    }
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      onToast?.('Voice input is not supported in this browser', true);
      return;
    }
    try {
      const rec = new SR();
      rec.lang = 'en-US';
      rec.interimResults = true;
      rec.continuous = true;
      rec.onresult = (e: any) => {
        let text = '';
        for (let i = 0; i < e.results.length; i++) {
          text += e.results[i][0]?.transcript ?? '';
        }
        if (text) setTerminalCommand(text.trim());
      };
      rec.onend = () => setListening(false);
      rec.onerror = () => setListening(false);
      recognitionRef.current = rec;
      rec.start();
      setListening(true);
      onToast?.('Listening… speak your command');
    } catch {
      onToast?.('Could not start voice input', true);
    }
  }, [listening, onToast, stopListening]);

  // Stop listening when the input unmounts.
  useEffect(() => {
    return () => stopListening();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Derive the active workspace
  const activeWs = workspaces?.find((w) => w.id === activeId) || workspaces?.[0];

  // Generation counter: any newer tree request invalidates in-flight ones, so
  // a stale listFiles can never overwrite the tree/expanded state after a
  // workspace switch.
  const treeGenRef = useRef(0);

  // Load root directory based on workspace path; reset expansion on switch so
  // the old workspace's open folders don't leak into the new one.
  useEffect(() => {
    if (!projectPath) return; // backend rejects empty path (400)
    setExpandedDirs(new Set());
    loadFileTree(projectPath);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectPath]);

  // Reset selected tty/file when active workspace changes
  useEffect(() => {
    const ws = workspaces?.find((w) => w.id === activeId);
    if (ws) {
      const tty = ws.panes.find((p) => p.tty)?.tty ?? '';
      setSelectedTty(tty || '');
    }
    setSelectedFilePath('');
  }, [activeId, workspaces]);

  // Reset cursor position when switching active file so a fresh file starts
  // at "Ln 1, Col 1" until the first cursor event arrives from CodeMirror.
  useEffect(() => {
    setCursorPos(null);
  }, [activeFile]);

  const loadFileTree = async (rootPath: string) => {
    const gen = ++treeGenRef.current;
    setTreeLoading(true);
    try {
      const result = await listFiles(rootPath);
      if (gen !== treeGenRef.current) return; // stale — a newer load superseded this
      const nodes: TreeNode[] = (result.files || []).map((e: FileEntry) => ({
        name: e.name,
        path: rootPath ? `${rootPath}/${e.name}` : e.name,
        isDir: e.is_dir,
        size: e.size,
        mtime: e.mtime,
      }));
      setFileTree(nodes.sort((a, b) => a.name.localeCompare(b.name)));
    } catch {
      if (gen === treeGenRef.current) onToast('Failed to load file tree', true);
    } finally {
      if (gen === treeGenRef.current) setTreeLoading(false);
    }
  };

  const findNode = (nodes: TreeNode[], targetPath: string): TreeNode | undefined => {
    for (const n of nodes) {
      if (n.path === targetPath) return n;
      if (n.children) {
        const r = findNode(n.children, targetPath);
        if (r) return r;
      }
    }
    return undefined;
  };

  const handleFileClick = async (node: TreeNode) => {
    if (!node.isDir) {
      handleOpenFile(node.path, node.name);
      return;
    }
    // Directory: toggle expansion. Collapse when already expanded; otherwise
    // load children (if not cached) and expand.
    if (expandedDirs.has(node.path)) {
      setExpandedDirs((prev) => {
        const next = new Set(prev);
        next.delete(node.path);
        return next;
      });
      return;
    }
    if (findNode(fileTree, node.path)?.children) {
      setExpandedDirs((prev) => new Set(prev).add(node.path));
      return;
    }
    const gen = ++treeGenRef.current;
    try {
      setLoadingDirs((prev) => new Set(prev).add(node.path));
      const result = await listFiles(node.path);
      if (gen !== treeGenRef.current) return; // stale — workspace switched mid-fetch
      const children: TreeNode[] = (result.files || []).map((e: FileEntry) => ({
        name: e.name,
        path: `${node.path}/${e.name}`,
        isDir: e.is_dir,
        size: e.size,
        mtime: e.mtime,
      }));
      children.sort((a, b) => a.name.localeCompare(b.name));
      const updatedNode = { ...node, children };
      setFileTree((prev) => updateNode(prev, node.path, updatedNode));
      setExpandedDirs((prev) => new Set(prev).add(node.path));
    } catch {
      if (gen === treeGenRef.current) onToast('Failed to load directory', true);
    } finally {
      setLoadingDirs((prev) => {
        const next = new Set(prev);
        next.delete(node.path);
        return next;
      });
    }
  };

  const updateNode = (nodes: TreeNode[], targetPath: string, updated: TreeNode): TreeNode[] => {
    return nodes.map((n) => {
      if (n.path === targetPath) return updated;
      if (n.children) {
        return { ...n, children: updateNode(n.children, targetPath, updated) };
      }
      return n;
    });
  };

  // Track whether a sidebar-resize drag is in flight so we can tear its
  // listeners down if the component unmounts mid-drag (otherwise the
  // document-level listeners leak and keep calling setState on unmounted).
  const dragCleanupRef = useRef<(() => void) | null>(null);
  useEffect(() => {
    return () => {
      dragCleanupRef.current?.();
      dragCleanupRef.current = null;
    };
  }, []);

  const handleResizeH = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = sidebarWidth;
    let active = true;
    const onMouseMove = (ev: MouseEvent) => {
      if (!active) return;
      const newWidth = Math.max(150, Math.min(500, startWidth + (ev.clientX - startX)));
      setSidebarWidth(newWidth);
    };
    const cleanup = () => {
      if (!active) return;
      active = false;
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', cleanup);
      document.removeEventListener('keydown', onKeyDown);
      dragCleanupRef.current = null;
    };
    const onKeyDown = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') {
        setSidebarWidth(startWidth); // cancel drag, restore original width
        cleanup();
      }
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', cleanup);
    document.addEventListener('keydown', onKeyDown);
    dragCleanupRef.current = cleanup;
  };

  // Vertical resize handler for terminal panel
  const handleResizeV = (e: React.MouseEvent) => {
    e.preventDefault();
    const startY = e.clientY;
    const startHeight = termPanelHeight;
    let active = true;
    const maxHeight = window.innerHeight * 0.6;
    const minHeight = 80;
    const onMouseMove = (ev: MouseEvent) => {
      if (!active) return;
      // Drag up = decrease height (ev.clientY < startY), drag down = increase
      const delta = startY - ev.clientY;
      const newHeight = Math.max(minHeight, Math.min(maxHeight, startHeight + delta));
      setTermPanelHeight(newHeight);
    };
    const cleanup = () => {
      if (!active) return;
      active = false;
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', cleanup);
      document.removeEventListener('keydown', onKeyDown);
    };
    const onKeyDown = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') {
        setTermPanelHeight(startHeight);
        cleanup();
      }
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', cleanup);
    document.addEventListener('keydown', onKeyDown);
  };

  // Persist termPanelHeight to localStorage
  useEffect(() => {
    if (!termCollapsed) {
      try {
        localStorage.setItem('termPanelHeight', String(termPanelHeight));
      } catch {}
    }
  }, [termPanelHeight, termCollapsed]);

  // ── Workspace selector handler ───────────────────────────────────────────
  const handleWorkspaceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const wsId = e.target.value;
    if (!wsId || !workspaces) return;
    // Switch to the selected workspace — updates sidebar highlight,
    // reloads file tree, and refreshes terminal list.
    onSelectWorkspace?.(wsId);
  };

  // ── Send-to-terminal handler ─────────────────────────────────────────────
  const handleSendToTerminal = async () => {
    if (!onSendToTerminal || !selectedTty || !selectedFilePath) return;
    setSending(true);
    try {
      await onSendToTerminal(selectedTty, selectedFilePath);
    } finally {
      setSending(false);
    }
  };

  // ── Terminal command handler ─────────────────────────────────────────────
  const handleSendCommand = async () => {
    if (!terminalCommand.trim()) return;
    setCommandSending(true);
    try {
      let targetTty: string | null = selectedTty || null;
      if (!targetTty && onEnsureTerminal) {
        targetTty = await onEnsureTerminal();
      }
      if (!targetTty) {
        onToast?.('No terminal available', true);
        return;
      }
      if (onSendCommand) {
        // Use the Tauri-aware callback (writes directly to PTY)
        await onSendCommand(targetTty, terminalCommand);
      } else {
        // Fallback: HTTP backend API (web mode: apiBase() is '' → same-origin
        // /api path served through the Vite proxy; Tauri: absolute sidecar URL).
        const baseUrl = apiBase();
        const res = await fetch(`${baseUrl}/api/terminals/${targetTty}/command`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ command: terminalCommand + '\n' }),
        });
        if (!res.ok) throw new Error('Failed to send command');
      }
      setTerminalCommand('');
    } catch (e) {
      console.error('Command send failed:', e);
      onToast?.('Failed to send command', true);
      setTerminalCommand('');
    } finally {
      setCommandSending(false);
    }
  };

  const handleCommandKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendCommand();
    }
  };

  // Available terminals for the active workspace (panes with a tty)
  const availableTerminals = activeWs
    ? activeWs.panes
        .filter((p) => p.tty)
        .map((p) => ({
          tty: p.tty!,
          agent: terminals?.[p.tty!]?.agent ?? '',
        }))
    : [];

  // Files available for sending (open files + top-level file-tree files)
  const availableFiles = (() => {
    const files: { path: string; name: string }[] = [...openFiles];
    // De-duplicate by path
    const seen = new Set(files.map((f) => f.path));
    for (const node of fileTree) {
      if (!node.isDir && !seen.has(node.path)) {
        files.push({ path: node.path, name: node.name });
        seen.add(node.path);
      }
    }
    return files;
  })();

  // Badge: does the active workspace have any live terminal?
  const hasActiveTerminal = activeWs?.panes.some((p) => p.tty) ?? false;

  // ── Django Command Groups (for dropdown) ───────────────────────────────
  const djangoCommandGroups = [
    {
      group: 'Core',
      commands: [
        { label: 'runserver', cmd: 'runserver', desc: 'Start the development server' },
        { label: 'shell', cmd: 'shell', desc: 'Open a Python shell with Django environment' },
        { label: 'check', cmd: 'check', desc: 'Check for common problems in the project' },
        { label: 'test', cmd: 'test', desc: 'Run tests for all installed apps' },
        {
          label: 'diffsettings',
          cmd: 'diffsettings',
          desc: 'Display differences between settings and defaults',
        },
      ],
    },
    {
      group: 'Database / Migrations',
      commands: [
        { label: 'migrate', cmd: 'migrate', desc: 'Apply migrations' },
        { label: 'makemigrations', cmd: 'makemigrations', desc: 'Create new migrations' },
        {
          label: 'showmigrations',
          cmd: 'showmigrations',
          desc: 'Show all migrations and their status',
        },
        { label: 'sqlmigrate', cmd: 'sqlmigrate', desc: 'Print SQL for a migration' },
        { label: 'sqlflush', cmd: 'sqlflush', desc: 'Print SQL to flush the database' },
        {
          label: 'sqlsequencereset',
          cmd: 'sqlsequencereset',
          desc: 'Print SQL to reset sequences',
        },
        {
          label: 'squashmigrations',
          cmd: 'squashmigrations',
          desc: 'Squash multiple migrations into one',
        },
        { label: 'dbshell', cmd: 'dbshell', desc: 'Open database shell' },
        { label: 'inspectdb', cmd: 'inspectdb', desc: 'Introspect database and create models' },
        { label: 'flush', cmd: 'flush', desc: 'Flush the database (delete all data)' },
        { label: 'loaddata', cmd: 'loaddata', desc: 'Load fixture data into the database' },
        { label: 'dumpdata', cmd: 'dumpdata', desc: 'Dump database data to fixtures' },
        { label: 'changepassword', cmd: 'changepassword', desc: 'Change a user password' },
        { label: 'clearsessions', cmd: 'clearsessions', desc: 'Delete expired sessions' },
      ],
    },
    {
      group: 'Static / Files',
      commands: [
        {
          label: 'collectstatic',
          cmd: 'collectstatic',
          desc: 'Collect static files into STATIC_ROOT',
        },
        { label: 'findstatic', cmd: 'findstatic', desc: 'Find static files' },
        { label: 'startapp', cmd: 'startapp', desc: 'Create a new Django app' },
        { label: 'startproject', cmd: 'startproject', desc: 'Create a new Django project' },
      ],
    },
    {
      group: 'I18n',
      commands: [
        {
          label: 'makemessages',
          cmd: 'makemessages',
          desc: 'Create message files for translation',
        },
        {
          label: 'compilemessages',
          cmd: 'compilemessages',
          desc: 'Compile message files to .mo format',
        },
      ],
    },
    {
      group: 'Project / Email',
      commands: [
        { label: 'sendtestemail', cmd: 'sendtestemail', desc: 'Send a test email' },
        { label: 'createsuperuser', cmd: 'createsuperuser', desc: 'Create a superuser' },
      ],
    },
  ];

  // ── Main 4 quick commands (always visible as buttons) ───────────────────
  const mainQuickCommands = [
    { label: '▶ runserver', cmd: 'python3 manage.py runserver' },
    { label: 'migrate', cmd: 'python3 manage.py migrate' },
    { label: 'makemigrations', cmd: 'python3 manage.py makemigrations' },
    { label: 'createsuperuser', cmd: 'python3 manage.py createsuperuser' },
  ];

  // ── Dropdown state ───────────────────────────────────────────────────────
  const [showCommandDropdown, setShowCommandDropdown] = useState(false);
  const dropdownAnchorRef = useRef<HTMLButtonElement>(null);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownAnchorRef.current && !dropdownAnchorRef.current.contains(e.target as Node)) {
        setShowCommandDropdown(false);
      }
    };
    if (showCommandDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showCommandDropdown]);

  // Keyboard navigation for dropdown
  const handleDropdownKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowCommandDropdown(false);
      dropdownAnchorRef.current?.focus();
    }
  };

  // Detected folder containing manage.py (Django root), cached per project
  // path so we only probe once. Commands run from THIS folder, not the raw
  // workspace root — a Django project often lives in a subdirectory.
  const djangoRootRef = useRef<{ key: string; root: string | null }>({
    key: '',
    root: null,
  });

  const detectDjangoRoot = async (): Promise<string | null> => {
    const path = projectPath || '';
    if (djangoRootRef.current.key === path) return djangoRootRef.current.root;
    try {
      const res = await findDjangoRoot(path);
      djangoRootRef.current = { key: path, root: res.found ? res.root : null };
    } catch {
      djangoRootRef.current = { key: path, root: null };
    }
    return djangoRootRef.current.root;
  };

  /** Shared runner for the pill buttons + the More ▾ dropdown.  Auto-opens the
   *  dedicated IDE terminal when none is attached, expands the collapsed bottom
   *  panel so the user SEES the command run, and never fails silently — a click
   *  either lands in the terminal (or an error toast explains why not). */
  const runCommandInTerminal = async (cmd: string) => {
    let targetTty: string | null = terminalSessionId ?? null;
    if (!targetTty && onEnsureTerminal) {
      try {
        targetTty = await onEnsureTerminal();
      } catch {
        targetTty = null;
      }
    }
    if (!targetTty || !onSendCommand) {
      onToast?.('No terminal available — open or start a workspace terminal first', true);
      return;
    }
    setTermCollapsed(false); // reveal the bottom terminal so output is visible
    try {
      // manage.py commands must run from the Django project root. When the
      // terminal is not already there, cd once (the shell keeps its cwd for
      // later commands in the same session).
      if (/manage\.py/.test(cmd)) {
        const djangoRoot = await detectDjangoRoot();
        if (djangoRoot) {
          await onSendCommand(targetTty, `cd ${JSON.stringify(djangoRoot)}`);
        }
      }
      await onSendCommand(targetTty, cmd);
    } catch {
      onToast?.(`Failed to run ${cmd}`, true);
    }
  };

  const runQuickCommand = (cmd: string) => runCommandInTerminal(cmd);

  const runDropdownCommand = (cmd: string) => {
    runCommandInTerminal(`python3 manage.py ${cmd}`);
    setShowCommandDropdown(false);
  };

  // Get main commands as buttons (filter from groups or use mainQuickCommands)
  const quickCommands = mainQuickCommands;

  // ── Large Go Live preview URL (same rel-path logic GoLivePanel uses) ──
  const livePreviewFrameUrl = (() => {
    if (!livePreviewUrl) return '';
    if (activeFile) {
      const name = activeFile.split('/').pop() || '';
      const ext = name.split('.').pop()?.toLowerCase() || '';
      if (ext === 'html' || ext === 'htm' || ext === 'svg') {
        const projectIdx = activeFile.indexOf(projectPath || '');
        const relPath =
          projectIdx >= 0 ? activeFile.slice(projectIdx + (projectPath?.length || 0) + 1) : name;
        return `${livePreviewUrl}/${relPath}`;
      }
    }
    return `${livePreviewUrl}/`;
  })();

  const handlePreviewReady = (info: { url: string; port: number }) => {
    setLivePreviewUrl(info.url);
  };

  // Centralized external navigation handler — routes ALL external links
  // to the embedded browser tab. Exposed on window for any component to use.
  const externalNavigate = (url: string) => {
    onBrowserNavigate(url);
  };

  // Set global handler on mount so any component can call
  // window.__tto_external_navigate(url) to open in embedded browser
  useEffect(() => {
    (window as any).__tto_external_navigate = externalNavigate;
    return () => {
      delete (window as any).__tto_external_navigate;
    };
  }, []);

  const onBrowserNavigate = (url: string) => {
    setBrowserUrl(url);
    setBrowserHistory((prev) => {
      const current = prev[browserHistoryIndex];
      if (url === current) return prev;
      return [...prev.slice(0, browserHistoryIndex + 1), url];
    });
    setBrowserHistoryIndex((prev) => prev + 1);
    setSidebarTab('browser');
    setSidebarHidden(false);
    // Any external navigation should surface the browser LARGE so the user
    // can actually see the site.
    setBrowserOpen(true);
  };

  const closeLivePreview = () => setLivePreview(false);

  const closeBrowser = () => {
    setBrowserOpen(false);
    setSidebarTab('explorer');
  };

  return (
    <div className="ide-container">
      {/* Title Bar — hamburger + logo on the left, brand title centred.
          The redundant yellow/green/red window-control buttons were removed:
          they duplicated the OS window chrome and silently no-op'd without
          window permissions. */}
      <div className="ide-titlebar">
        <div className="ide-titlebar-left">
          <button
            className="ide-menu-btn"
            onClick={() => setSidebarHidden((v) => !v)}
            title={sidebarHidden ? 'Show Sidebar' : 'Hide Sidebar'}
          >
            ☰
          </button>
          <img src="/desktop-icon.png" alt="TTO IDE logo" className="ide-logo" />
        </div>
        <div className="ide-titlebar-center">
          <span className="ide-brand">TTO IDE</span>
          {activeFile && <span className="ide-titlebar-file">{activeFile}</span>}
        </div>
      </div>

      <div className="ide-body">
        {/* Activity Bar */}
        <div className="ide-activity-bar">
          <button
            className={`ide-activity-btn ${sidebarTab === 'explorer' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSidebarTab('explorer');
            }}
            title="Explorer (Cmd+Shift+E)"
          >
            📁
          </button>
          <button
            className={`ide-activity-btn ${sidebarTab === 'search' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSidebarTab('search');
            }}
            title="Search (Cmd+Shift+F)"
          >
            🔍
          </button>
          <button
            className={`ide-activity-btn ${sidebarTab === 'git' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSidebarTab('git');
            }}
            title="Source Control (Cmd+Shift+G)"
          >
            ⎇
          </button>
          <button
            className={`ide-activity-btn ${sidebarTab === 'runner' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSidebarTab('runner');
            }}
            title="Run / Compile (Cmd+Shift+R)"
          >
            ▶
          </button>
          <button
            className={`ide-activity-btn ${sidebarTab === 'golive' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSidebarTab('golive');
            }}
            title="Go Live"
          >
            🌐
          </button>
          <button
            className={`ide-activity-btn ide-activity-google ${sidebarTab === 'browser' ? 'active' : ''}`}
            onClick={() => {
              setSidebarTab('browser');
              setBrowserOpen(true);
            }}
            title="Browser (Ctrl+Shift+B)"
            aria-label="Google browser"
          >
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
          </button>
          <button
            className={`ide-activity-btn ${sidebarTab === 'settings' ? 'active' : ''}`}
            onClick={() => {
              setSidebarHidden(false);
              setSettingsOpen((o) => !o);
            }}
            title="Settings"
          >
            ⚙
          </button>
        </div>

        {/* Sidebar */}
        <div
          className={`ide-sidebar${sidebarHidden ? ' hidden' : ''}`}
          style={{ width: sidebarWidth }}
        >
          <div className="ide-sidebar-header">
            <span className="ide-sidebar-title">
              {sidebarTab === 'explorer' && 'Explorer'}
              {sidebarTab === 'search' && 'Search'}
              {sidebarTab === 'git' && 'Source Control'}
              {sidebarTab === 'runner' && 'Run / Compile'}
              {sidebarTab === 'golive' && 'Go Live'}
              {sidebarTab === 'browser' && 'Browser'}
              {sidebarTab === 'settings' && 'Settings'}
            </span>
            <button className="ide-sidebar-close" onClick={() => setSidebarHidden(true)}>
              ×
            </button>
          </div>

          {/* Workspace selector — shown at top of sidebar when workspaces prop is provided */}
          {workspaces && workspaces.length > 1 && sidebarTab === 'explorer' && (
            <div className="ide-workspace-selector">
              <div
                className="ide-terminal-badge"
                title={hasActiveTerminal ? 'Terminal active in this workspace' : undefined}
              >
                {hasActiveTerminal ? '● Terminal' : '○ No terminal'}
              </div>
              <select
                className="ide-workspace-select"
                value={activeId || ''}
                onChange={handleWorkspaceChange}
              >
                {workspaces.map((ws) => (
                  <option key={ws.id} value={ws.id}>
                    {ws.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="ide-sidebar-content">
            {sidebarTab === 'explorer' && !treeLoading && (
              <FileTree
                nodes={fileTree}
                onFileClick={handleFileClick}
                activeFile={activeFile}
                expandedDirs={expandedDirs}
                loadingDirs={loadingDirs}
              />
            )}
            {sidebarTab === 'explorer' && treeLoading && (
              <div className="ide-loading">Loading files...</div>
            )}
            {sidebarTab === 'search' && (
              <SearchPanel
                searchPath={projectPath}
                onClose={() => setSidebarTab('explorer')}
                onOpenFile={handleOpenFile}
              />
            )}
            {sidebarTab === 'git' && (
              <GitSourceControl
                onToast={onToast}
                onOpenFile={handleOpenFile}
                workspacePath={projectPath}
              />
            )}{' '}
            {sidebarTab === 'settings' && <SettingsContent onToast={onToast} />}
            {sidebarTab === 'golive' && (
              <GoLivePanel
                projectPath={projectPath}
                activeFile={activeFile}
                onOpenPreview={() => setLivePreview(true)}
                onPreviewReady={handlePreviewReady}
                onBrowserNavigate={onBrowserNavigate}
              />
            )}
            {sidebarTab === 'browser' && (
              <EmbeddedBrowser
                url={browserUrl}
                onUrlChange={setBrowserUrl}
                onNavigate={onBrowserNavigate}
                initialHistory={browserHistory}
                initialHistoryIndex={browserHistoryIndex}
              />
            )}
            {sidebarTab === 'runner' && (
              <CodeRunner
                activeFile={activeFile}
                activeFileName={activeFile?.split('/').pop()}
                terminals={terminals}
                onSendCommand={onSendCommand}
                preferredTty={availableTerminals[0]?.tty}
              />
            )}
            {/* Terminal Command Section — shown when terminals are available */}
            {sidebarTab === 'explorer' && availableTerminals.length > 0 && (
              <div className="ide-terminal-section">
                <div className="ide-terminal-section-title">Terminal Command</div>
                <div className="ide-terminal-term-select">
                  <select
                    className="ide-send-select"
                    value={selectedTty}
                    onChange={(e) => setSelectedTty(e.target.value)}
                    title="Select terminal to send command to"
                  >
                    {availableTerminals.length === 0 && <option value="">No terminals</option>}
                    {availableTerminals.map((t) => (
                      <option key={t.tty} value={t.tty}>
                        {t.tty}
                        {t.agent ? ` · ${t.agent}` : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="ide-terminal-command-row">
                  <input
                    ref={commandInputRef}
                    type="text"
                    className="ide-terminal-input"
                    placeholder="Type command and press Enter..."
                    value={terminalCommand}
                    onChange={(e) => setTerminalCommand(e.target.value)}
                    onKeyDown={handleCommandKeyDown}
                    disabled={commandSending}
                  />
                  <button
                    className={`ide-voice-btn${listening ? ' listening' : ''}`}
                    onClick={toggleVoice}
                    title={listening ? 'Stop voice input' : 'Speak a command instead of typing'}
                    aria-label={listening ? 'Stop voice input' : 'Voice command input'}
                  >
                    {listening ? '🔴' : '🎤'}
                  </button>
                  <button
                    className="ide-send-btn ide-terminal-send-btn"
                    disabled={!selectedTty || !terminalCommand.trim() || commandSending}
                    onClick={handleSendCommand}
                    title="Send command to terminal"
                  >
                    {commandSending ? '⏳' : '➤'}
                  </button>
                </div>
                <div className="ide-terminal-hint">Press Enter to send</div>
              </div>
            )}
          </div>

          {/* Send-to-Terminal panel — only when explorer tab, workspaces provided, and active workspace has terminals */}
          {sidebarTab === 'explorer' &&
            !!workspaces &&
            availableTerminals.length > 0 &&
            onSendToTerminal && (
              <div className="ide-send-panel">
                <div className="ide-send-panel-title">Send to Terminal</div>
                <div className="ide-send-row">
                  <select
                    className="ide-send-select"
                    value={selectedTty}
                    onChange={(e) => setSelectedTty(e.target.value)}
                  >
                    {availableTerminals.length === 0 && <option value="">No terminals</option>}
                    {availableTerminals.map((t) => (
                      <option key={t.tty} value={t.tty}>
                        {t.tty}
                        {t.agent ? ` · ${t.agent}` : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="ide-send-row">
                  <select
                    className="ide-send-select"
                    value={selectedFilePath}
                    onChange={(e) => setSelectedFilePath(e.target.value)}
                  >
                    <option value="">Select a file…</option>
                    {availableFiles.map((f) => (
                      <option key={f.path} value={f.path}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="ide-send-row">
                  <button
                    className="ide-send-btn"
                    disabled={!selectedTty || !selectedFilePath || sending}
                    onClick={handleSendToTerminal}
                  >
                    {sending ? 'Sending…' : 'Send'}
                  </button>
                </div>
              </div>
            )}
        </div>

        {/* Resize Handle */}
        <div
          className={`ide-resize-h${sidebarHidden ? ' hidden' : ''}`}
          onMouseDown={handleResizeH}
        />

        {/* Editor Area */}
        <div className="ide-editor-area">
          {/* Tabs */}
          <div className="ide-editor-tabs">
            {openFiles.map((f) => (
              <button
                key={f.path}
                className={`ide-tab ${f.path === activeFile ? 'active' : ''}${f.dirty ? ' dirty' : ''}`}
                onClick={() => setActiveFile(f.path)}
              >
                <span className="ide-tab-icon">{fileIcon(f.name)}</span>
                <span className="ide-tab-name">{f.name}</span>
                {f.dirty && <span className="dirty-dot-mini">●</span>}
                <span
                  className="ide-tab-close"
                  onClick={(e) => {
                    e.stopPropagation();
                    closeFile(f.path);
                  }}
                >
                  ×
                </span>
              </button>
            ))}
          </div>

          {/* Editor center drop zone — wraps empty state, breadcrumbs and
              editor content so a file dropped anywhere in the editor area
              (OS drag, sidebar tree drag, or URI list) opens it. */}
          <div
            className={`ide-editor-center ide-editor-drop${editorDragOver ? ' over' : ''}`}
            onDragOver={(e) => {
              e.preventDefault();
              e.dataTransfer.dropEffect = 'copy';
            }}
            onDragEnter={(e) => {
              e.preventDefault();
              setEditorDragOver(true);
            }}
            onDragLeave={(e) => {
              // Only clear when the pointer actually leaves THIS container —
              // not when it moves onto a child.
              if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
                setEditorDragOver(false);
              }
            }}
            onDrop={(e) => {
              e.preventDefault();
              setEditorDragOver(false);
              const paths = extractDropPaths(e.dataTransfer);
              if (!paths.length) return;
              const p = paths[0];
              handleOpenFile(p, p.split('/').pop() || p);
            }}
          >
            {/* Empty state — shown below the tab strip when no file is open */}
            {!activeFile && (
              <div className="ide-welcome">
                <img src="/desktop-icon.png" alt="tto" className="ide-welcome-logo" />
                <h1>Welcome to tto IDE</h1>
                <p className="ide-welcome-sub">
                  Terminal Task Orchestrator — Code, Command, Conquer
                </p>
                <p>Select a file from Explorer to start editing</p>
                <div className="ide-shortcuts">
                  <span className="ide-shortcut">
                    <kbd>⌘P</kbd> Command Palette
                  </span>
                  <span className="ide-shortcut">
                    <kbd>⌘⇧F</kbd> Search Files
                  </span>
                  <span className="ide-shortcut">
                    <kbd>⌘⇧G</kbd> Source Control
                  </span>
                </div>
              </div>
            )}

            {/* Breadcrumbs */}
            {activeFile && (
              <div className="ide-breadcrumbs">
                {(() => {
                  const segments = activeFile.split('/').filter(Boolean);
                  return segments.map((seg, idx) => {
                    const segPath = segments.slice(0, idx + 1).join('/');
                    return (
                      <span key={segPath} className="ide-breadcrumb">
                        {idx > 0 && <span className="breadcrumb-sep">/</span>}
                        <span className="breadcrumb-part">{seg}</span>
                      </span>
                    );
                  });
                })()}
              </div>
            )}

            {/* Editor */}
            <div className="ide-editor-content">
              {activeFile &&
                (() => {
                  const file = openFiles.find((f) => f.path === activeFile);
                  return file ? (
                    <CodeEditor
                      key={`${activeFile}:${gotoNonce}`}
                      path={activeFile}
                      name={file.name}
                      onClose={() => {
                        if (activeFile) closeFile(activeFile);
                      }}
                      onToast={onToast}
                      gotoLine={(window as any).__tto_pending_goto_line || undefined}
                      onChange={(dirty) => {
                        setOpenFiles((prev) =>
                          prev.map((f) => (f.path === activeFile ? { ...f, dirty } : f)),
                        );
                      }}
                      onCursor={(line, col) => setCursorPos({ line, col })}
                    />
                  ) : null;
                })()}
            </div>
          </div>
          {/* /ide-editor-center drop zone */}

          {/* Large Go Live preview — overlays the editor center so the user
              can SEE the live site big while editing. Closes back to the
              editor code. */}
          {livePreview && livePreviewFrameUrl && (
            <div className="ide-live-preview">
              <div className="ide-live-preview-header">
                <span className="ide-live-preview-title">🌐 Live Preview</span>
                <span
                  className="ide-live-preview-url"
                  title="Open in embedded browser"
                  onClick={() => onBrowserNavigate(livePreviewFrameUrl)}
                >
                  {livePreviewFrameUrl}
                </span>
                <div style={{ flex: 1 }} />
                <button
                  className="ide-live-preview-btn"
                  title="Refresh preview"
                  onClick={() => setLivePreviewRefreshKey((k) => k + 1)}
                >
                  ⟳
                </button>
                <button className="ide-live-close" title="Close preview" onClick={closeLivePreview}>
                  ✕
                </button>
              </div>
              <iframe
                key={livePreviewRefreshKey}
                className="ide-live-preview-frame"
                src={livePreviewFrameUrl}
                title="Go Live Large Preview"
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              />
            </div>
          )}

          {/* Large Browser overlay — fills the editor center so the user can
              actually SEE and USE the web (DuckDuckGo, docs, etc.) instead of
              the 240px sidebar iframe that looked blank. */}
          {browserOpen && (
            <div className="ide-browser-overlay">
              <div className="ide-browser-overlay-header">
                <span className="ide-browser-overlay-title">🌐 Browser</span>
                <div style={{ flex: 1 }} />
                <button
                  className="ide-browser-overlay-btn"
                  title="Open in sidebar (small)"
                  onClick={() => {
                    setBrowserOpen(false);
                    setSidebarTab('browser');
                  }}
                >
                  ⛶
                </button>
                <button
                  className="ide-browser-overlay-close"
                  title="Close browser"
                  onClick={closeBrowser}
                >
                  ✕
                </button>
              </div>
              <div className="ide-browser-overlay-body">
                <EmbeddedBrowser
                  url={browserUrl}
                  onUrlChange={setBrowserUrl}
                  onNavigate={onBrowserNavigate}
                  initialHistory={browserHistory}
                  initialHistoryIndex={browserHistoryIndex}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Vertical Resize Handle for Terminal Panel */}
      {!termCollapsed && <div className="ide-resize-v" onMouseDown={handleResizeV} />}

      {/* In-IDE Terminal Panel */}
      <div
        className={`ide-term-panel${termCollapsed ? ' collapsed' : ''}`}
        style={{ height: termCollapsed ? 28 : termPanelHeight }}
      >
        <div className="ide-term-header">
          <button
            className="ide-term-collapse"
            onClick={() => setTermCollapsed((v) => !v)}
            title={termCollapsed ? 'Expand terminal' : 'Collapse terminal'}
          >
            {termCollapsed ? '▸' : '▾'}
          </button>
          <span className="ide-term-title">Terminal</span>
          <div className="ide-term-quick-btns">
            {quickCommands.map((qc) => (
              <button
                key={qc.label}
                className="ide-term-quick-btn"
                onClick={() => runQuickCommand(qc.cmd)}
                title={`Run ${qc.cmd} in terminal${terminalSessionId ? ` (${terminalSessionId})` : ''}`}
              >
                {qc.label}
              </button>
            ))}
          </div>
          <div style={{ flex: 1 }} />
          {/* More ▾ Dropdown */}
          <div className="ide-term-dropdown" style={{ position: 'relative' }}>
            <button
              ref={dropdownAnchorRef}
              className="ide-term-quick-btn"
              onClick={() => setShowCommandDropdown((v) => !v)}
              title="More Django commands"
              onKeyDown={handleDropdownKeyDown}
            >
              More ▾
            </button>
            {showCommandDropdown && (
              <div className="ide-command-dropdown" onKeyDown={handleDropdownKeyDown} role="menu">
                {djangoCommandGroups.map((group) => (
                  <div key={group.group} className="ide-command-dropdown-group">
                    <div className="ide-command-dropdown-group-label">{group.group}</div>
                    {group.commands.map((cmd) => (
                      <button
                        key={cmd.cmd}
                        className="ide-command-dropdown-item"
                        role="menuitem"
                        onClick={() => runDropdownCommand(cmd.cmd)}
                        title={cmd.desc}
                      >
                        <span className="ide-command-dropdown-cmd">{cmd.label}</span>
                        <span className="ide-command-dropdown-desc">{cmd.desc}</span>
                      </button>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
          {terminalSessionId && (
            <span className="ide-term-tty" title={terminalSessionId}>
              {terminalSessionId}
            </span>
          )}
          <button
            className="ide-term-clear"
            onClick={() => {
              if (terminalSessionId) {
                try {
                  TerminalManager.get(terminalSessionId)?.term?.clear();
                } catch {
                  /* noop */
                }
              }
            }}
            title="Clear terminal output"
          >
            Clear
          </button>
        </div>
        {!termCollapsed && (
          <div className="ide-term-anchor">
            {terminalSessionId ? (
              <TerminalAnchor sessionId={terminalSessionId} />
            ) : (
              <div className="ide-term-empty">
                Click a command above to auto-open a terminal in this workspace
              </div>
            )}
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="ide-statusbar">
        <div className="ide-status-left">
          <span className="ide-status-item">✓ Ready</span>
          {activeFile && (
            <span className="ide-status-item">
              {openFiles.find((f) => f.path === activeFile)?.dirty && (
                <span className="ide-status-dirty-dot">●</span>
              )}
              {activeFile.split('/').pop()}
            </span>
          )}
        </div>
        <div className="ide-status-right">
          <span className="ide-status-item ide-cursor-pos">
            {cursorPos ? `Ln ${cursorPos.line}, Col ${cursorPos.col}` : 'Ln 1, Col 1'}
          </span>
          <span className="ide-status-item">UTF-8</span>
          <span className="ide-status-item">LF</span>
          {openFiles.some((f) => f.dirty) && (
            <span className="ide-status-item ide-dirty">● Dirty</span>
          )}
        </div>
      </div>

      {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

function FileTree({
  nodes,
  onFileClick,
  activeFile,
  expandedDirs,
  loadingDirs,
}: {
  nodes: TreeNode[];
  onFileClick: (node: TreeNode) => void;
  activeFile: string | null;
  expandedDirs: Set<string>;
  loadingDirs: Set<string>;
}) {
  return (
    <div className="ide-file-tree">
      {nodes.map((node) => (
        <TreeNodeItem
          key={node.path}
          node={node}
          onFileClick={onFileClick}
          activeFile={activeFile}
          expandedDirs={expandedDirs}
          loadingDirs={loadingDirs}
        />
      ))}
    </div>
  );
}

function TreeNodeItem({
  node,
  onFileClick,
  activeFile,
  expandedDirs,
  loadingDirs,
}: {
  node: TreeNode;
  onFileClick: (node: TreeNode) => void;
  activeFile: string | null;
  expandedDirs: Set<string>;
  loadingDirs: Set<string>;
}) {
  const isExpanded = expandedDirs.has(node.path);
  const isLoading = loadingDirs.has(node.path);
  const isFile = !node.isDir;

  const handleDragStart = (e: React.DragEvent<HTMLButtonElement>) => {
    // Sidebar drag source: mirror the dropPaths.ts convention (same formats
    // FileBrowser/terminal drops expect). Directories are NOT draggable —
    // only openable files.
    e.stopPropagation(); // don't let the click also fire
    e.dataTransfer.setData('text/plain', node.path);
    e.dataTransfer.setData('application/x-tto-file', node.path);
    e.dataTransfer.effectAllowed = 'copy';
    e.currentTarget.classList.add('dragging');
  };

  const handleDragEnd = (e: React.DragEvent<HTMLButtonElement>) => {
    e.currentTarget.classList.remove('dragging');
  };

  return (
    <div className="ide-tree-item">
      {/* Directories route through onFileClick too — it lazy-loads children then
          expands (and collapses when re-clicked). Files just open. */}
      <button
        className={`ide-tree-row ${node.path === activeFile ? 'active' : ''}`}
        onClick={() => onFileClick(node)}
        draggable={isFile}
        onDragStart={isFile ? handleDragStart : undefined}
        onDragEnd={isFile ? handleDragEnd : undefined}
      >
        {node.isDir ? (
          <>
            <span className="ide-tree-toggle" title={isExpanded ? 'Collapse' : 'Expand'}>
              {isLoading ? '⟳' : isExpanded ? '▾' : '▸'}
            </span>
            <span className="ide-tree-icon">📁</span>
          </>
        ) : (
          <span className="ide-tree-icon" style={{ flex: '0 0 20px' }} />
        )}
        <span className="ide-tree-name">{node.name}</span>
        {isLoading && <span className="ide-tree-loading">⏳</span>}
      </button>
      {node.isDir && isExpanded && node.children && node.children.length > 0 && (
        <div className="ide-tree-children">
          {node.children.map((child) => (
            <TreeNodeItem
              key={child.path}
              node={child}
              onFileClick={onFileClick}
              activeFile={activeFile}
              expandedDirs={expandedDirs}
              loadingDirs={loadingDirs}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SettingsContent({ onToast }: { onToast?: (msg: string, error?: boolean) => void }) {
  const [fontSize, setFontSize] = useState(() => {
    try {
      return parseInt(localStorage.getItem('editorFontSize') || '14');
    } catch {
      return 14;
    }
  });
  const [tabSize, setTabSize] = useState(() => {
    try {
      return parseInt(localStorage.getItem('editorTabSize') || '2');
    } catch {
      return 2;
    }
  });
  const [wordWrap, setWordWrap] = useState(() => {
    try {
      return localStorage.getItem('editorWordWrap') !== 'false';
    } catch {
      return true;
    }
  });
  const [minimapEnabled, setMinimapEnabled] = useState(() => {
    try {
      return localStorage.getItem('minimapEnabled') !== 'false';
    } catch {
      return true;
    }
  });

  const handleSave = () => {
    try {
      localStorage.setItem('editorFontSize', String(fontSize));
      localStorage.setItem('editorTabSize', String(tabSize));
      localStorage.setItem('editorWordWrap', wordWrap ? 'true' : 'false');
      localStorage.setItem('minimapEnabled', minimapEnabled ? 'true' : 'false');
      onToast?.('Settings saved');
    } catch {}
  };

  return (
    <div className="ide-settings">
      <div className="settings-section">
        <h3>Editor</h3>
        <div className="setting-row">
          <label>Font Size</label>
          <input
            type="number"
            min={10}
            max={24}
            value={fontSize}
            onChange={(e) => setFontSize(parseInt(e.target.value) || 14)}
            className="setting-input"
          />
        </div>
        <div className="setting-row">
          <label>Tab Size</label>
          <select
            value={tabSize}
            onChange={(e) => setTabSize(parseInt(e.target.value))}
            className="setting-select"
          >
            <option value={2}>2 spaces</option>
            <option value={4}>4 spaces</option>
            <option value={8}>8 spaces (tabs)</option>
          </select>
        </div>
        <div className="setting-row">
          <label>Word Wrap</label>
          <input
            type="checkbox"
            checked={wordWrap}
            onChange={(e) => setWordWrap(e.target.checked)}
            className="setting-checkbox"
          />
        </div>
        <div className="setting-row">
          <label>Minimap</label>
          <input
            type="checkbox"
            checked={minimapEnabled}
            onChange={(e) => setMinimapEnabled(e.target.checked)}
            className="setting-checkbox"
          />
        </div>
        <button className="btn-primary" onClick={handleSave}>
          Save Settings
        </button>
      </div>
    </div>
  );
}
