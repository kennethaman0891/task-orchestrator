import { useState, useEffect, useCallback, useRef } from 'react';
import type { Workspace } from '../workspace';
import { addTask, sendNotification } from '../api/client';
import { isClosed } from '../lib/format';
import type { UnifiedTerminal } from '../types';

export interface ScheduledTask {
  id: string;
  workspace_id: string;
  day: number; // 1-based day index within the plan
  date: string; // ISO date string (YYYY-MM-DD)
  description: string;
  status: 'pending' | 'dispatched' | 'done' | 'failed';
  dispatched_at?: number;
  created_at: number;
}

export interface TaskPlan {
  id: string;
  workspace_id: string;
  name: string;
  start_date: string; // YYYY-MM-DD
  total_days: number;
  tasks: ScheduledTask[];
  active: boolean;
  created_at: number;
}

interface Props {
  workspaces: Workspace[];
  activeId?: string;
  terminals: Record<string, UnifiedTerminal>;
  onToast: (msg: string, error?: boolean) => void;
}

const STORAGE_KEY = 'tto-ceo-plans';

function loadPlans(): TaskPlan[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}
function savePlans(plans: TaskPlan[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(plans));
}
function genId(): string {
  return `plan-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
function today(): string {
  return new Date().toISOString().slice(0, 10);
}
function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}
function dayOfWeek(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', { weekday: 'short' });
}

export function CEOScheduler({ workspaces, activeId, terminals, onToast }: Props) {
  const ws = workspaces.find((w) => w.id === activeId) || workspaces[0];
  const [plans, setPlans] = useState<TaskPlan[]>(() => loadPlans());
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanDays, setNewPlanDays] = useState(30);
  const [newPlanStart, setNewPlanStart] = useState(today());
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [showNewPlan, setShowNewPlan] = useState(false);
  const editRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    savePlans(plans);
  }, [plans]);

  const wsPlans = plans
    .filter((p) => p.workspace_id === ws?.id)
    .sort((a, b) => b.created_at - a.created_at);

  const activePlan =
    plans.find((p) => p.id === selectedPlan) || wsPlans.find((p) => p.active) || wsPlans[0];

  const todayStr = today();

  const createPlan = useCallback(() => {
    if (!newPlanName.trim() || !ws) return;
    const plan: TaskPlan = {
      id: genId(),
      workspace_id: ws.id,
      name: newPlanName.trim(),
      start_date: newPlanStart,
      total_days: Math.max(1, Math.min(365, newPlanDays)),
      tasks: [],
      active: true,
      created_at: Date.now(),
    };
    // Pre-generate empty task slots
    for (let i = 0; i < plan.total_days; i++) {
      plan.tasks.push({
        id: genId(),
        workspace_id: ws.id,
        day: i + 1,
        date: addDays(newPlanStart, i),
        description: '',
        status: 'pending',
        created_at: Date.now(),
      });
    }
    setPlans((prev) => [...prev, plan]);
    setSelectedPlan(plan.id);
    setNewPlanName('');
    setShowNewPlan(false);
    onToast(`📅 Plan "${plan.name}" created — ${plan.total_days} days`);
  }, [newPlanName, newPlanDays, newPlanStart, ws, onToast]);

  const updateTask = useCallback((taskId: string, description: string) => {
    setPlans((prev) =>
      prev.map((p) => ({
        ...p,
        tasks: p.tasks.map((t) =>
          t.id === taskId ? { ...t, description, updated_at: Date.now() } : t,
        ),
      })),
    );
  }, []);

  const togglePlanActive = useCallback((planId: string) => {
    setPlans((prev) => prev.map((p) => (p.id === planId ? { ...p, active: !p.active } : p)));
  }, []);

  const [dispatching, setDispatching] = useState(false);

  const dispatchToday = useCallback(async () => {
    if (!activePlan) return;
    const todayTasks = activePlan.tasks.filter(
      (t) => t.date === todayStr && t.description.trim() && t.status === 'pending',
    );
    if (todayTasks.length === 0) {
      onToast('No pending tasks for today');
      return;
    }
    setDispatching(true);
    let ok = 0;
    let fail = 0;
    // Resolve the ACTIVE workspace's live terminals to their OS ttys.
    // Previous code scanned ALL terminals globally and its "not closed" filter
    // was a no-op — `t.is_live` is a boolean, so `is_live.toString()` is
    // "true"/"false" and never contains "closed", meaning closed terminals were
    // never excluded. addTask() also needs the OS tty, but a pane's `tty` field
    // holds the Rust session id in Tauri, so we resolve via session_id and use
    // the entry's real `.tty`.
    const wsTerminals = (ws?.panes ?? [])
      .map((p) => {
        const key = p.tty;
        if (!key) return undefined;
        const entry = terminals[key] || Object.values(terminals).find((u) => u.session_id === key);
        return entry;
      })
      .filter((entry): entry is UnifiedTerminal => !!entry && !isClosed(entry) && !!entry.tty)
      .map((entry) => entry.tty);
    for (let i = 0; i < todayTasks.length; i++) {
      const task = todayTasks[i];
      // Round-robin assign to available terminals
      const tty = wsTerminals.length > 0 ? wsTerminals[i % wsTerminals.length] : '';
      if (!tty) {
        fail++;
        continue;
      }
      try {
        await addTask(tty, task.description, '');
        ok++;
      } catch {
        fail++;
      }
    }
    // Mark dispatched in local state
    setPlans((prev) =>
      prev.map((p) =>
        p.id === activePlan.id
          ? {
              ...p,
              tasks: p.tasks.map((t) =>
                t.date === todayStr && t.description.trim() && t.status === 'pending'
                  ? { ...t, status: 'dispatched' as const, dispatched_at: Date.now() }
                  : t,
              ),
            }
          : p,
      ),
    );
    setDispatching(false);
    if (fail === 0) {
      onToast(`🚀 Dispatched ${ok} task(s) to terminals`);
      // Notify Telegram about the dispatched plan
      const taskSummary = todayTasks
        .slice(0, 3)
        .map((t, i) => `${i + 1}. ${t.description.slice(0, 80)}`)
        .join('\n');
      const extra = todayTasks.length > 3 ? `\n…and ${todayTasks.length - 3} more` : '';
      sendNotification(
        'dispatch',
        `📋 CEO PLAN DISPATCHED — ${activePlan.name}\n\n${taskSummary}${extra}\n\n📡 ${ok} task(s) sent to terminals`,
      ).catch(() => {});
    } else {
      onToast(`⚠️ Dispatched ${ok}/${todayTasks.length} — ${fail} failed (no terminals?)`, true);
    }
  }, [activePlan, todayStr, terminals, ws, onToast]);

  const getPlanSummary = useCallback(() => {
    if (!activePlan) return null;
    const done = activePlan.tasks.filter((t) => t.status === 'done').length;
    const dispatched = activePlan.tasks.filter((t) => t.status === 'dispatched').length;
    const filled = activePlan.tasks.filter((t) => t.description.trim()).length;
    return { done, dispatched, filled, total: activePlan.tasks.length };
  }, [activePlan]);

  return (
    <div className="ceo-wrap">
      {/* Header */}
      <div className="ceo-header">
        <div className="ceo-header-left">
          <span className="logo">tto</span>
          <span className="ceo-title">CEO Agent</span>
          {activePlan && <span className="ceo-plan-name">{activePlan.name}</span>}
        </div>
        <div className="ceo-header-actions">
          <button className="ceo-btn" onClick={() => setShowNewPlan(!showNewPlan)}>
            {showNewPlan ? '✕ Cancel' : '+ New Plan'}
          </button>
          {activePlan && (
            <>
              <button
                className={`ceo-btn ${activePlan.active ? 'ceo-btn-active' : ''}`}
                onClick={() => togglePlanActive(activePlan.id)}
              >
                {activePlan.active ? '⏸ Pause' : '▶ Resume'}
              </button>
              <button
                className="ceo-btn ceo-btn-dispatch"
                onClick={dispatchToday}
                disabled={dispatching}
              >
                {dispatching ? '⏳ Dispatching…' : '🚀 Dispatch Today'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* New plan form */}
      {showNewPlan && (
        <div className="ceo-new-plan">
          <input
            className="ceo-input"
            value={newPlanName}
            onChange={(e) => setNewPlanName(e.target.value)}
            placeholder="Plan name (e.g. 'August Sprint')"
            autoFocus
          />
          <div className="ceo-new-plan-row">
            <label>
              Start:
              <input
                type="date"
                className="ceo-date-input"
                value={newPlanStart}
                onChange={(e) => setNewPlanStart(e.target.value)}
              />
            </label>
            <label>
              Days:
              <input
                type="number"
                className="ceo-num-input"
                value={newPlanDays}
                min={1}
                max={365}
                onChange={(e) => setNewPlanDays(parseInt(e.target.value) || 30)}
              />
            </label>
            <button
              className="ceo-btn ceo-btn-create"
              onClick={createPlan}
              disabled={!newPlanName.trim()}
            >
              Create Plan
            </button>
          </div>
        </div>
      )}

      {/* Plan selector */}
      {wsPlans.length > 1 && (
        <div className="ceo-plan-selector">
          {wsPlans.map((p) => (
            <button
              key={p.id}
              className={`ceo-plan-tab ${activePlan?.id === p.id ? 'active' : ''} ${!p.active ? 'paused' : ''}`}
              onClick={() => setSelectedPlan(p.id)}
            >
              {p.name} ({p.total_days}d)
              {!p.active && ' ⏸'}
            </button>
          ))}
        </div>
      )}

      {/* Summary bar */}
      {activePlan &&
        (() => {
          const summary = getPlanSummary();
          if (!summary) return null;
          const pct = summary.total > 0 ? Math.round((summary.done / summary.total) * 100) : 0;
          return (
            <div className="ceo-summary">
              <div className="ceo-summary-bar">
                <div className="ceo-summary-fill" style={{ width: `${pct}%` }} />
              </div>
              <div className="ceo-summary-text">
                <span>
                  📅 {formatDate(activePlan.start_date)} —{' '}
                  {formatDate(addDays(activePlan.start_date, activePlan.total_days - 1))}
                </span>
                <span>
                  {summary.filled}/{summary.total} tasks filled
                </span>
                <span>✅ {summary.done} done</span>
                <span>🚀 {summary.dispatched} dispatched</span>
              </div>
            </div>
          );
        })()}

      {/* Day-by-day calendar */}
      {activePlan && (
        <div className="ceo-calendar">
          {activePlan.tasks
            .slice()
            .sort((a, b) => a.day - b.day)
            .map((task) => {
              const isToday = task.date === todayStr;
              const isPast = task.date < todayStr;
              const statusCls =
                task.status === 'done'
                  ? 'done'
                  : task.status === 'dispatched'
                    ? 'dispatched'
                    : task.status === 'failed'
                      ? 'failed'
                      : task.description.trim()
                        ? 'filled'
                        : 'empty';
              return (
                <div
                  key={task.id}
                  className={`ceo-day ${statusCls} ${isToday ? 'today' : ''} ${isPast ? 'past' : ''}`}
                >
                  <div className="ceo-day-header">
                    <span className="ceo-day-num">Day {task.day}</span>
                    <span className="ceo-day-date">
                      {dayOfWeek(task.date)} {formatDate(task.date)}
                    </span>
                    {isToday && <span className="ceo-day-badge">TODAY</span>}
                    <span className={`ceo-day-status ceo-st-${task.status}`}>
                      {task.status === 'done'
                        ? '✅'
                        : task.status === 'dispatched'
                          ? '🚀'
                          : task.status === 'failed'
                            ? '✗'
                            : task.description.trim()
                              ? '📝'
                              : '○'}
                    </span>
                  </div>
                  {editingTask === task.id ? (
                    <div className="ceo-task-edit">
                      <textarea
                        ref={editRef}
                        className="ceo-task-input"
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                            updateTask(task.id, editText);
                            setEditingTask(null);
                          }
                          if (e.key === 'Escape') setEditingTask(null);
                        }}
                        placeholder="What should be done this day?"
                        rows={2}
                      />
                      <div className="ceo-task-edit-actions">
                        <button
                          className="ceo-btn-sm"
                          onClick={() => {
                            updateTask(task.id, editText);
                            setEditingTask(null);
                          }}
                        >
                          Save
                        </button>
                        <button
                          className="ceo-btn-sm ceo-btn-cancel"
                          onClick={() => setEditingTask(null)}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div
                      className="ceo-task-content"
                      onClick={() => {
                        setEditingTask(task.id);
                        setEditText(task.description);
                      }}
                    >
                      {task.description || (
                        <span className="ceo-task-empty">Click to add task…</span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      )}

      {/* Empty state */}
      {!activePlan && !showNewPlan && (
        <div className="ceo-empty">
          <div className="ceo-empty-icon">👔</div>
          <div className="ceo-empty-title">No plans yet</div>
          <div className="ceo-empty-sub">
            Create a plan to schedule day-by-day tasks.
            <br />
            Tasks auto-dispatch to the orchestrator when you're away.
          </div>
          <button className="ceo-btn ceo-btn-create" onClick={() => setShowNewPlan(true)}>
            + Create First Plan
          </button>
        </div>
      )}
    </div>
  );
}
