import { useState } from 'react';

interface AddTerminalCardProps {
  onToast: (msg: string, isError?: boolean) => void;
  onOpen?: () => void;
}

export function AddTerminalCard({ onToast, onOpen }: AddTerminalCardProps) {
  const [opening, setOpening] = useState(false);

  const open = async () => {
    if (opening || !onOpen) return;
    setOpening(true);
    try {
      onOpen();
    } catch (e) {
      onToast('Failed to open terminal: ' + (e as Error).message, true);
    } finally {
      setOpening(false);
    }
  };

  return (
    <div className="stat add-term">
      <button
        className="add-term-main"
        onClick={open}
        disabled={opening || !onOpen}
        title={
          onOpen
            ? 'Open a new terminal pane in the workspace'
            : 'Terminal open handler not connected'
        }
      >
        <div className="num plus">{opening ? '…' : '＋'}</div>
        <div className="label">{opening ? 'Opening…' : 'New Terminal'}</div>
      </button>
    </div>
  );
}
