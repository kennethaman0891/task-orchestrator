import type { TerminalEntry, UnifiedTerminal } from '../types';
import { formatTokens, isClosed, cleanModel } from '../lib/format';
import { StatusBadge } from './StatusBadge';

/** Deterministic hue for an agent name → each agent gets its own badge color. */
function hueOf(name: string): number {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
  return h;
}

export function TerminalTable({ terminals }: { terminals: Record<string, TerminalEntry> }) {
  // Only live terminals show in the table — closed ones are pruned
  const rows = Object.keys(terminals)
    .filter((tty) => !isClosed(terminals[tty]))
    .map((tty) => {
      const t = terminals[tty];
      const ut = t as UnifiedTerminal;
      const closed = isClosed(t);
      const cur = t.current_task;
      const tokIn = t.tokens?.tokens_input || 0;
      const tokOut = t.tokens?.tokens_output || 0;
      const agent = t.agent || '';
      const hue = agent ? hueOf(agent) : null;
      return (
        <tr key={tty} className={closed ? 'row-closed' : 'row-live'}>
          <td className="tty-cell">
            <span
              className={`status-dot ${closed ? '' : 'live'}`}
              title={closed ? 'CLOSED' : 'LIVE'}
            />
            <span className="tty-name" title={ut.session_id ? `${ut.session_id} · ${tty}` : tty}>
              {ut.session_name || ut.session_id
                ? `${ut.session_name}${ut.session_id ? ` (${ut.session_id})` : ''}`
                : tty}
            </span>
          </td>
          <td>
            {(() => {
              const model = t.model || '';
              return model ? (
                <span className="token-model" style={{ fontSize: '10px' }}>
                  {cleanModel(model)}
                </span>
              ) : (
                <span className="muted">—</span>
              );
            })()}
          </td>
          <td>
            {agent ? (
              <span
                className="agent-badge"
                style={
                  hue !== null
                    ? {
                        background: `hsla(${hue}, 70%, 60%, 0.14)`,
                        color: `hsl(${hue}, 80%, 72%)`,
                        borderColor: `hsla(${hue}, 70%, 60%, 0.35)`,
                      }
                    : undefined
                }
              >
                {agent}
              </span>
            ) : (
              <span className="muted">shell</span>
            )}
          </td>
          <td className="task-cell path-cell" title={t.cwd || ''}>
            <span className="path-icon">📁</span>
            {t.cwd || '-'}
          </td>
          <td className="task-cell" title={cur?.description || ''}>
            {cur ? (
              <span className="task-inline">
                <StatusBadge status={cur.status} />
                <span className="task-desc">{cur.description}</span>
              </span>
            ) : (
              <span className="muted">—</span>
            )}
          </td>
          <td className={`num-cell ${tokIn > 0 ? 'tok-live' : ''}`}>{formatTokens(tokIn)}</td>
          <td className={`num-cell ${tokOut > 0 ? 'tok-live' : ''}`}>{formatTokens(tokOut)}</td>
        </tr>
      );
    });

  const liveCount = rows.length;
  const totalIn = Object.values(terminals).reduce((s, t) => s + (t.tokens?.tokens_input || 0), 0);
  const totalOut = Object.values(terminals).reduce((s, t) => s + (t.tokens?.tokens_output || 0), 0);

  return (
    <div className="table-wrap">
      <div className="table-meta">
        <span className="table-meta-live">
          <span className="status-dot live" /> {liveCount} live terminal{liveCount === 1 ? '' : 's'}
        </span>
        <span className="table-meta-tokens">
          Σ <b>{formatTokens(totalIn)}</b> in · <b>{formatTokens(totalOut)}</b> out
        </span>
      </div>
      <table className="terminal-table">
        <colgroup>
          <col style={{ width: '18%' }} />
          <col style={{ width: '13%' }} />
          <col style={{ width: '10%' }} />
          <col style={{ width: '22%' }} />
          <col style={{ width: '20%' }} />
          <col style={{ width: '9%' }} />
          <col style={{ width: '8%' }} />
        </colgroup>
        <thead>
          <tr>
            <th>Terminal</th>
            <th>Model</th>
            <th>Agent</th>
            <th>Path</th>
            <th>Current Task</th>
            <th className="num-cell">Tokens In</th>
            <th className="num-cell">Tokens Out</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
  );
}
