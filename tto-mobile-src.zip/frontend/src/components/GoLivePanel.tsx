import { useState, useCallback, useRef, useEffect } from 'react';
import { apiBase } from '../api/base';
import { findDjangoRoot } from '../api/client';

interface Props {
  /** The active file's directory (for choosing what to serve) */
  projectPath?: string;
  /** Active file path */
  activeFile?: string | null;
  /** Parent shows a LARGE preview of the live site (in the editor center). */
  onOpenPreview?: () => void;
  /** Parent captures the running server's URL/port to build the large preview. */
  onPreviewReady?: (info: { url: string; port: number }) => void;
  /** Callback to navigate to a URL in the embedded browser tab */
  onBrowserNavigate?: (url: string) => void;
}

/**
 * Go Live panel — starts a lightweight local HTTP server for the project
 * directory and shows the result in an iframe, similar to VS Code's
 * Live Server extension.
 *
 * Uses the backend's /api/serve/start endpoint which spawns
 * `python3 -m http.server` in the project directory.
 */
export function GoLivePanel({
  projectPath,
  activeFile,
  onOpenPreview,
  onPreviewReady,
  onBrowserNavigate,
}: Props) {
  const [running, setRunning] = useState(false);
  const [port, setPort] = useState(18920);
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const [loading, setLoading] = useState(false);
  const [iframeError, setIframeError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const portRef = useRef(0);
  const onPreviewReadyRef = useRef(onPreviewReady);
  onPreviewReadyRef.current = onPreviewReady;

  // Cleanup: stop server when component unmounts
  useEffect(() => {
    return () => {
      if (portRef.current) {
        const base = apiBase();
        if (base) {
          fetch(`${base}/api/serve/stop`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port: portRef.current }),
          }).catch(() => {});
        }
      }
    };
  }, []);

  const startServer = useCallback(async () => {
    if (!projectPath) {
      setError('No project folder selected. Set a project path in the sidebar.');
      return;
    }
    const base = apiBase();
    if (!base) {
      setError('Backend not available. Make sure the backend is running.');
      return;
    }

    setError('');
    setLoading(true);
    try {
      // Serve the real project folder: a Django project often lives in a
      // subdirectory (e.g. dd/ecommerce) — serving the workspace root would
      // show a bare directory listing instead of the app.
      let servePath = projectPath;
      try {
        const dj = await findDjangoRoot(projectPath);
        if (dj.found && dj.root) servePath = dj.root;
      } catch {
        /* keep projectPath */
      }
      const res = await fetch(`${base}/api/serve/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: servePath, port }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.detail || data.message || `HTTP ${res.status}`);
      }
      const data = await res.json();
      if (data.ok && data.url) {
        setUrl(data.url);
        setPort(data.port);
        portRef.current = data.port;
        setRunning(true);
        setError('');
        // Hand the running server URL/port up so the IDE can build a large
        // in-editor preview.
        onPreviewReadyRef.current?.({ url: data.url, port: data.port });
      } else {
        throw new Error(data.detail || 'Failed to start server');
      }
    } catch (e: any) {
      setError(e?.message || 'Failed to start server');
      setRunning(false);
    } finally {
      setLoading(false);
    }
  }, [projectPath, port]);

  const stopServer = useCallback(async () => {
    const base = apiBase();
    if (base && portRef.current) {
      try {
        await fetch(`${base}/api/serve/stop`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ port: portRef.current }),
        });
      } catch {
        /* best effort */
      }
    }
    setRunning(false);
    setUrl('');
    setError('');
    portRef.current = 0;
  }, []);

  // Determine the URL to show in the iframe
  const iframeUrl = (() => {
    if (!running || !url) return '';
    let baseUrl = url;

    // HTTPS upgrade logic: if iframe src is http:// and target is NOT localhost,
    // try upgrading to https:// first (since Tauri app is tauri://localhost - secure context)
    if (baseUrl.startsWith('http://')) {
      try {
        const parsed = new URL(baseUrl);
        const hostname = parsed.hostname;
        const isLocalhost =
          hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
        if (!isLocalhost) {
          // Try HTTPS first for remote sites
          baseUrl = baseUrl.replace('http://', 'https://');
        }
      } catch {
        // Invalid URL, keep original
      }
    }

    if (activeFile) {
      const name = activeFile.split('/').pop() || '';
      const ext = name.split('.').pop()?.toLowerCase() || '';
      if (ext === 'html' || ext === 'htm' || ext === 'svg') {
        const projectIdx = activeFile.indexOf(projectPath || '');
        const relPath =
          projectIdx >= 0 ? activeFile.slice(projectIdx + (projectPath?.length || 0) + 1) : name;
        return `${baseUrl}/${relPath}`;
      }
    }
    return `${baseUrl}/`;
  })();

  return (
    <div className="go-live-panel">
      <div className="go-live-header">
        <span className={`go-live-dot ${running ? 'running' : 'stopped'}`} />
        <span className="go-live-title">
          {loading ? 'Starting...' : running ? 'Go Live' : 'Go Live (Offline)'}
        </span>
        {running && (
          <span
            className="go-live-url"
            onClick={() => onBrowserNavigate?.(url)}
            title="Open in embedded browser"
          >
            {url}
          </span>
        )}
        {running && (
          <button
            className="go-live-btn open-preview"
            onClick={onOpenPreview}
            title="Open a large preview in the editor"
          >
            🌐 Open in Editor
          </button>
        )}
        {running ? (
          <button className="go-live-btn stop" onClick={stopServer}>
            ⏹ Stop
          </button>
        ) : (
          <button
            className="go-live-btn start"
            onClick={startServer}
            disabled={!projectPath || loading}
          >
            {loading ? '⏳' : '▶'} Start
          </button>
        )}
      </div>
      {error && (
        <div className="go-live-iframe-error">
          <div>⚠️ {error}</div>
          <div style={{ fontSize: 11, opacity: 0.6, marginTop: 4 }}>
            {error.includes('not selected')
              ? 'Set a project path in the sidebar first'
              : 'Make sure the backend server is running'}
          </div>
        </div>
      )}
      {running && !error && (
        <div className="go-live-iframe-wrap">
          {iframeError && (
            <div className="go-live-iframe-error">
              <div>⚠️ Failed to load preview</div>
              <div style={{ fontSize: 12, opacity: 0.8, marginTop: 8, lineHeight: 1.4 }}>
                The site may block iframe embedding (X-Frame-Options / CSP headers) or the
                connection was refused.
              </div>
              <div style={{ fontSize: 11, opacity: 0.6, marginTop: 8 }}>
                Try opening in the embedded Browser tab instead.
              </div>
              <button
                className="go-live-btn open-preview"
                onClick={() => onBrowserNavigate?.(iframeUrl)}
                style={{ marginTop: 12 }}
              >
                🌐 Open in Browser Tab
              </button>
              <button
                className="go-live-btn"
                onClick={() => {
                  setIframeError(false);
                  setRefreshKey((k) => k + 1);
                }}
                style={{ marginTop: 8 }}
              >
                ↻ Retry in Iframe
              </button>
            </div>
          )}
          {!iframeError && (
            <iframe
              ref={iframeRef}
              key={refreshKey}
              className="go-live-iframe"
              src={iframeUrl}
              title="Go Live Preview"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-top-navigation-by-user-activation allow-downloads allow-presentation"
              referrerPolicy="origin"
              onLoad={() => setIframeError(false)}
              onError={() => setIframeError(true)}
            />
          )}
        </div>
      )}
      {!running && !error && !loading && (
        <div className="go-live-iframe-error">
          <div style={{ fontSize: 32, opacity: 0.2 }}>🌐</div>
          <div>Click ▶ Start to preview your project</div>
          <div style={{ fontSize: 11, opacity: 0.5, marginTop: 4 }}>
            {projectPath ? `Serves: ${projectPath}` : 'Set a project path in the sidebar first'}
          </div>
        </div>
      )}
      {running && (
        <div className="go-live-controls">
          <input className="go-live-input" value={iframeUrl} readOnly title="Preview URL" />
          <button
            className="go-live-refresh"
            onClick={() => setRefreshKey((k) => k + 1)}
            title="Refresh preview"
          >
            ↻
          </button>
        </div>
      )}
    </div>
  );
}
