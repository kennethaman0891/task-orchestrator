import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { open } from '@tauri-apps/plugin-dialog';

export type CreateItemType = 'file' | 'folder';

interface CreateItemModalProps {
  isOpen: boolean;
  type: CreateItemType;
  currentPath: string;
  onClose: () => void;
  onConfirm: (name: string, targetPath?: string) => void;
}

/**
 * CreateItemModal — a clean, accessible modal for creating new files/folders.
 * Replaces the basic window.prompt() with a proper dialog that matches the app's design.
 */
export function CreateItemModal({
  isOpen,
  type,
  currentPath,
  onClose,
  onConfirm,
}: CreateItemModalProps) {
  const [name, setName] = useState('');
  const [pickedPath, setPickedPath] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);

  const title = type === 'file' ? 'New File' : 'New Folder';
  const placeholder = type === 'file' ? 'e.g., component.tsx' : 'e.g., components';
  const icon = type === 'file' ? '📄' : '📁';

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen) {
      setName('');
      setPickedPath(null); // fresh modal always starts at the default path
      // Defer focus to next tick so ref is attached
      window.setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [isOpen]);

  // Handle Escape to close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.addEventListener('keydown', onKey);
      // Prevent body scroll
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  // Optional "Browse…" — open the native macOS folder picker so the user can
  // choose WHERE the new file/folder is created. Cancelling does nothing and
  // keeps the current path. Only a non-empty string result is accepted.
  const handleBrowse = async () => {
    try {
      const dir = await open({
        directory: true,
        title: 'Choose destination folder',
        defaultPath: currentPath,
      });
      if (dir === null) return; // cancelled — keep default path
      const picked = Array.isArray(dir) ? dir[0] : dir;
      if (picked && picked.trim() !== '') setPickedPath(picked);
    } catch (err) {
      // Dialog unavailable (e.g. running in a plain browser outside Tauri) —
      // fall back to the default path; the existing flow stays intact.
      console.warn('[CreateItemModal] Browse dialog unavailable:', err);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (trimmed) {
      onConfirm(trimmed, pickedPath ?? currentPath);
      onClose();
    }
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  if (!isOpen) return null;

  return createPortal(
    <div
      ref={overlayRef}
      className="cim-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <form className="cim-modal" onSubmit={handleSubmit}>
        {/* Header */}
        <div className="cim-header">
          <span className="cim-icon" aria-hidden="true">
            {icon}
          </span>
          <h2 className="cim-title">{title}</h2>
          <button type="button" className="cim-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        {/* Path context */}
        <div className="cim-path-context" title={(pickedPath ?? currentPath) || 'Workspace root'}>
          <span className="cim-path-label">Create in:</span>
          <span className="cim-path-value">{(pickedPath ?? currentPath) || '/'}</span>
          {pickedPath != null && (
            <button
              type="button"
              className="cim-path-reset"
              onClick={() => setPickedPath(null)}
              title="Use default folder"
              aria-label="Use default folder"
            >
              ✕
            </button>
          )}
          <button
            type="button"
            className={`cim-browse${pickedPath != null ? ' picked' : ''}`}
            onClick={handleBrowse}
          >
            Browse…
          </button>
        </div>

        {/* Input field */}
        <div className="cim-input-wrapper">
          <label htmlFor="cim-name" className="cim-label">
            {type === 'file' ? 'File name' : 'Folder name'}
          </label>
          <input
            ref={inputRef}
            id="cim-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={placeholder}
            className="cim-input"
            autoComplete="off"
            spellCheck={false}
            aria-describedby="cim-hint"
          />
          <span id="cim-hint" className="cim-hint">
            {type === 'file' ? 'Extension determines file type' : 'Will create as directory'}
          </span>
        </div>

        {/* Actions */}
        <div className="cim-actions">
          <button type="button" className="cim-btn cim-btn-cancel" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="cim-btn cim-btn-create" disabled={!name.trim()}>
            Create {type === 'file' ? 'File' : 'Folder'}
          </button>
        </div>
      </form>
    </div>,
    document.body,
  );
}
