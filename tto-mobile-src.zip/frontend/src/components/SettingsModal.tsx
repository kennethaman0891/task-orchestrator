import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { apiBase } from '../api/base';

// ── Types ────────────────────────────────────────────────────────────────────

interface SettingsState {
  editorFontSize: number;
  editorFontFamily: string;
  editorTabSize: number;
  editorWordWrap: boolean;
  minimapEnabled: boolean;
  autoSave: boolean;
  cursorBlink: boolean;
  smoothScrolling: boolean;
  theme: string;
  accentColor: string;
  uiDensity: 'comfortable' | 'compact';
  terminalFontSize: number;
  terminalFontFamily: string;
  terminalCursor: 'block' | 'line' | 'underline';
  terminalScrollback: number;
  terminalBgColor: string;
  terminalOpacity: number;
  language: string;
  githubUsername: string;
  apikey: string;
  displayName: string;
  opencodeUrl: string;
  telemetryEnabled: boolean;
  shortcuts: Record<string, string>;
  buildInfo: string;
}

const DEFAULT_SHORTCUTS: Record<string, string> = {
  'Open Settings': 'Ctrl+,',
  'Command Palette': 'Ctrl+Shift+P',
  'Toggle Terminal': 'Ctrl+`',
  'Split Terminal': 'Ctrl+\\',
  'New Terminal': 'Ctrl+Shift+C',
  'Close Terminal': 'Ctrl+W',
  'Find in Files': 'Ctrl+Shift+F',
  'Go to File': 'Ctrl+P',
  'Save File': 'Ctrl+S',
  'Toggle Word Wrap': 'Alt+Z',
  'Minimap Toggle': 'Ctrl+M',
  'Zoom In / Out': 'Ctrl++ / Ctrl+-',
};

const THEMES = [
  { id: 'void', name: 'Void', desc: 'Pure dark' },
  { id: 'neon', name: 'Neon Tokyo', desc: 'Cyberpunk neon' },
  { id: 'synthwave', name: 'Synthwave', desc: 'Retro purple/pink' },
  { id: 'dracula', name: 'Dracula', desc: 'Classic Dracula' },
  { id: 'carbon', name: 'Carbon', desc: 'IBM Carbon dark' },
  { id: 'obsidian', name: 'Obsidian', desc: 'Deep blue-black' },
  { id: 'paper', name: 'Paper', desc: 'Light theme' },
];

const ACCENTS = [
  { id: '#4f8cff', name: 'Blue' },
  { id: '#f27863', name: 'Coral' },
  { id: '#4ade80', name: 'Green' },
  { id: '#a78bfa', name: 'Violet' },
  { id: '#fbbf24', name: 'Amber' },
  { id: '#22d3ee', name: 'Cyan' },
];

const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिन्दी (Hindi)' },
  { code: 'es', label: 'Español' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'zh', label: '中文（简体）' },
  { code: 'ar', label: 'العربية' },
  { code: 'pt', label: 'Português' },
];

const FONT_FAMILIES = [
  'SF Mono',
  'Menlo',
  'Monaco',
  'Cascadia Mono',
  'Consolas',
  'Liberation Mono',
  'JetBrains Mono',
  'Fira Code',
  'Hack',
  'Source Code Pro',
];

type CategoryId =
  | 'editor'
  | 'terminal'
  | 'appearance'
  | 'language'
  | 'account'
  | 'integrations'
  | 'shortcuts'
  | 'about';

interface Category {
  id: CategoryId;
  label: string;
  icon: string;
  searchTags: string[];
}

const CATEGORIES: Category[] = [
  {
    id: 'editor',
    label: 'Editor',
    icon: '⌨',
    searchTags: ['font', 'size', 'tab', 'wrap', 'minimap', 'indent', 'cursor', 'save'],
  },
  {
    id: 'terminal',
    label: 'Terminal',
    icon: '▸',
    searchTags: ['term', 'tty', 'console', 'shell', 'command', 'font', 'cursor', 'scroll'],
  },
  {
    id: 'appearance',
    label: 'Appearance',
    icon: '◐',
    searchTags: ['theme', 'color', 'accent', 'density', 'dark', 'light', 'ui'],
  },
  {
    id: 'language',
    label: 'Language',
    icon: '🌐',
    searchTags: ['lang', 'locale', 'translation', 'hindi', 'english'],
  },
  {
    id: 'account',
    label: 'Account',
    icon: '👤',
    searchTags: ['user', 'profile', 'github', 'login', 'apikey', 'auth', 'name'],
  },
  {
    id: 'integrations',
    label: 'Integrations',
    icon: '🔌',
    searchTags: ['opencode', 'server', 'agent', 'api', 'connect', 'health'],
  },
  {
    id: 'shortcuts',
    label: 'Keyboard',
    icon: '⏎',
    searchTags: ['shortcut', 'keybind', 'hotkey', 'command', 'key'],
  },
  {
    id: 'about',
    label: 'About',
    icon: 'ℹ',
    searchTags: ['version', 'info', 'build', 'docs', 'help', 'privacy'],
  },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

function loadSetting<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function saveSetting(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

function getBuildInfo(): string {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const meta = import.meta as any;
    const pkgVersion = meta?.env?.VITE_APP_VERSION || '2.3.0';
    return `${pkgVersion}-${meta?.env?.MODE ?? 'dev'}`;
  } catch {
    return '2.3.0-dev';
  }
}

function loadAllSettings(): SettingsState {
  return {
    editorFontSize: loadSetting('editorFontSize', 14),
    editorFontFamily: loadSetting('editorFontFamily', 'SF Mono'),
    editorTabSize: loadSetting('editorTabSize', 2),
    editorWordWrap: loadSetting('editorWordWrap', true) as boolean,
    minimapEnabled: loadSetting('minimapEnabled', true) as boolean,
    autoSave: loadSetting('autoSave', true) as boolean,
    cursorBlink: loadSetting('cursorBlink', true) as boolean,
    smoothScrolling: loadSetting('smoothScrolling', true) as boolean,
    theme: loadSetting('tto-theme', 'void'),
    accentColor: loadSetting('accentColor', '#4f8cff'),
    uiDensity: loadSetting('uiDensity', 'comfortable') as SettingsState['uiDensity'],
    terminalFontSize: loadSetting('terminalFontSize', 11),
    terminalFontFamily: loadSetting('terminalFontFamily', 'SF Mono'),
    terminalCursor: loadSetting('terminalCursor', 'block') as SettingsState['terminalCursor'],
    terminalScrollback: loadSetting('terminalScrollback', 5000),
    terminalBgColor: loadSetting('terminalBgColor', '#000000'),
    terminalOpacity: loadSetting('terminalOpacity', 1),
    language: loadSetting('tto-language', 'en'),
    githubUsername: loadSetting('github-username', ''),
    apikey: loadSetting('api-key', ''),
    displayName: loadSetting('display-name', ''),
    opencodeUrl: loadSetting('opencode-url', 'http://127.0.0.1:4096'),
    telemetryEnabled: loadSetting('telemetry-enabled', false) as boolean,
    shortcuts: loadSetting('keybindings', DEFAULT_SHORTCUTS),
    buildInfo: getBuildInfo(),
  };
}

// ── Component ────────────────────────────────────────────────────────────────

export function SettingsModal({ onClose }: { onClose: () => void }) {
  const [settings, setSettings] = useState<SettingsState>(loadAllSettings);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<CategoryId>('editor');
  const [saveToast, setSaveToast] = useState<{ show: boolean; msg: string }>({
    show: false,
    msg: '',
  });
  const [opencodeStatus, setOpencodeStatus] = useState<'idle' | 'checking' | 'ok' | 'error'>(
    'idle',
  );
  const searchRef = useRef<HTMLInputElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = window.setTimeout(() => searchRef.current?.focus(), 50);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const filteredCategories = useMemo(() => {
    if (!search.trim()) return CATEGORIES.map((c) => c.id);
    const q = search.toLowerCase();
    return CATEGORIES.filter(
      (cat) => cat.searchTags.some((t) => t.includes(q)) || cat.label.toLowerCase().includes(q),
    ).map((c) => c.id);
  }, [search]);

  const handleSave = useCallback(() => {
    try {
      saveSetting('editorFontSize', settings.editorFontSize);
      saveSetting('editorFontFamily', settings.editorFontFamily);
      saveSetting('editorTabSize', settings.editorTabSize);
      saveSetting('editorWordWrap', settings.editorWordWrap);
      saveSetting('minimapEnabled', settings.minimapEnabled);
      saveSetting('autoSave', settings.autoSave);
      saveSetting('cursorBlink', settings.cursorBlink);
      saveSetting('smoothScrolling', settings.smoothScrolling);
      saveSetting('tto-theme', settings.theme);
      saveSetting('accentColor', settings.accentColor);
      saveSetting('uiDensity', settings.uiDensity);
      saveSetting('terminalFontSize', settings.terminalFontSize);
      saveSetting('terminalFontFamily', settings.terminalFontFamily);
      saveSetting('terminalCursor', settings.terminalCursor);
      saveSetting('terminalScrollback', settings.terminalScrollback);
      saveSetting('terminalBgColor', settings.terminalBgColor);
      saveSetting('terminalOpacity', settings.terminalOpacity);
      saveSetting('tto-language', settings.language);
      saveSetting('github-username', settings.githubUsername);
      saveSetting('api-key', settings.apikey);
      saveSetting('display-name', settings.displayName);
      saveSetting('opencode-url', settings.opencodeUrl);
      saveSetting('telemetry-enabled', settings.telemetryEnabled);
      saveSetting('keybindings', settings.shortcuts);
    } catch {}

    setSaveToast({ show: true, msg: 'Settings saved' });
    setTimeout(() => setSaveToast({ show: false, msg: '' }), 2200);
    onClose();
  }, [settings, onClose]);

  const update = <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const themeSwatchStyle = (id: string): React.CSSProperties => {
    const map: Record<string, string> = {
      void: 'linear-gradient(135deg,#090a09 0%,#1a1c1a 100%)',
      neon: 'linear-gradient(135deg,#0d0f1a 0%,#ff2a6d 100%)',
      synthwave: 'linear-gradient(135deg,#260033 0%,#ff71ce 50%,#01cdfe 100%)',
      dracula: 'linear-gradient(135deg,#282a36 0%,#44475a 100%)',
      carbon: 'linear-gradient(135deg,#1b1b1b 0%,#3a3a3a 100%)',
      obsidian: 'linear-gradient(135deg,#0a0e17 0%,#162032 100%)',
      paper: 'linear-gradient(135deg,#fafafa 0%,#e8e8e8 100%)',
    };
    return { background: map[id] ?? map.void };
  };

  /** Test the OpenCode server connection (used by Integrations tab). */
  const testOpencode = useCallback(async () => {
    setOpencodeStatus('checking');
    try {
      const res = await fetch(`${apiBase()}/api/opencode/health`, {
        signal: AbortSignal.timeout(5000),
      });
      const data = await res.json().catch(() => ({}));
      setOpencodeStatus(res.ok && (data?.healthy ?? true) ? 'ok' : 'error');
    } catch {
      setOpencodeStatus('error');
    }
  }, []);

  // ── Section renderers ────────────────────────────────────────────────────

  const renderEditor = () => (
    <>
      <div className="setting-group">
        <div className="setting-group-title">Typography</div>
        <div className="setting-row">
          <label htmlFor="editor-font-size">Font Size</label>
          <input
            id="editor-font-size"
            type="number"
            min={10}
            max={24}
            value={settings.editorFontSize}
            onChange={(e) => update('editorFontSize', parseInt(e.target.value) || 14)}
            className="setting-input"
          />
        </div>
        <div className="setting-row">
          <label htmlFor="editor-font-family">Font Family</label>
          <select
            id="editor-font-family"
            value={settings.editorFontFamily}
            onChange={(e) => update('editorFontFamily', e.target.value)}
            className="setting-select"
            style={{ fontFamily: `${settings.editorFontFamily}, monospace` }}
          >
            {FONT_FAMILIES.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
        <div className="setting-row">
          <label htmlFor="editor-tab-size">Tab Size</label>
          <select
            id="editor-tab-size"
            value={settings.editorTabSize}
            onChange={(e) => update('editorTabSize', parseInt(e.target.value))}
            className="setting-select"
          >
            <option value={2}>2 spaces</option>
            <option value={4}>4 spaces</option>
            <option value={8}>8 spaces (tabs)</option>
          </select>
        </div>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Behavior</div>
        <div className="setting-row">
          <label htmlFor="editor-wordwrap">Word Wrap</label>
          <button
            id="editor-wordwrap"
            role="switch"
            aria-checked={settings.editorWordWrap}
            className={`setting-toggle${settings.editorWordWrap ? ' on' : ''}`}
            onClick={() => update('editorWordWrap', !settings.editorWordWrap)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
        <div className="setting-row">
          <label htmlFor="minimap-toggle">Minimap</label>
          <button
            id="minimap-toggle"
            role="switch"
            aria-checked={settings.minimapEnabled}
            className={`setting-toggle${settings.minimapEnabled ? ' on' : ''}`}
            onClick={() => update('minimapEnabled', !settings.minimapEnabled)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
        <div className="setting-row">
          <label htmlFor="autosave-toggle">Auto Save</label>
          <button
            id="autosave-toggle"
            role="switch"
            aria-checked={settings.autoSave}
            className={`setting-toggle${settings.autoSave ? ' on' : ''}`}
            onClick={() => update('autoSave', !settings.autoSave)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
        <div className="setting-row">
          <label htmlFor="cursor-blink">Cursor Blink</label>
          <button
            id="cursor-blink"
            role="switch"
            aria-checked={settings.cursorBlink}
            className={`setting-toggle${settings.cursorBlink ? ' on' : ''}`}
            onClick={() => update('cursorBlink', !settings.cursorBlink)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
        <div className="setting-row">
          <label htmlFor="smooth-scroll">Smooth Scrolling</label>
          <button
            id="smooth-scroll"
            role="switch"
            aria-checked={settings.smoothScrolling}
            className={`setting-toggle${settings.smoothScrolling ? ' on' : ''}`}
            onClick={() => update('smoothScrolling', !settings.smoothScrolling)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
      </div>
    </>
  );

  const renderTerminal = () => (
    <>
      <div className="setting-group">
        <div className="setting-group-title">Font</div>
        <div className="setting-row">
          <label htmlFor="term-font-size">Font Size</label>
          <input
            id="term-font-size"
            type="number"
            min={8}
            max={20}
            value={settings.terminalFontSize}
            onChange={(e) => update('terminalFontSize', parseInt(e.target.value) || 11)}
            className="setting-input"
          />
          <span className="setting-hint">Refresh terminals to apply</span>
        </div>
        <div className="setting-row">
          <label htmlFor="term-font-family">Font Family</label>
          <select
            id="term-font-family"
            value={settings.terminalFontFamily}
            onChange={(e) => update('terminalFontFamily', e.target.value)}
            className="setting-select"
            style={{ fontFamily: `${settings.terminalFontFamily}, monospace` }}
          >
            {FONT_FAMILIES.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Cursor & History</div>
        <div className="setting-row">
          <label htmlFor="term-cursor">Cursor Style</label>
          <select
            id="term-cursor"
            value={settings.terminalCursor}
            onChange={(e) =>
              update('terminalCursor', e.target.value as SettingsState['terminalCursor'])
            }
            className="setting-select"
          >
            <option value="block">Block</option>
            <option value="line">Line</option>
            <option value="underline">Underline</option>
          </select>
        </div>
        <div className="setting-row">
          <label htmlFor="term-scrollback">Scrollback (lines)</label>
          <select
            id="term-scrollback"
            value={settings.terminalScrollback}
            onChange={(e) => update('terminalScrollback', parseInt(e.target.value))}
            className="setting-select"
          >
            <option value={1000}>1,000</option>
            <option value={5000}>5,000</option>
            <option value={10000}>10,000</option>
            <option value={50000}>50,000</option>
          </select>
        </div>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Appearance</div>
        <div className="setting-row">
          <label htmlFor="term-bg-color">Background Color</label>
          <div className="color-picker-row">
            <input
              id="term-bg-color"
              type="color"
              value={settings.terminalBgColor}
              onChange={(e) => update('terminalBgColor', e.target.value)}
              className="color-input"
            />
            <span className="color-hex">{settings.terminalBgColor}</span>
          </div>
        </div>
        <div className="setting-row setting-row-slider">
          <label htmlFor="term-opacity">Opacity</label>
          <div className="slider-group">
            <input
              id="term-opacity"
              type="range"
              min={0.3}
              max={1}
              step={0.05}
              value={settings.terminalOpacity}
              onChange={(e) => update('terminalOpacity', parseFloat(e.target.value))}
              className="setting-range"
            />
            <span className="slider-value">{Math.round(settings.terminalOpacity * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Live preview */}
      <div
        className="term-preview-card"
        style={{ backgroundColor: settings.terminalBgColor, opacity: settings.terminalOpacity }}
      >
        <div className="term-preview-titlebar">
          <span className="term-preview-dot term-preview-dot--red" aria-hidden="true" />
          <span className="term-preview-dot term-preview-dot--yellow" aria-hidden="true" />
          <span className="term-preview-dot term-preview-dot--green" aria-hidden="true" />
          <span className="term-preview-title">Terminal Preview</span>
        </div>
        <pre
          className="term-preview-content"
          style={{
            fontFamily: settings.terminalFontFamily,
            fontSize: settings.terminalFontSize,
            color: '#4ade80',
          }}
        >
          {`$ echo "hello from tto"\nhello from tto\n\n$ `}
        </pre>
      </div>
    </>
  );

  const renderAppearance = () => (
    <>
      <div className="setting-group">
        <div className="setting-group-title">Theme</div>
        <div className="theme-grid">
          {THEMES.map((t) => (
            <button
              key={t.id}
              className={`theme-btn ${settings.theme === t.id ? 'active' : ''}`}
              onClick={() => update('theme', t.id)}
              aria-pressed={settings.theme === t.id}
            >
              <div className="theme-swatch" style={themeSwatchStyle(t.id)} />
              <div className="theme-info">
                <div className="theme-name">{t.name}</div>
                <div className="theme-desc">{t.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Accent Color</div>
        <div className="accent-row">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              className={`accent-swatch${settings.accentColor === a.id ? ' active' : ''}`}
              style={{ background: a.id }}
              onClick={() => update('accentColor', a.id)}
              title={a.name}
              aria-label={`Accent color: ${a.name}`}
            />
          ))}
        </div>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Layout</div>
        <div className="setting-row">
          <label htmlFor="ui-density">Interface Density</label>
          <select
            id="ui-density"
            value={settings.uiDensity}
            onChange={(e) => update('uiDensity', e.target.value as SettingsState['uiDensity'])}
            className="setting-select"
          >
            <option value="comfortable">Comfortable</option>
            <option value="compact">Compact</option>
          </select>
        </div>
      </div>
    </>
  );

  const renderLanguage = () => (
    <>
      <div className="setting-row">
        <label htmlFor="lang-select">Interface Language</label>
        <select
          id="lang-select"
          value={settings.language}
          onChange={(e) => update('language', e.target.value)}
          className="setting-select"
        >
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>
              {l.label}
            </option>
          ))}
        </select>
      </div>
      <p className="setting-note">
        Localization is applied after restart. English (en) is the default.
      </p>
    </>
  );

  const renderAccount = () => (
    <>
      <div className="account-profile-card">
        <div className="account-avatar">
          {(settings.displayName || settings.githubUsername || '?').charAt(0).toUpperCase()}
        </div>
        <div className="account-profile-info">
          <div className="account-profile-name">
            {settings.displayName || settings.githubUsername || 'Not signed in'}
          </div>
          <div className="account-profile-sub">
            {settings.githubUsername ? `@${settings.githubUsername}` : 'Sign in to sync settings'}
          </div>
        </div>
        <button
          className="btn btn-github"
          onClick={() => {
            const username = prompt('Enter your GitHub username (mock login):');
            if (username !== null) update('githubUsername', username.trim());
          }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
            <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-8.2 0 0 .56-.21 2.2.82.32.11.63.16.94.16z" />
          </svg>
          {settings.githubUsername ? 'Change Account' : 'Sign in with GitHub'}
        </button>
      </div>

      <div className="setting-group">
        <div className="setting-group-title">Profile</div>
        <div className="setting-row">
          <label htmlFor="display-name">Display Name</label>
          <input
            id="display-name"
            type="text"
            placeholder="How you appear in the IDE"
            value={settings.displayName}
            onChange={(e) => update('displayName', e.target.value)}
            className="setting-input"
          />
        </div>
      </div>

      <div className="setting-divider" />

      <div className="setting-row">
        <label htmlFor="api-key">API Key</label>
        <input
          id="api-key"
          type="password"
          placeholder="sk-… (stored locally only)"
          value={settings.apikey}
          onChange={(e) => update('apikey', e.target.value)}
          className="setting-input apikey-input"
        />
      </div>
      <p className="setting-note">
        API keys are stored in localStorage on your device. They are never transmitted to third
        parties.
      </p>
    </>
  );

  const renderIntegrations = () => (
    <>
      <div className="setting-group">
        <div className="setting-group-title">OpenCode Agent Server</div>
        <div className="setting-row">
          <label htmlFor="opencode-url">Server URL</label>
          <input
            id="opencode-url"
            type="text"
            placeholder="http://127.0.0.1:4096"
            value={settings.opencodeUrl}
            onChange={(e) => update('opencodeUrl', e.target.value)}
            className="setting-input"
          />
        </div>
        <div className="setting-row">
          <span className="setting-hint">
            Used by the Agent Workspace. The backend auto-discovers the server password from the
            running process when needed.
          </span>
        </div>
        <div className="setting-row">
          <button
            className="btn secondary"
            onClick={testOpencode}
            disabled={opencodeStatus === 'checking'}
          >
            {opencodeStatus === 'checking' ? 'Checking…' : '🔌 Test Connection'}
          </button>
          {opencodeStatus === 'ok' && <span className="conn-badge ok">● Connected</span>}
          {opencodeStatus === 'error' && <span className="conn-badge err">● Unreachable</span>}
        </div>
      </div>

      <div className="setting-divider" />

      <div className="setting-group">
        <div className="setting-group-title">Privacy</div>
        <div className="setting-row">
          <label htmlFor="telemetry-toggle">Anonymous Telemetry</label>
          <button
            id="telemetry-toggle"
            role="switch"
            aria-checked={settings.telemetryEnabled}
            className={`setting-toggle${settings.telemetryEnabled ? ' on' : ''}`}
            onClick={() => update('telemetryEnabled', !settings.telemetryEnabled)}
          >
            <span className="setting-toggle-knob" />
          </button>
        </div>
        <p className="setting-note">No telemetry is collected today — this is off by default.</p>
      </div>
    </>
  );

  const renderShortcuts = () => {
    const entries = Object.entries(settings.shortcuts);
    return (
      <div className="shortcuts-table">
        {entries.map(([action, key]) => (
          <div key={action} className="shortcut-row">
            <span className="shortcut-action">{action}</span>
            <kbd className="shortcut-key">{key}</kbd>
          </div>
        ))}
      </div>
    );
  };

  const renderAbout = () => (
    <>
      <div className="about-card">
        <div className="about-logo">✦</div>
        <div className="about-title">tto IDE</div>
        <div className="about-tagline">AI-powered terminal orchestration</div>
      </div>
      <div className="about-meta">
        <div className="setting-row">
          <label>Version</label>
          <span className="about-badge">{settings.buildInfo}</span>
        </div>
        <div className="setting-row">
          <label>Build Date</label>
          <span className="about-date">
            {new Date().toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </span>
        </div>
      </div>
      <div className="about-links">
        <a
          href="https://github.com/kennethaman/tto"
          className="about-link"
          onClick={(e) => {
            e.preventDefault();
            (window as any).__tto_external_navigate?.('https://github.com/kennethaman/tto');
          }}
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
            <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-8.2 0 0 .56-.21 2.2.82.32.11.63.16.94.16z" />
          </svg>
          GitHub Repository
        </a>
        <a
          href="#docs"
          className="about-link"
          onClick={(e) => {
            e.preventDefault();
          }}
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
            <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm0 1h12a1 1 0 0 1 1 1v1H1V4a1 1 0 0 1 1-1zM1 13V6h12v7H1z" />
          </svg>
          Documentation
        </a>
      </div>
      <p className="setting-note" style={{ marginTop: 12 }}>
        tto is free and open-source software. Built with ❤️ by Kenneth Aman.
      </p>
    </>
  );

  const renderContent = () => {
    switch (activeCategory) {
      case 'editor':
        return renderEditor();
      case 'terminal':
        return renderTerminal();
      case 'appearance':
        return renderAppearance();
      case 'language':
        return renderLanguage();
      case 'account':
        return renderAccount();
      case 'integrations':
        return renderIntegrations();
      case 'shortcuts':
        return renderShortcuts();
      case 'about':
        return renderAbout();
      default:
        return null;
    }
  };

  const categoryIcon = (id: CategoryId) => CATEGORIES.find((c) => c.id === id)!.icon;

  return (
    <div
      className="settings-overlay"
      ref={overlayRef}
      onClick={(e) => {
        if (e.target === overlayRef.current) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Settings"
    >
      <div className="settings-modal">
        {/* Header */}
        <div className="settings-header">
          <div className="settings-header-title">
            <span className="settings-header-icon" aria-hidden="true">
              ⚙
            </span>
            <h2>Settings</h2>
          </div>
          <button className="settings-close" onClick={onClose} aria-label="Close settings">
            <span aria-hidden="true">×</span>
          </button>
        </div>

        {/* Search bar */}
        <div className="settings-search-bar">
          <span className="settings-search-icon" aria-hidden="true">
            🔍
          </span>
          <input
            ref={searchRef}
            type="text"
            placeholder="Search settings…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="settings-search-input"
            aria-label="Search settings"
          />
          {search && (
            <button
              className="settings-search-clear"
              onClick={() => setSearch('')}
              aria-label="Clear search"
            >
              <span aria-hidden="true">✕</span>
            </button>
          )}
        </div>

        <div className="settings-body">
          {/* Category navigation */}
          <nav className="settings-nav" aria-label="Settings sections">
            {CATEGORIES.filter((cat) => filteredCategories.includes(cat.id)).map((cat) => (
              <button
                key={cat.id}
                className={`settings-nav-item ${activeCategory === cat.id ? 'active' : ''}`}
                onClick={() => {
                  setActiveCategory(cat.id);
                  setSearch('');
                }}
                aria-current={activeCategory === cat.id ? 'page' : undefined}
              >
                <span className="settings-nav-icon" aria-hidden="true">
                  {cat.icon}
                </span>
                <span>{cat.label}</span>
              </button>
            ))}
            {filteredCategories.length === 0 && (
              <p className="settings-no-results">No matching settings found.</p>
            )}
          </nav>

          {/* Content panel */}
          <div className="settings-content-panel">
            <div className="settings-section">
              <h3>
                <span className="settings-section-icon" aria-hidden="true">
                  {categoryIcon(activeCategory)}
                </span>
                {CATEGORIES.find((c) => c.id === activeCategory)?.label}
              </h3>
              {renderContent()}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="settings-footer">
          <button className="btn secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn primary" onClick={handleSave}>
            Save Settings
          </button>
        </div>

        {/* Save confirmation toast */}
        {saveToast.show && (
          <div className="settings-save-toast" role="status" aria-live="polite">
            ✓ {saveToast.msg}
          </div>
        )}
      </div>
    </div>
  );
}
