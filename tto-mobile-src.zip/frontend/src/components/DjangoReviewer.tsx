import { useCallback, useEffect, useRef, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { isTauri } from '../terminal/channels';

// ── Types ──────────────────────────────────────────────────────────────────

interface FileNode {
  name: string;
  path: string;
  is_dir: boolean;
  children: FileNode[];
  status?: 'error' | 'warning' | 'info' | 'ok';
}

interface Issue {
  severity: 'error' | 'warning' | 'info' | 'ok';
  file: string;
  line: number;
  message: string;
  fixable: boolean;
  category: string;
}

interface AnalysisReport {
  project: {
    name: string;
    path: string;
    fileTree: FileNode[];
    hasManagePy: boolean;
    hasSettingsPy: boolean;
    pythonFiles: string[];
    totalFiles: number;
  };
  issues: Issue[];
  urlPatterns: { pattern: string; view: string; name?: string; file: string; line: number }[];
  views: { name: string; kind: string; file: string; line: number }[];
  models: {
    name: string;
    app: string;
    file: string;
    line: number;
    fields: string[];
    hasMigration: boolean;
  }[];
  score: number;
}

interface FixReport {
  fixesApplied: number;
  issuesFixed: string[];
  remainingIssues: Issue[];
  success: boolean;
}

interface CheckResults {
  systemCheck: string;
  migrationCheck: string;
  testResults: string;
  allPassed: boolean;
}

interface ProjectSlot {
  id: string;
  zipPath: string;
  name: string;
  status: 'queued' | 'extracting' | 'analyzing' | 'fixing' | 'done' | 'error';
  report?: AnalysisReport;
  fixReport?: FixReport;
  checkResults?: CheckResults;
  error?: string;
}

// ── Component ──────────────────────────────────────────────────────────────

export function DjangoReviewer() {
  const [projects, setProjects] = useState<ProjectSlot[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());
  const [processing, setProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);

  const selected = projects.find((p) => p.id === selectedId);

  // ── Cleanup old extracted projects on mount/unmount ───────────────────────
  useEffect(() => {
    if (!isTauri()) return;
    // Clean up projects older than 30 minutes when component mounts
    invoke('django_cleanup_old_projects', { maxAgeMinutes: 30 }).catch((e) =>
      console.warn('[DjangoReviewer] cleanup failed:', e),
    );

    // Also clean up on unmount
    return () => {
      invoke('django_cleanup_old_projects', { maxAgeMinutes: 30 }).catch((e) =>
        console.warn('[DjangoReviewer] unmount cleanup failed:', e),
      );
    };
  }, []);

  // ── File handling ──────────────────────────────────────────────────────

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    if (!isTauri()) {
      alert('Django Reviewer requires the desktop app');
      return;
    }
    const zipFiles = Array.from(files).filter((f) => f.name.endsWith('.zip'));
    if (zipFiles.length === 0) {
      alert('Please upload .zip files');
      return;
    }

    // Create slots for each zip
    const newSlots: ProjectSlot[] = zipFiles.map((f) => ({
      id: `proj-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      zipPath: (f as any).path || '',
      name: f.name.replace('.zip', ''),
      status: 'queued' as const,
    }));

    setProjects((prev) => [...prev, ...newSlots]);
    setProcessing(true);

    // Process each project sequentially
    for (const slot of newSlots) {
      try {
        // Step 1: Extract
        updateStatus(slot.id, 'extracting');
        const projectInfo = await invoke<{
          name: string;
          path: string;
          has_manage_py: boolean;
          has_settings_py: boolean;
        }>('django_extract_zip', { zipPath: slot.zipPath });

        // Step 2: Analyze
        updateStatus(slot.id, 'analyzing');
        const report = await invoke<AnalysisReport>('django_analyze', {
          projectPath: projectInfo.path,
        });

        // Step 3: Done
        setProjects((prev) =>
          prev.map((p) => (p.id === slot.id ? { ...p, status: 'done', report } : p)),
        );
      } catch (e: any) {
        setProjects((prev) =>
          prev.map((p) =>
            p.id === slot.id
              ? { ...p, status: 'error', error: e?.toString() || 'Unknown error' }
              : p,
          ),
        );
      }
    }

    setProcessing(false);
  }, []);

  const updateStatus = (id: string, status: ProjectSlot['status']) => {
    setProjects((prev) => prev.map((p) => (p.id === id ? { ...p, status } : p)));
  };

  // ── Fix & Package ──────────────────────────────────────────────────────

  const handleFix = useCallback(async (slot: ProjectSlot) => {
    if (!slot.report) return;
    updateStatus(slot.id, 'fixing');
    try {
      const fixReport = await invoke<FixReport>('django_fix', {
        projectPath: slot.report.project.path,
      });
      setProjects((prev) =>
        prev.map((p) => (p.id === slot.id ? { ...p, fixReport, status: 'done' } : p)),
      );
    } catch (e: any) {
      setProjects((prev) =>
        prev.map((p) => (p.id === slot.id ? { ...p, status: 'error', error: e?.toString() } : p)),
      );
    }
  }, []);

  const handleRunChecks = useCallback(async (slot: ProjectSlot) => {
    if (!slot.report) return;
    try {
      const results = await invoke<CheckResults>('django_run_checks', {
        projectPath: slot.report.project.path,
      });
      setProjects((prev) =>
        prev.map((p) => (p.id === slot.id ? { ...p, checkResults: results } : p)),
      );
    } catch (e: any) {
      alert(`Checks failed: ${e}`);
    }
  }, []);

  const handleDownload = useCallback(async (slot: ProjectSlot) => {
    if (!slot.report) return;
    try {
      const zipPath = await invoke<string>('django_package', {
        projectPath: slot.report.project.path,
      });
      // Open the file in the system file manager
      await invoke('plugin:shell|open', { path: zipPath });
    } catch (e: any) {
      alert(`Package failed: ${e}`);
    }
  }, []);

  const handleDownloadAll = useCallback(async () => {
    const doneProjects = projects.filter((p) => p.status === 'done' && p.report);
    for (const p of doneProjects) {
      await handleDownload(p);
    }
  }, [projects, handleDownload]);

  // ── Drag & Drop ────────────────────────────────────────────────────────

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (dropRef.current) dropRef.current.classList.add('drag-over');
  }, []);

  const handleDragLeave = useCallback(() => {
    if (dropRef.current) dropRef.current.classList.remove('drag-over');
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      if (dropRef.current) dropRef.current.classList.remove('drag-over');
      if (e.dataTransfer.files.length > 0) {
        handleFiles(e.dataTransfer.files);
      }
    },
    [handleFiles],
  );

  // ── File Tree Rendering ────────────────────────────────────────────────

  const toggleDir = (path: string) => {
    setExpandedDirs((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const renderFileNode = (node: FileNode, depth: number = 0) => {
    const isExpanded = expandedDirs.has(node.path);
    const statusIcon =
      node.status === 'ok'
        ? '✅'
        : node.status === 'warning'
          ? '⚠️'
          : node.status === 'error'
            ? '❌'
            : '📄';

    return (
      <div key={node.path}>
        <div
          className={`dr-file${node.is_dir ? ' dir' : ''}`}
          style={{ paddingLeft: `${12 + depth * 16}px` }}
          onClick={() => node.is_dir && toggleDir(node.path)}
        >
          <span className="dr-file-icon">
            {node.is_dir ? (isExpanded ? '📂' : '📁') : statusIcon}
          </span>
          <span className="dr-file-name">{node.name}</span>
        </div>
        {node.is_dir &&
          isExpanded &&
          node.children.map((child) => renderFileNode(child, depth + 1))}
      </div>
    );
  };

  // ── Score badge ────────────────────────────────────────────────────────

  const scoreBadge = (score: number) => {
    const color = score >= 80 ? 'var(--green)' : score >= 50 ? 'var(--yellow)' : 'var(--red)';
    return (
      <span className="dr-score" style={{ borderColor: color, color }}>
        {score}
      </span>
    );
  };

  const statusIcon = (status: ProjectSlot['status']) => {
    switch (status) {
      case 'queued':
        return '⏳';
      case 'extracting':
        return '📦';
      case 'analyzing':
        return '🔍';
      case 'fixing':
        return '🔧';
      case 'done':
        return '✅';
      case 'error':
        return '❌';
    }
  };

  return (
    <div className="django-reviewer">
      {/* ── Upload Zone ─────────────────────────────────────────── */}
      <div
        ref={dropRef}
        className="dr-dropzone"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip"
          multiple
          style={{ display: 'none' }}
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
        <div className="dr-dropzone-icon">📁</div>
        <div className="dr-dropzone-text">
          Drop Django project zips here or <span className="dr-browse">browse</span>
        </div>
        <div className="dr-dropzone-hint">Supports multiple .zip files at once</div>
      </div>

      {/* ── Project Cards ───────────────────────────────────────── */}
      {projects.length > 0 && (
        <div className="dr-projects-bar">
          <div className="dr-projects-list">
            {projects.map((p) => (
              <div
                key={p.id}
                className={`dr-project-card ${selectedId === p.id ? 'selected' : ''} ${p.status}`}
                onClick={() => setSelectedId(p.id)}
              >
                <div className="dr-project-status">{statusIcon(p.status)}</div>
                <div className="dr-project-name">{p.name}</div>
                {p.report && scoreBadge(p.report.score)}
              </div>
            ))}
          </div>
          <div className="dr-projects-actions">
            <button
              className="btn small primary"
              disabled={processing || projects.every((p) => p.status !== 'done')}
              onClick={handleDownloadAll}
            >
              📦 Download All Fixed
            </button>
          </div>
        </div>
      )}

      {/* ── Detail Panel ────────────────────────────────────────── */}
      {selected && selected.report && (
        <div className="dr-detail">
          {/* Left: File Tree */}
          <div className="dr-file-tree">
            <div className="dr-section-header">📁 File Tree</div>
            <div className="dr-file-list">
              {selected.report.project.fileTree.map((node) => renderFileNode(node))}
            </div>
          </div>

          {/* Center: Issues */}
          <div className="dr-issues">
            <div className="dr-section-header">
              🔍 Issues Found ({selected.report.issues.length})
              <div className="dr-issues-actions">
                <button className="btn small primary" onClick={() => handleFix(selected)}>
                  ⚡ Auto-Fix
                </button>
                <button className="btn small" onClick={() => handleRunChecks(selected)}>
                  ▶ Run Checks
                </button>
                <button className="btn small" onClick={() => handleDownload(selected)}>
                  📦 Download
                </button>
              </div>
            </div>

            {/* Score */}
            <div className="dr-score-bar">
              <span className="dr-score-label">Health Score:</span>
              {scoreBadge(selected.report.score)}
              <span className="dr-score-detail">
                {selected.report.views.length} views · {selected.report.models.length} models ·{' '}
                {selected.report.urlPatterns.length} URLs
              </span>
            </div>

            {/* Fix Report */}
            {selected.fixReport && (
              <div className="dr-fix-report">
                <div className="dr-fix-header">
                  🔧 Fixed {selected.fixReport.fixesApplied} issues
                </div>
                {selected.fixReport.issuesFixed.map((fix, i) => (
                  <div key={i} className="dr-fix-item">
                    ✅ {fix}
                  </div>
                ))}
              </div>
            )}

            {/* Check Results */}
            {selected.checkResults && (
              <div className="dr-checks">
                <div className="dr-check-header">
                  {selected.checkResults.allPassed ? '✅' : '⚠️'} Check Results
                </div>
                <pre className="dr-check-output">{selected.checkResults.systemCheck}</pre>
                <pre className="dr-check-output">{selected.checkResults.migrationCheck}</pre>
                <pre className="dr-check-output">{selected.checkResults.testResults}</pre>
              </div>
            )}

            {/* Issue List */}
            <div className="dr-issue-list">
              {selected.report.issues.map((issue, i) => (
                <div key={i} className={`dr-issue ${issue.severity}`}>
                  <span className="dr-issue-sev">
                    {issue.severity === 'error' ? '❌' : issue.severity === 'warning' ? '⚠️' : 'ℹ️'}
                  </span>
                  <span className="dr-issue-file">
                    {issue.file}:{issue.line || '?'}
                  </span>
                  <span className="dr-issue-msg">{issue.message}</span>
                  {issue.fixable && <span className="dr-issue-fixable">🔧 fixable</span>}
                </div>
              ))}
              {selected.report.issues.length === 0 && (
                <div className="dr-no-issues">🎉 No issues found!</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Empty state ─────────────────────────────────────────── */}
      {projects.length === 0 && (
        <div className="dr-empty">
          <div className="dr-empty-icon">✦</div>
          <div className="dr-empty-title">Django Project Reviewer</div>
          <div className="dr-empty-text">
            Upload your Django project zips to get automated code review, connectivity checks,
            auto-fixes, and working downloads.
          </div>
        </div>
      )}
    </div>
  );
}
