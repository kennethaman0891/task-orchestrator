import { useTerminals } from '../hooks/useTerminals';
import { KanbanBoard } from './KanbanBoard';

/**
 * Dedicated view for terminal sessions.
 * This component renders the terminal cards in a responsive layout,
 * ensuring they do not get cut off regardless of screen size or session count.
 */
export default function TerminalView() {
  const { terminals } = useTerminals();

  return (
    <div style={styles.container}>
      {/* The KanbanBoard already contains the necessary responsiveness (auto-fit grid) and dynamic height handling */}
      <KanbanBoard terminals={terminals} onToast={() => {}} />
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    padding: '20px',
    minHeight: '100vh', // Ensure it takes up full viewport height
    backgroundColor: '#1e1e1e', // Example background color
  },
};
