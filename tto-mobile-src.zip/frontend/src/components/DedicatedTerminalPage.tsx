import TerminalView from './TerminalView';

/**
 * Dedicated view for all terminal sessions.
 * This component serves as the entry point for the terminals mode,
 * providing a clean, responsive interface for managing multiple CLI sessions.
 */
export default function DedicatedTerminalPage() {
  return (
    <div style={{ padding: '0 20px', height: '100vh', width: '100%' }}>
      <TerminalView />
    </div>
  );
}
