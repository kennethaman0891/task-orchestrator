import { useState, useEffect, useCallback, useRef } from 'react';
import { createPortal } from 'react-dom';
import { listFiles, type FileEntry, uploadProject } from '../api/client';
import { apiBase } from '../api/base';
import { splitPath } from '../lib/format';
import { usePointerFileDrag, type PointerDragItem } from '../hooks/usePointerFileDrag';
import { CreateItemModal } from './CreateItemModal';

// ── API helpers for file/folder operations ────────────────────────────────
// NOTE: must prefix with apiBase() so requests reach the sidecar in BOTH dev
// (Vite proxy on :1420) and release/Tauri mode (served from tauri://localhost,
// where relative /api URLs would resolve to port 80 and fail silently).
async function createFile(
  targetPath: string,
  name: string,
  onToast: (msg: string, error?: boolean) => void,
) {
  const fullPath = targetPath ? `${targetPath}/${name}` : name;
  try {
    const res = await fetch(apiBase() + '/api/file/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: fullPath, content: '' }),
    });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || j.message || 'Failed');
    onToast(`Created file "${name}"`);
    return true;
  } catch (e: any) {
    onToast(`Failed to create file: ${e.message}`, true);
    return false;
  }
}

async function createDir(
  targetPath: string,
  name: string,
  onToast: (msg: string, error?: boolean) => void,
) {
  const fullPath = targetPath ? `${targetPath}/${name}` : name;
  try {
    const res = await fetch(apiBase() + '/api/dir/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: fullPath }),
    });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || j.message || 'Failed');
    onToast(`Created folder "${name}"`);
    return true;
  } catch (e: any) {
    onToast(`Failed to create folder: ${e.message}`, true);
    return false;
  }
}

async function deleteItem(
  targetPath: string,
  name: string,
  _isDir: boolean,
  onToast: (msg: string, error?: boolean) => void,
) {
  const fullPath = targetPath ? `${targetPath}/${name}` : name;
  try {
    const res = await fetch(apiBase() + `/api/file/delete?path=${encodeURIComponent(fullPath)}`, {
      method: 'DELETE',
    });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || j.message || 'Failed');
    onToast(`Deleted ${_isDir ? 'folder' : 'file'} "${name}"`);
    return true;
  } catch (e: any) {
    onToast(`Failed to delete: ${e.message}`, true);
    return false;
  }
}

async function renameItem(
  targetPath: string,
  oldName: string,
  newName: string,
  _isDir: boolean,
  onToast: (msg: string, error?: boolean) => void,
  refresh: () => void,
): Promise<boolean> {
  const oldFull = targetPath ? `${targetPath}/${oldName}` : oldName;
  const newFull = targetPath ? `${targetPath}/${newName}` : newName;
  try {
    const res = await fetch(apiBase() + '/api/file/rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: oldFull, new_path: newFull }),
    });
    if (!res.ok) {
      // Failed fetch must NOT resolve as a silent success — surface the error
      // and let the caller keep the menu open.
      let msg = `Rename failed (HTTP ${res.status})`;
      try {
        const j = await res.json();
        if (j.detail) msg = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail);
        else if (j.message) msg = j.message;
      } catch {
        /* non-JSON body */
      }
      onToast(msg, true);
      return false;
    }
    onToast(`Renamed to "${newName}"`);
    refresh();
    return true;
  } catch (e: any) {
    onToast(`Rename failed: ${e?.message || 'network error'}`, true);
    return false;
  }
}

interface MenuPos {
  x: number;
  y: number;
}
interface MenuTarget {
  path: string;
  name: string;
  isDir: boolean;
}

interface Props {
  onOpenFile: (path: string, name: string) => void;
  onToast?: (msg: string, error?: boolean) => void;
  /** Initialize the file browser to this path */
  initialPath?: string;
  /** Files dropped onto a terminal (pointer-drag, guaranteed to work in WKWebView) */
  onDropFiles?: (paths: string[], sessionId?: string, kinds?: ('file' | 'folder')[]) => void;
}

export function FileBrowser({ onOpenFile, onToast = () => {}, initialPath, onDropFiles }: Props) {
  // Pointer-drag manager (lives here so it is instantiated ONCE and passed down
  // through every recursively-rendered FileTree level).
  const pd = usePointerFileDrag(onDropFiles ?? (() => {}));
  const [path, setPath] = useState(initialPath || ''); // Initialize from workspace path
  const [menuPos, setMenuPos] = useState<MenuPos | null>(null);
  const [menuTarget, setMenuTarget] = useState<MenuTarget | null>(null);
  // Bumped after any create/delete so the tree re-fetches and shows the new
  // folder/file immediately (toolbar + context menu both trigger this).
  const [reloadNonce, setReloadNonce] = useState(0);
  const bumpReload = useCallback(() => setReloadNonce((n) => n + 1), []);
  // Ref to hold the cleanup function from the root FileTree
  const cleanupExpandedRef = useRef<(fullPath: string) => void>(() => {});
  // Modal state for CreateItemModal (shared across FileBrowser and FileTree)
  const [createModal, setCreateModal] = useState<{
    type: 'file' | 'folder';
    contextPath?: string;
  } | null>(null);
  const openCreateFileModal = useCallback(() => setCreateModal({ type: 'file' }), []);
  const openCreateFolderModal = useCallback(() => setCreateModal({ type: 'folder' }), []);
  const closeCreateModal = useCallback(() => setCreateModal(null), []);

  // Confirmed from the modal — create the file/folder at the exact path the
  // user was browsing (toolbar) or the folder they right-clicked (context menu),
  // then bump reloadNonce so EVERY FileTree level re-fetches and shows it.
  const handleCreateConfirm = useCallback(
    (name: string, targetPath?: string) => {
      // Precedence: explicit browse target (from CreateItemModal) → context path
      // (right-clicked folder) → current browsed path (toolbar). The modal's
      // default "Create in: <path>" flow is preserved when targetPath is absent.
      const usePath = targetPath ?? createModal?.contextPath ?? path;
      if (createModal?.type === 'file') {
        createFile(usePath, name, onToast).then((ok) => {
          if (ok) bumpReload();
        });
      } else {
        createDir(usePath, name, onToast).then((ok) => {
          if (ok) bumpReload();
        });
      }
      closeCreateModal();
    },
    [createModal, path, onToast, bumpReload, closeCreateModal],
  );
  // Reset path when workspace changes
  useEffect(() => {
    setPath(initialPath || '');
  }, [initialPath]);

  // Close context menu on outside click
  useEffect(() => {
    if (!menuPos) return;
    const handler = () => setMenuPos(null);
    // Delay so the originating click fires first
    const t = window.setTimeout(() => window.addEventListener('click', handler), 0);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener('click', handler);
    };
  }, [menuPos]);

  // No path configured → show placeholder instead of listing home directory
  // Check `path` state (synced via useEffect) rather than `initialPath` prop,
  // so the placeholder only appears when there's genuinely no path to work with.
  // NOTE: all hooks are declared ABOVE this early return — returning here must
  // never change the hook count between renders (React Rules of Hooks).
  if (!path || !path.trim()) {
    return (
      <div className="fb-no-path">
        <p>No project folder set</p>
        <span className="fb-no-path-hint">
          Click the 📁 path below the workspace name in the sidebar to set your project folder
        </span>
      </div>
    );
  }

  return (
    <>
      <FileTree
        path={path}
        setPath={setPath}
        onOpenFile={onOpenFile}
        depth={0}
        onToast={onToast}
        onDropFiles={onDropFiles}
        pd={pd}
        menuPos={menuPos}
        menuTarget={menuTarget}
        setMenuPos={setMenuPos}
        setMenuTarget={setMenuTarget}
        reloadNonce={reloadNonce}
        openCreateFileModal={openCreateFileModal}
        openCreateFolderModal={openCreateFolderModal}
        setCreateModal={setCreateModal}
      />
      {menuPos &&
        menuTarget &&
        createPortal(
          <ContextMenu
            key={`${menuPos.x}-${menuPos.y}`}
            target={menuTarget}
            pos={menuPos}
            onToast={onToast}
            onOpenFile={onOpenFile}
            onOpenDir={(dirPath) => setPath(dirPath)}
            onDismiss={() => setMenuPos(null)}
            cleanupExpanded={cleanupExpandedRef.current}
            setCreateModal={setCreateModal}
            onRefresh={bumpReload}
          />,
          document.body,
        )}
      {createModal && (
        <CreateItemModal
          isOpen={true}
          type={createModal.type}
          currentPath={createModal.contextPath ?? path}
          onClose={closeCreateModal}
          onConfirm={handleCreateConfirm}
        />
      )}
    </>
  );
}

function ContextMenu({
  target,
  pos,
  onToast,
  onOpenFile,
  onOpenDir,
  onDismiss,
  cleanupExpanded,
  setCreateModal,
  onRefresh,
}: {
  target: MenuTarget;
  pos: MenuPos;
  onToast: (msg: string, error?: boolean) => void;
  onOpenFile: (path: string, name: string) => void;
  onOpenDir: (path: string) => void;
  onDismiss: () => void;
  cleanupExpanded: (fullPath: string) => void;
  setCreateModal: (v: { type: 'file' | 'folder'; contextPath?: string } | null) => void;
  onRefresh: () => void;
}) {
  const snapX = Math.min(pos.x, window.innerWidth - 170);
  const snapY = Math.min(pos.y, window.innerHeight - 240);

  return (
    <div
      className="fb-context-menu"
      style={{ left: snapX, top: snapY }}
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className="fb-menu-item"
        onClick={() => {
          const full = target.path ? `${target.path}/${target.name}` : target.name;
          // "Open" on a folder navigates INTO it (uses the directory).
          if (target.isDir) {
            onOpenDir(full);
          } else {
            onOpenFile(full, target.name);
          }
          onDismiss();
        }}
      >
        Open
      </button>
      <div className="fb-menu-sep" />
      <button
        className="fb-menu-item"
        onClick={() => {
          onDismiss();
          setCreateModal({ type: 'file', contextPath: target.path });
        }}
      >
        New File…
      </button>
      <button
        className="fb-menu-item"
        onClick={() => {
          onDismiss();
          setCreateModal({ type: 'folder', contextPath: target.path });
        }}
      >
        New Folder…
      </button>
      <div className="fb-menu-sep" />
      <button
        className="fb-menu-item"
        onClick={() => {
          const n = prompt('Rename to:', target.name);
          if (n && n !== target.name) {
            // Keep the menu open on failure (renameItem returns false + toasts);
            // dismiss + refresh the tree only on real success.
            renameItem(target.path, target.name, n, target.isDir, onToast, onRefresh).then((ok) => {
              if (ok) onDismiss();
            });
          }
        }}
      >
        Rename…
      </button>
      <button
        className={`fb-menu-item${target.isDir ? '' : ' danger'}`}
        onClick={() => {
          const full = target.path ? `${target.path}/${target.name}` : target.name;
          if (target.isDir) {
            deleteItem(target.path, target.name, true, onToast).then((ok) => {
              if (ok) {
                cleanupExpanded(full);
                onDismiss();
                onRefresh();
              }
            });
          } else {
            if (confirm(`Delete "${target.name}"?`)) {
              deleteItem(target.path, target.name, false, onToast).then((ok) => {
                if (ok) {
                  onDismiss();
                  onRefresh();
                }
              });
            }
          }
        }}
      >
        Delete
      </button>
    </div>
  );
}

function FileTree({
  path,
  setPath,
  onOpenFile,
  depth,
  onToast,
  menuPos,
  menuTarget,
  setMenuPos,
  setMenuTarget,
  reloadNonce,
  onDropFiles,
  pd,
  setCreateModal,
  openCreateFileModal,
  openCreateFolderModal,
}: {
  path: string;
  setPath: (p: string) => void;
  onOpenFile: (path: string, name: string) => void;
  depth: number;
  onToast: (msg: string, error?: boolean) => void;
  menuPos: MenuPos | null;
  menuTarget: MenuTarget | null;
  setMenuPos: (p: MenuPos | null) => void;
  setMenuTarget: (t: MenuTarget | null) => void;
  reloadNonce: number;
  onDropFiles?: (paths: string[], sessionId?: string, kinds?: ('file' | 'folder')[]) => void;
  pd: ReturnType<typeof usePointerFileDrag>;
  setCreateModal: (v: { type: 'file' | 'folder'; contextPath?: string } | null) => void;
  openCreateFileModal: () => void;
  openCreateFolderModal: () => void;
}) {
  const [files, setFiles] = useState<FileEntry[] | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [dragOver, setDragOver] = useState(false);
  // Track whether a double-click is imminent so onClick doesn't open the file
  // while the user is trying to rename it.
  const pendingDblClickRef = useRef(false);
  const refresh = useCallback(() => {
    if (!path || !path.trim()) return; // backend rejects empty path (400)
    setLoading(true);
    setError(null);
    listFiles(path)
      .then((d) => setFiles(d.files))
      .catch((e: any) => {
        const msg = e?.message || 'Failed to load files';
        setError(msg);
        setFiles([]);
      })
      .finally(() => setLoading(false));
  }, [path]);

  useEffect(() => {
    refresh();
  }, [refresh, reloadNonce]);

  const handleContextMenu = useCallback(
    (e: React.MouseEvent, entry: FileEntry) => {
      e.preventDefault();
      e.stopPropagation();
      setMenuPos({ x: e.clientX, y: e.clientY });
      setMenuTarget({ path, name: entry.name, isDir: entry.is_dir });
    },
    [path, setMenuPos, setMenuTarget],
  );

  const handleDoubleClick = useCallback(
    (entry: FileEntry) => {
      if (entry.is_dir) return;
      pendingDblClickRef.current = true;
      setRenaming(path ? `${path}/${entry.name}` : entry.name);
      setRenameValue(entry.name);
    },
    [path],
  );

  // Reset the dbl-click guard after each click cycle so single clicks work normally.
  useEffect(() => {
    const t = window.setTimeout(() => {
      pendingDblClickRef.current = false;
    }, 50);
    return () => window.clearTimeout(t);
  }, [renaming]);

  const commitRename = useCallback(
    (_: string, oldName: string, isDir: boolean) => {
      const newName = renameValue.trim();
      if (!newName || newName === oldName) {
        setRenaming(null);
        return;
      }
      renameItem(path, oldName, newName, isDir, onToast, refresh);
      setRenaming(null);
    },
    [path, renameValue, onToast, refresh],
  );

  // ── Drag & Drop ──────────────────────────────────────────────────────────
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  }, []);

  // Debounced drag leave timer ref — tracks the pending timeout so only the
  // latest drag-leave call's timer is active (old timeouts are cleared).
  const dragLeaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Debounced drag leave: only clear the global drag-into-terminal-input flag
  // after the cursor has been outside for a short delay. This prevents the flag
  // from being cleared mid-drag when the mouse briefly moves outside (e.g. over
  // sidebar edges), which would cause files to route to the terminal PTY instead
  // of the command line for user review.
  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Clear any pending timer from a previous drag-leave
    if (dragLeaveTimer.current) {
      clearTimeout(dragLeaveTimer.current);
      dragLeaveTimer.current = null;
    }
    // Set a new debounced timeout to clear the global flag
    dragLeaveTimer.current = setTimeout(() => setDragOver(false), 150);
  }, []);

  // Clean up the debounced timer on component unmount
  useEffect(() => {
    return () => {
      if (dragLeaveTimer.current) {
        clearTimeout(dragLeaveTimer.current);
        dragLeaveTimer.current = null;
      }
    };
  }, []);

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragOver(false);
      const filesList = Array.from(e.dataTransfer.files);
      if (!filesList.length) return;
      for (const file of filesList) {
        try {
          const result = await uploadProject(file);
          if (result.ok) {
            onToast(`Uploaded "${file.name}" → ${result.path}`);
            refresh();
          } else {
            onToast(`Failed to upload "${file.name}"`, true);
          }
        } catch (err: any) {
          onToast(`Upload failed: ${err.message}`, true);
        }
      }
    },
    [onToast, refresh],
  );

  if (files === null) return <div className="sidebar-placeholder">Loading...</div>;

  // Show error state when the API call failed
  if (error) {
    return (
      <div className="fb-error">
        <span className="fb-error-icon">⚠</span>
        <span className="fb-error-msg">{error}</span>
        <button className="fb-retry-btn" onClick={refresh}>
          Retry
        </button>
      </div>
    );
  }

  const dirs = files.filter((f) => f.is_dir);
  const fileItems = files.filter((f) => !f.is_dir);

  return (
    <>
      <div
        className={`fb-tree${dragOver ? ' drag-over' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {dragOver && (
          <div className="fb-drop-overlay">
            <span>📂 Drop files here to upload</span>
          </div>
        )}
        {depth === 0 && (
          <div className="fb-toolbar">
            <span className="fb-tb-path" title={path}>
              {path}
            </span>
            <span className="fb-tb-actions">
              <button className="fb-tb-btn" title="New file" onClick={openCreateFileModal}>
                📄
              </button>
              <button className="fb-tb-btn" title="New folder" onClick={openCreateFolderModal}>
                📁
              </button>
              <button className="fb-tb-btn" title="Refresh" onClick={refresh}>
                ↺
              </button>
            </span>
          </div>
        )}
        {depth > 0 && (
          <div
            className="fb-back"
            onClick={() => {
              // Go up one level, preserving the path's absolute style:
              //  - POSIX (/Users/…)   → root is the leading '/' (splitPath's
              //    filter(Boolean) drops it, so re-add on join)
              //  - Windows (C:\…)     → root is the drive letter itself; the
              //    joined parts already yield the absolute path, so NO extra
              //    separator prefix (that would produce \C:\…).
              const isPosixAbs = path.startsWith('/');
              const isWinAbs = /^[a-zA-Z]:[\\/]/.test(path);
              const sep = path.includes('\\') ? '\\' : '/';
              const parts = splitPath(path);
              parts.pop();
              if (parts.length === 0) {
                // At the filesystem root — resolve to the root, not ''.
                setPath(isPosixAbs ? '/' : isWinAbs ? path.slice(0, path.indexOf(':') + 2) : '');
                return;
              }
              const joined = isPosixAbs ? '/' + parts.join('/') : parts.join(sep);
              // A bare drive label (C:) is the drive ROOT — restore the
              // trailing separator so the listing resolves to C:\.
              setPath(isWinAbs && /^[a-zA-Z]:$/.test(joined) ? joined + sep : joined);
            }}
          >
            ← back
          </div>
        )}
        {loading && <div className="sidebar-placeholder">Loading...</div>}
        {dirs.map((d) => {
          const full = path ? `${path}/${d.name}` : d.name;
          const isOpen = !!expanded[full];
          return (
            <div
              key={full}
              className="fb-item fb-dir"
              onClick={(e) => {
                // Clicking ANYWHERE on the folder row expands/collapses it —
                // not just the tiny ▸ toggle or the name text. (Left button only;
                // right-click opens the context menu and must not toggle.)
                // e.detail === 1 skips the SECOND click of a double-click — that
                // one belongs to the navigate-on-double-click handler below.
                if (pd.consumeDrag()) return; // the interaction was a drag-drop, not a click
                if (e.button === 0 && e.detail === 1)
                  setExpanded((ex) => ({ ...ex, [full]: !ex[full] }));
              }}
              onMouseDown={(e) => {
                if (renaming === full) return;
                pd.begin(e, {
                  label: d.name,
                  path: full,
                  kind: 'folder',
                  icon: '📁',
                } satisfies PointerDragItem);
              }}
              onContextMenu={(e) => handleContextMenu(e, d)}
            >
              <span className="fb-toggle">{isOpen ? '▾' : '▸'}</span>
              {renaming === full ? (
                <input
                  className="fb-rename-input"
                  value={renameValue}
                  autoFocus
                  onChange={(e) => setRenameValue(e.target.value)}
                  onBlur={() => commitRename(full, d.name, true)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitRename(full, d.name, true);
                    if (e.key === 'Escape') setRenaming(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <span
                  className="fb-name"
                  onDoubleClick={() => {
                    setPath(full);
                    setExpanded((e) => ({ ...e, [full]: true }));
                  }}
                  title={`${full} — double-click to open folder`}
                >
                  📁 {d.name}
                </span>
              )}
            </div>
          );
        })}
        {dirs.map((d) => {
          const full = path ? `${path}/${d.name}` : d.name;
          if (!expanded[full]) return null;
          return (
            <div key={`sub-${full}`} style={{ paddingLeft: 12 }}>
              <FileTree
                path={full}
                setPath={setPath}
                onOpenFile={onOpenFile}
                depth={depth + 1}
                onToast={onToast}
                onDropFiles={onDropFiles}
                pd={pd}
                menuPos={menuPos}
                menuTarget={menuTarget}
                setMenuPos={setMenuPos}
                setMenuTarget={setMenuTarget}
                reloadNonce={reloadNonce}
                setCreateModal={setCreateModal}
                openCreateFileModal={openCreateFileModal}
                openCreateFolderModal={openCreateFolderModal}
              />
            </div>
          );
        })}
        {fileItems.map((f) => {
          const full = path ? `${path}/${f.name}` : f.name;
          return (
            <div
              key={full}
              className="fb-item fb-file"
              onClick={() => {
                // Preventing single-click from opening the file when the user is
                // in the middle of a drag-drop or a double-click rename sequence.
                if (pd.consumeDrag()) return;
                if (pendingDblClickRef.current) return;
                onOpenFile(full, f.name);
              }}
              onMouseDown={(e) => {
                if (renaming === full) return;
                pd.begin(e, {
                  label: f.name,
                  path: full,
                  kind: 'file',
                  icon: '📄',
                } satisfies PointerDragItem);
              }}
              onContextMenu={(e) => handleContextMenu(e, f)}
              onDoubleClick={() => handleDoubleClick(f)}
            >
              {renaming === full ? (
                <input
                  className="fb-rename-input"
                  value={renameValue}
                  autoFocus
                  onChange={(e) => setRenameValue(e.target.value)}
                  onBlur={() => commitRename(full, f.name, false)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitRename(full, f.name, false);
                    if (e.key === 'Escape') setRenaming(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <span className="fb-name" title={full}>
                  {f.name}
                </span>
              )}
              {f.size != null && (
                <span className="fb-size">
                  {f.size >= 1048576
                    ? (f.size / 1048576).toFixed(1) + 'M'
                    : f.size >= 1024
                      ? (f.size / 1024).toFixed(0) + 'K'
                      : String(f.size)}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}
