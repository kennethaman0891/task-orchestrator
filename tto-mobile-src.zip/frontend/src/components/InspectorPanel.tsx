/**
 * InspectorPanel — annotation editor rendered as a floating panel.
 *
 * Shown after an element is selected.  Collects a user comment, then either
 * saves the annotation or sends it directly to the agent terminal.
 */

import { useEffect, useRef, useState } from 'react';
import type { Annotation } from '../types';
import { getStore, inspectorActions } from '../lib/inspector/store';
import { sendAnnotationToAgent } from '../api/client';

interface Props {
  activeTty: string | null;
  activeProjectPath?: string;
  activeWorkspaceName?: string;
  onAnnotationsChange?: (anns: Annotation[]) => void;
}

function formatAgentContext(ann: Annotation, projectPath?: string, workspaceName?: string): string {
  const src = ann.element.sourceExact
    ? `${ann.element.sourceFile ?? 'unknown'}:${ann.element.sourceLine ?? '?'}`
    : ann.element.sourceFile
      ? `${ann.element.sourceFile} (approx.)`
      : 'Source unknown — run in dev mode for full resolution';

  const dims = ann.element.computedStyles;
  const w = dims.width || '?';
  const h = dims.height || '?';

  const parts = [
    '## UI Annotation',
    '',
    '### Target',
    ann.element.componentName || ann.element.domTag,
    '',
    '### DOM',
    `\`${ann.element.selector}\``,
    '',
    '### React Component',
    ann.element.componentName || '(native DOM element)',
    '',
    '### Source',
    src,
    '',
    '### Project',
    projectPath || '(not set)',
  ];

  if (workspaceName) {
    parts.push('', '### Workspace', workspaceName);
  }

  parts.push(
    '',
    '### User Request',
    ann.userComment,
    '',
    '### Element Dimensions',
    `- Width: ${w}`,
    `- Height: ${h}`,
    `- Display: ${dims.display || '—'}`,
    `- Padding: ${dims.padding || '—'}`,
  );

  if (ann.element.role) parts.push(`- Role: ${ann.element.role}`);
  if (ann.element.ariaLabel) parts.push(`- Aria-label: ${ann.element.ariaLabel}`);

  return parts.filter(Boolean).join('\n');
}

export function InspectorPanel({
  activeTty,
  activeProjectPath,
  activeWorkspaceName,
  onAnnotationsChange,
}: Props) {
  const store = getStore();
  const selectedEl = store.selectedEl;
  const existingAnn = store.annotations.find((a) => a.element.id === selectedEl?.id);
  const [comment, setComment] = useState(existingAnn?.userComment ?? '');
  const [sending, setSending] = useState(false);
  const [sendResult, setSendResult] = useState<'ok' | 'err' | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!selectedEl) return;
    setComment(existingAnn?.userComment ?? '');
    setSendResult(null);
  }, [selectedEl?.id]);

  const panelTop = selectedEl
    ? Math.min(selectedEl.boundingBox.y + 16, window.innerHeight - 340)
    : 80;

  if (!selectedEl) return null;

  const handleCancel = () => {
    if (existingAnn) {
      inspectorActions.removeAnnotation(existingAnn.id);
      onAnnotationsChange?.(getStore().annotations);
    } else {
      inspectorActions.clearSelection();
    }
  };

  const handleSendToAgent = async () => {
    if (!selectedEl || !activeTty) return;
    const trimmed = comment.trim();
    if (!trimmed) return;

    setSending(true);
    setSendResult(null);

    let ann = existingAnn;
    if (!ann) {
      ann = {
        id: `ann-${Date.now()}`,
        element: selectedEl,
        userComment: trimmed,
        createdAt: Date.now(),
      };
      inspectorActions.addAnnotation(ann);
      onAnnotationsChange?.(getStore().annotations);
    } else {
      inspectorActions.editAnnotation(ann.id, trimmed);
      onAnnotationsChange?.(getStore().annotations);
    }

    try {
      await sendAnnotationToAgent(activeTty, {
        comment: formatAgentContext(ann, activeProjectPath, activeWorkspaceName),
        elementTag: selectedEl.domTag,
        elementClass: selectedEl.className,
        componentName: selectedEl.componentName || '',
        sourceFile: selectedEl.sourceFile,
        projectPath: activeProjectPath,
        boundingBox: selectedEl.boundingBox,
      });
      setSendResult('ok');
    } catch {
      setSendResult('err');
    } finally {
      setSending(false);
    }
  };

  const sourceInfo = selectedEl.sourceExact
    ? `${selectedEl.sourceFile}:${selectedEl.sourceLine ?? '?'}`
    : selectedEl.sourceFile
      ? `${selectedEl.sourceFile} (approx)`
      : 'Unknown — dev mode recommended';

  return (
    <div
      className="inspector-panel"
      data-inspector-ui
      ref={panelRef}
      style={{ right: '16px', top: `${panelTop}px` }}
    >
      <div className="inspector-panel-header">
        <span className="inspector-panel-component">
          {selectedEl.componentName || selectedEl.domTag}
        </span>
        <button className="inspector-panel-close" onClick={handleCancel} title="Close">
          ×
        </button>
      </div>

      <div className="inspector-panel-selector">{selectedEl.selector}</div>

      <div className="inspector-panel-meta">
        {selectedEl.componentName && (
          <div>
            <b>Component:</b> {selectedEl.componentName}
          </div>
        )}
        <div>
          <b>Source:</b> {sourceInfo}
        </div>
      </div>

      <div className="inspector-panel-field">
        <label>Instruction</label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Tell the coding agent what you want changed…"
          autoFocus
        />
      </div>

      {sendResult === 'err' && (
        <div className="inspector-send-err">
          Failed to send — make sure an opencode terminal is running.
        </div>
      )}

      <div className="inspector-panel-actions">
        <button className="btn-cancel-panel" onClick={handleCancel}>
          Cancel
        </button>
        <button
          className="btn-send-agent"
          onClick={handleSendToAgent}
          disabled={sending || !comment.trim() || !activeTty}
          title={activeTty ? 'Send to agent terminal' : 'No active terminal — open one first'}
        >
          {sending ? 'Sending…' : 'Send to Agent'}
        </button>
      </div>
    </div>
  );
}

export default InspectorPanel;
