import { useState } from 'react';
import type { TerminalEntry, UnifiedTerminal } from '../types';
import {
  addTask,
  completeTask,
  launchCli,
  updateContext,
  updateSessionContext,
  updateSessionName,
  suggestTask,
  acceptSuggestion,
  dismissSuggestion,
  generateSessionSummary,
} from '../api/client';
import { formatTokens, formatTime, cleanModel, isClosed } from '../lib/format';
import { StatusBadge } from './StatusBadge';
import { TaskInput } from './TaskInput';

interface TerminalCardProps {
  tty: string;
  t: TerminalEntry;
  onToast: (msg: string, isError?: boolean) => void;
}

export function TerminalCard({ tty, t, onToast }: TerminalCardProps) {
  const closed = isClosed(t);
  const cur = t.current_task;
  const next = t.next_task;
  const queue = t.queue || [];
  const history = t.history || [];
  const tok = t.tokens || {
    tokens_input: 0,
    tokens_output: 0,
    cost: 0,
    model: '',
    session_title: '',
  };
  const tokIn = tok.tokens_input || 0;
  const tokOut = tok.tokens_output || 0;
  const model = tok.model ? cleanModel(tok.model) : '';
  const hasTokens = tokIn > 0 || tokOut > 0;

  const [sname, setSname] = useState('');
  const [suggesting, setSuggesting] = useState(false);

  const handleSuggest = async () => {
    setSuggesting(true);
    try {
      const r = await suggestTask(tty);
      if (r.suggestion) {
        onToast(`Suggestion ready for ${tty}`);
      } else {
        onToast('No suggestion — add session context or history first', true);
      }
    } catch {
      onToast('Failed to generate suggestion', true);
    } finally {
      setSuggesting(false);
    }
  };

  const handleAcceptSuggestion = async () => {
    setSuggesting(true);
    try {
      await acceptSuggestion(tty);
      onToast(`Suggestion accepted on ${tty} — task created`);
    } catch {
      onToast('Failed to accept suggestion', true);
    } finally {
      setSuggesting(false);
    }
  };

  const handleDismissSuggestion = async () => {
    try {
      await dismissSuggestion(tty);
    } catch {
      onToast('Failed to dismiss suggestion', true);
    }
  };

  const handleAddTask = async (desc: string) => {
    try {
      await addTask(tty, desc);
      onToast(`Task sent to ${tty}: "${desc}"`);
    } catch (e) {
      onToast('Failed to add task: ' + (e as Error).message, true);
    }
  };

  const handleComplete = async () => {
    if (!cur) return;
    const summary = window.prompt('Task summary (what was done?):');
    if (summary === null) return;
    try {
      await completeTask(tty, cur.id, summary);
      onToast(`Task completed on ${tty}`);
    } catch {
      onToast('Failed to complete task', true);
    }
  };

  const handleSctx = async (v: string) => {
    try {
      await updateSessionContext(tty, v);
      onToast(`Session context saved for ${tty} — will persist to next task`);
    } catch {
      onToast('Failed to save session context', true);
    }
  };

  const handleGenSummary = async () => {
    setSuggesting(true);
    try {
      const r = await generateSessionSummary(tty);
      if (r.summary) {
        onToast(`Session summary: "${r.summary}"`);
      } else {
        onToast('No summary — add session context or complete a task first', true);
      }
    } catch {
      onToast('Failed to generate summary', true);
    } finally {
      setSuggesting(false);
    }
  };

  const handleTctx = async (v: string) => {
    try {
      await updateContext(tty, v);
      onToast(`Context saved for ${tty}`);
    } catch {
      onToast('Failed to save context', true);
    }
  };

  const handleSname = async (v: string) => {
    if (!v.trim()) {
      onToast('Enter a session name', true);
      return;
    }
    try {
      await updateSessionName(tty, v);
      onToast(`Session name set for ${tty}: "${v}"`);
      setSname('');
    } catch {
      onToast('Failed to set session name', true);
    }
  };

  const handleLaunchCli = async (cmd: string) => {
    try {
      await launchCli(tty, cmd);
      onToast(`Launched "${cmd}" in ${tty}`);
    } catch (e) {
      onToast('Failed to launch: ' + (e as Error).message, true);
    }
  };

  return (
    <div
      className={`terminal-card ${closed ? 'closed' : ''} ${t.pending_cli ? 'cli-pending' : ''}`}
    >
      <div className="card-header">
        <div className="card-title-block">
          <span
            className="tty"
            title={`${tty} — click to copy${t.cwd ? ` · ${t.cwd}` : ''}`}
            onClick={() => {
              navigator.clipboard.writeText(tty).catch(() => {});
              onToast(`Copied ${tty}`);
            }}
          >
            {(t as UnifiedTerminal).session_id
              ? `${(t as UnifiedTerminal).session_id} · ${tty}`
              : tty}
          </span>
          {t.cwd && (
            <span className="card-cwd" title={t.cwd}>
              {t.cwd}
            </span>
          )}
        </div>
        <div className="card-meta">
          {t.agent && <span className="agent-badge">{t.agent}</span>}
          {t.pending_cli && <span className="live-dot setup">setup</span>}
          <span className={`live-dot ${closed ? '' : 'live'}`}>{closed ? 'CLOSED' : 'LIVE'}</span>
        </div>
      </div>
      <div className="card-body">
        {t.pending_cli && (
          <div className="task-section cli-launch">
            <div className="task-label">Launch CLI in this terminal</div>
            <div className="cli-hint">
              Type an AI CLI name — <b>opencode</b>, <b>claude</b>, <b>codex</b>, <b>gemini</b> — it
              opens here.
            </div>
            <TaskInput
              placeholder="Type CLI name (opencode, claude, codex, gemini...) and press Enter"
              buttonLabel="Launch"
              onEnter={handleLaunchCli}
            />
          </div>
        )}
        <div className="session-row">
          <span className="session-tag">
            Session: {(t as UnifiedTerminal).session_id || t.session_name || '—'}
          </span>
          <span className="session-tag">Window: {t.window_name || '—'}</span>
          {t.pane_title && <span className="session-tag">Pane: {t.pane_title}</span>}
          <input
            className="session-input"
            type="text"
            placeholder="Set session name"
            value={sname}
            onChange={(e) => setSname(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleSname(sname);
              }
            }}
          />
          <button className="btn-session small btn" onClick={() => handleSname(sname)}>
            Set
          </button>
        </div>
        <div className="cwd" title={t.cwd || ''}>
          {t.cwd ? '📁 ' + t.cwd : 'no cwd'}
        </div>
        <div className="token-row">
          <span className="token-badge">
            {hasTokens
              ? `Tokens: ${formatTokens(tokIn)} in / ${formatTokens(tokOut)} out`
              : 'No tokens yet'}
          </span>
          {model && <span className="token-model">{model}</span>}
          {t.model && t.model !== tok.model && (
            <span
              className="token-model"
              style={{ background: 'rgba(139,92,246,0.15)', color: '#a78bfa' }}
              title="Model assigned by orchestrator/task center"
            >
              🎯 {cleanModel(t.model)}
            </span>
          )}
        </div>

        <div className="task-section">
          <div className="task-label">
            Session Context
            <button
              className="mini-btn"
              onClick={handleGenSummary}
              disabled={suggesting}
              title="Generate a one-line summary of what was done in this session"
            >
              ⚡
            </button>
          </div>
          <div className="task session-context">
            {suggesting ? (
              <div className="task suggestion">
                <span className="sugg-spinner">⟳</span> Summarizing session…
              </div>
            ) : t.session_summary ? (
              <div className="session-summary" title={t.session_summary}>
                💼 {t.session_summary}
              </div>
            ) : null}
            {t.session_context ? (
              <div className="context">📌 {t.session_context}</div>
            ) : (
              <div className="empty">
                No session context — add context that persists across tasks
              </div>
            )}
            <TaskInput
              className="sctx-input"
              placeholder="Session context/description (persists for next task)..."
              buttonLabel="Save"
              onEnter={handleSctx}
            />
          </div>
        </div>

        <div className="task-section">
          <div className="task-label">
            Suggested Next Task
            {!t.suggested_task && !suggesting && (
              <button
                className="mini-btn"
                onClick={handleSuggest}
                title="Generate a next-task suggestion from session context"
              >
                ⚡
              </button>
            )}
          </div>
          {suggesting ? (
            <div className="task suggestion">
              <span className="sugg-spinner">⟳</span> Generating from context…
            </div>
          ) : t.suggested_task ? (
            <div className="task suggestion">
              <div className="context">💡 {t.suggested_task}</div>
              <div className="sugg-actions">
                <button
                  className="mini-btn accept"
                  onClick={handleAcceptSuggestion}
                  disabled={suggesting}
                >
                  Accept
                </button>
                <button className="mini-btn" onClick={handleSuggest} disabled={suggesting}>
                  Regenerate
                </button>
                <button
                  className="mini-btn"
                  onClick={handleDismissSuggestion}
                  disabled={suggesting}
                >
                  Dismiss
                </button>
              </div>
            </div>
          ) : (
            <div className="empty">
              {cur && cur.status === 'running'
                ? 'Waiting for current task to finish…'
                : 'Auto-suggests after each task · click ⚡ to generate now'}
            </div>
          )}
        </div>

        <div className="task-section">
          <div className="task-label">Current Task</div>
          {cur ? (
            <>
              <div className="task">
                <StatusBadge status={cur.status} />
                {cur.description}
                {cur.context && <div className="context">📌 {cur.context}</div>}
                {cur.output && (
                  <div className="output" title="Live terminal output">
                    {cur.output}
                  </div>
                )}
                {cur.summary && <div className="summary">✓ {cur.summary}</div>}
              </div>
              <TaskInput
                placeholder="Context/description for this task..."
                buttonLabel="Save"
                onEnter={handleTctx}
                autoClear={false}
              />
            </>
          ) : (
            <div className="empty">No task assigned</div>
          )}
        </div>

        {t.live_output && (
          <div className="task-section">
            <div className="task-label">
              Live Output <span className="live-dot live">●</span>
            </div>
            <pre className="live-output" title="Real-time terminal output (updates every 1s)">
              {t.live_output}
            </pre>
          </div>
        )}

        <div className="task-section">
          <div className="task-label">Next Task</div>
          {next ? (
            <div className="task">
              <StatusBadge status={next.status} />
              {next.description}
              {next.context && <div className="context">📌 {next.context}</div>}
            </div>
          ) : (
            <div className="empty">None</div>
          )}
        </div>

        {queue.length > 0 && (
          <div className="queue">
            <div className="task-label">Queue ({queue.length})</div>
            {queue.map((q) => (
              <div className="task" key={q.id}>
                <StatusBadge status={q.status} />
                {q.description}
              </div>
            ))}
          </div>
        )}

        <TaskInput
          placeholder="Assign new task (Enter to send)..."
          buttonLabel="Add"
          onEnter={handleAddTask}
        />

        {cur && (
          <button className="btn done-btn small done-btn-full" onClick={handleComplete}>
            ✓ Mark Done
          </button>
        )}

        {history.length > 0 && (
          <div className="history">
            <div className="task-label">History — Task Summaries (last {history.length})</div>
            {history.map((h) => (
              <div className="h-item" key={h.id}>
                <span className="h-done">✓</span>
                <span>
                  <b>{h.description}</b>
                </span>
                <span className="h-time">{formatTime(h.completed_at)}</span>
                {h.summary && <div className="h-full h-summary">Summary: {h.summary}</div>}
                {h.context && <div className="h-full h-context">Context: {h.context}</div>}
                {h.output && <div className="output h-output">{h.output}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
