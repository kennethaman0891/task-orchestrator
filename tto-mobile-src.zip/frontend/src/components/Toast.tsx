export interface ToastState {
  message: string;
  error?: boolean;
  id: number;
}

export function Toast({ toast }: { toast: ToastState | null }) {
  if (!toast) return null;
  return (
    <div key={toast.id} className={`toast show ${toast.error ? 'toast-error' : ''}`}>
      {toast.message}
    </div>
  );
}
