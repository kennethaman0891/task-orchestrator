import { memo, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { TerminalPane } from '../terminal/TerminalPane';
import {
  getParkingElement,
  getSlotNode,
  getTerminalAnchor,
  setSlotNode,
  setTerminalAnchor,
} from '../terminal/TerminalPlacement';

/** Memoized terminal renderer — one terminal changing never re-renders the rest. */
const TerminalPaneMemo = memo(TerminalPane);

/** Per-session rendering state, computed by App for the current view. */
export interface TerminalSessionState {
  /** Pane id used for TUI-change routing (grid pane id, or `workspace-<sid>`).
   *  The underlying xterm instance is keyed by sessionId and NEVER remounts on
   *  paneId changes (TerminalPane reads it through a ref). */
  paneId: string;
  visible: boolean;
  focused: boolean;
}

interface TerminalHostProps {
  /** Every session that must stay mounted (all workspace panes ∪ focused). */
  sessionIds: string[];
  /** Per-session visible/focused/paneId for the CURRENT view. */
  sessionStates: Record<string, TerminalSessionState>;
  /** Active view — gates link detection to the workspace view (as before). */
  view: string;
  onToast?: (msg: string, error?: boolean) => void;
  onRestart?: (sessionId: string) => void;
  onKill?: (sessionId: string) => void;
  onNewTerminal?: () => void;
  onTuiChange?: (active: boolean, paneId: string) => void;
  onLinkClick?: (target: string, lineNumber?: number, isUrl?: boolean) => void;
  /** Handle files dragged into a terminal pane. Receives absolute paths. */
  onDrop?: (sessionId: string, paths: string[]) => void;
}

/**
 * TerminalHost — the SINGLE always-mounted owner of every xterm instance.
 *
 * WHY: the workspace, grid and other views used to each render their OWN
 * <TerminalPane> tree. Switching views unmounted the other tree, disposing the
 * xterm instances (and their client-side scrollback) — the PTY stayed alive in
 * Rust, but returning to the view showed a BLANK terminal.
 *
 * HOW: TerminalHost renders each session's <TerminalPane> exactly once, forever,
 * inside a per-session "slot" div rendered into via a STABLE React portal. Views
 * render lightweight <TerminalAnchor> placeholders; TerminalAnchor moves each
 * session's slot div into itself (see TerminalPlacement.ts for the why this is
 * order-safe and remount-free). The anchorless slots sit OFFSCREEN AT FULL SIZE
 * in .th-parking — never display:none, because collapsing xterm's host to 0×0
 * invalidates its render dimensions and its row cache never recovers.
 *
 * The existing TerminalPane `visible` effect (refit on reveal) is preserved:
 * `visible` flips true exactly when the slot lands in a shown anchor.
 */
export function TerminalHost({
  sessionIds,
  sessionStates,
  view,
  onToast,
  onRestart,
  onKill,
  onNewTerminal,
  onTuiChange,
  onLinkClick,
  onDrop,
}: TerminalHostProps) {
  return (
    <>
      {sessionIds.map((sid) => (
        <TerminalPanePortal
          key={sid}
          sessionId={sid}
          state={
            sessionStates[sid] ?? {
              paneId: `workspace-${sid}`,
              visible: false,
              focused: false,
            }
          }
          view={view}
          onToast={onToast}
          onRestart={onRestart}
          onKill={onKill}
          onNewTerminal={onNewTerminal}
          onTuiChange={onTuiChange}
          onLinkClick={view === 'workspace' ? onLinkClick : undefined}
          onDrop={onDrop}
        />
      ))}
    </>
  );
}

interface PanePortalProps {
  sessionId: string;
  state: TerminalSessionState;
  view: string;
  onToast?: (msg: string, error?: boolean) => void;
  onRestart?: (sessionId: string) => void;
  onKill?: (sessionId: string) => void;
  onNewTerminal?: () => void;
  onTuiChange?: (active: boolean, paneId: string) => void;
  onLinkClick?: (target: string, lineNumber?: number, isUrl?: boolean) => void;
  onDrop?: (sessionId: string, paths: string[]) => void;
}

function TerminalPanePortal({
  sessionId,
  state,
  view,
  onToast,
  onRestart,
  onKill,
  onNewTerminal,
  onTuiChange,
  onLinkClick,
  onDrop,
}: PanePortalProps) {
  // The slot div is NOT rendered by React — it is a plain DOM node that the
  // portal renders into and that TerminalAnchor physically moves between views.
  // Reparenting it is invisible to React, so the TerminalPane inside NEVER
  // unmounts across view switches.
  const [slotEl, setSlotEl] = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    const node = document.createElement('div');
    node.className = 'th-slot';
    node.dataset.sessionId = sessionId;
    setSlotNode(sessionId, node);
    // Park offscreen at full size until an anchor claims it.
    const park = getParkingElement();
    if (node.parentNode !== park) park.appendChild(node);
    setSlotEl(node);
    return () => {
      setSlotNode(sessionId, null);
      node.remove();
    };
  }, [sessionId]);

  // Placement safety net: after the slot exists, make sure it sits in the
  // currently registered anchor (or parking). Runs AFTER the commit's refs and
  // layout effects, so for a freshly-mounted anchor the registry is up to date
  // (this is also what places brand-new sessions whose slot didn't exist when
  // the anchor's own mount effect ran).
  useEffect(() => {
    if (!slotEl) return;
    const dest = getTerminalAnchor(sessionId) ?? getParkingElement();
    if (slotEl.parentNode !== dest) dest.appendChild(slotEl);
  }, [slotEl, sessionId]);

  if (!slotEl) return null;

  return createPortal(
    <TerminalPaneMemo
      sessionId={sessionId}
      paneId={state.paneId}
      onToast={onToast}
      onRestart={onRestart}
      onKill={onKill}
      onNewTerminal={onNewTerminal}
      onTuiChange={onTuiChange}
      onLinkClick={view === 'workspace' ? onLinkClick : undefined}
      visible={state.visible}
      focused={state.focused}
      onDrop={onDrop ? (paths) => onDrop(sessionId, paths) : undefined}
    />,
    slotEl,
  );
}

/**
 * TerminalAnchor — the lightweight placeholder a view renders where a terminal
 * should appear. On mount it moves the session's slot div (from TerminalHost)
 * into itself; on unmount (view switch / pane close) it returns the slot to the
 * offscreen full-size parking area. Nothing here ever destroys the xterm.
 *
 * Ordering note: in React's commit layout phase, a host element's ref attaches
 * when its own fiber is visited (its children before itself), so by the time
 * THIS anchor's layout effect runs, this very anchor is already registered —
 * reading the slot registry and moving the slot are safe and happen before
 * paint, so view switches never show an empty cell.
 */
export const TerminalAnchor = memo(function TerminalAnchor({ sessionId }: { sessionId: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const prevSid = useRef(sessionId);
  const latestSid = useRef(sessionId);
  latestSid.current = sessionId;

  // Callback ref: (a) keep the element for our own layout effect, and
  // (b) register/unregister in TerminalPlacement so TerminalHost's portals can
  // route slots to this anchor even when the slot node did not exist yet at
  // mount time (e.g. initial page load / brand-new sessions).
  const attachRef = useCallback(
    (el: HTMLDivElement | null) => {
      ref.current = el;
      setTerminalAnchor(sessionId, el);
    },
    [sessionId],
  );

  useLayoutEffect(() => {
    const park = getParkingElement();
    // If this anchor reused for a DIFFERENT session (re-assign in place), the
    // previous session's slot must go back to parking first.
    const prev = prevSid.current;
    prevSid.current = sessionId;
    if (prev && prev !== sessionId) {
      const oldSlot = getSlotNode(prev);
      if (oldSlot && oldSlot.parentNode !== park) park.appendChild(oldSlot);
    }
    // Move the current session's slot into this anchor.
    const el = ref.current;
    const slot = getSlotNode(sessionId);
    if (el && slot && slot.parentNode !== el) el.appendChild(slot);
  }, [sessionId]);

  // On unmount, hand the slot back to the parking area — xterm keeps real
  // dimensions and stays mounted for the next time this session is shown.
  useLayoutEffect(
    () => () => {
      const slot = getSlotNode(latestSid.current);
      if (!slot) return;
      const park = getParkingElement();
      if (slot.parentNode !== park) park.appendChild(slot);
    },
    [],
  );

  return <div className="term-anchor" ref={attachRef} />;
});

TerminalAnchor.displayName = 'TerminalAnchor';
