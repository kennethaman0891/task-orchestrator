import { useEffect, useState } from 'react';
import type { TokenUsage as TokenUsageData } from '../types';
import { getTokenUsage, updateTokenLimit } from '../api/client';
import { formatTokens } from '../lib/format';

export function TokenUsage({
  live,
  onToast,
}: {
  live?: TokenUsageData | null;
  onToast: (msg: string, error?: boolean) => void;
}) {
  const [local, setLocal] = useState<TokenUsageData | null>(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false); // collapsed by default — keeps vertical space for terminals
  const [editing, setEditing] = useState<string | null>(null);
  const [limitInput, setLimitInput] = useState('');

  const data = live ?? local;

  const load = () => {
    getTokenUsage()
      .then(setLocal)
      .catch(() => onToast('Failed to load token usage', true));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveLimit = (key: string) => {
    const parsed = parseInt(limitInput.replace(/[,_\s]/g, ''), 10);
    const valid = /^[0-9.,\s]+$/.test(limitInput.trim());
    if (!valid || isNaN(parsed) || parsed <= 0) {
      onToast('Enter a valid token limit (e.g. 1500000000 or 1,500,000,000)', true);
      return;
    }
    setLoading(true);
    updateTokenLimit(key, parsed)
      .then((d) => {
        setLocal(d);
        setEditing(null);
        onToast('Token limit saved');
      })
      .catch(() => onToast('Failed to save token limit', true))
      .finally(() => setLoading(false));
  };

  const clearLimit = (key: string) => {
    setLoading(true);
    updateTokenLimit(key, null)
      .then((d) => {
        setLocal(d);
        setEditing(null);
        onToast('Token limit cleared');
      })
      .catch(() => onToast('Failed to clear token limit', true))
      .finally(() => setLoading(false));
  };

  if (!data) {
    return (
      <div className="token-panel">
        <div className="token-title">Token Usage</div>
        <div className="empty">Loading token usage…</div>
      </div>
    );
  }

  const { totals, models } = data;

  // Compact one-line summary shown when collapsed.
  const compact = (
    <span className="token-compact">
      <span className="token-compact-item">
        Available <b>{formatTokens(totals.available)}</b>
      </span>
      <span className="token-compact-item">
        Used <b>{formatTokens(totals.used)}</b>
      </span>
      <span className="token-compact-item">
        Left{' '}
        <b className={totals.left < totals.available * 0.2 ? 'low' : ''}>
          {formatTokens(totals.left)}
        </b>
      </span>
    </span>
  );

  return (
    <div className={`token-panel ${expanded ? 'expanded' : ''}`}>
      <div className="token-panel-header" onClick={() => setExpanded((e) => !e)}>
        <span className="token-title">
          Token Usage{' '}
          <span
            className="token-refresh"
            onClick={(e) => {
              e.stopPropagation();
              load();
            }}
            title="Refresh"
          >
            ↻
          </span>
        </span>
        {!expanded && compact}
        <span className={`token-chevron ${expanded ? 'open' : ''}`}>{expanded ? '▾' : '▸'}</span>
      </div>

      {expanded && (
        <>
          <div className="token-totals">
            <div className="token-total-item">
              <span className="token-total-label">Total Available Tokens</span>
              <span className="token-total-value">{formatTokens(totals.available)}</span>
            </div>
            <div className="token-total-item">
              <span className="token-total-label">Used</span>
              <span className="token-total-value">{formatTokens(totals.used)}</span>
            </div>
            <div className="token-total-item">
              <span className="token-total-label">Left</span>
              <span
                className={`token-total-value ${totals.left < totals.available * 0.2 ? 'low' : ''}`}
              >
                {formatTokens(totals.left)}
              </span>
            </div>
            {totals.available > 0 && (
              <div className="token-bar">
                <div
                  className="token-bar-fill"
                  style={{ width: `${Math.min(100, (totals.used / totals.available) * 100)}%` }}
                />
              </div>
            )}
          </div>

          {models.length === 0 ? (
            <div className="empty">
              No models have used more than {formatTokens(data.threshold)} tokens yet.
            </div>
          ) : (
            <table className="token-table">
              <thead>
                <tr>
                  <th>Model</th>
                  <th className="num">Used</th>
                  <th className="num">Limit</th>
                  <th className="num">Left</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {models.map((m) => (
                  <tr key={m.key}>
                    <td>
                      <span className="token-model-name" title={`${m.provider} · ${m.key}`}>
                        {m.name}
                      </span>
                      <span className="token-provider">{m.provider}</span>
                    </td>
                    <td className="num">{formatTokens(m.used)}</td>
                    <td className="num">
                      {editing === m.key ? (
                        <span className="token-limit-edit">
                          <input
                            value={limitInput}
                            onChange={(e) => setLimitInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') saveLimit(m.key);
                              if (e.key === 'Escape') setEditing(null);
                            }}
                            autoFocus
                            placeholder="e.g. 1,500,000,000"
                          />
                          <button className="mini-btn" onClick={() => saveLimit(m.key)}>
                            ✓
                          </button>
                          <button className="mini-btn" onClick={() => setEditing(null)}>
                            ✕
                          </button>
                        </span>
                      ) : m.limit !== null && m.limit !== undefined ? (
                        formatTokens(m.limit)
                      ) : (
                        <span
                          className="muted"
                          title="This model has a usage limit that is not publicly disclosed (e.g. DeepSeek free tier). No exact number is shown because the provider does not publish one."
                        >
                          limited
                        </span>
                      )}
                    </td>
                    <td
                      className={`num ${m.left !== null && m.left !== undefined && m.left < 0 ? 'over' : ''}`}
                    >
                      {m.left !== null && m.left !== undefined ? formatTokens(m.left) : '—'}
                    </td>
                    <td className="num">
                      {editing === m.key ? (
                        <button
                          className="mini-btn"
                          onClick={() => clearLimit(m.key)}
                          disabled={loading}
                        >
                          clear
                        </button>
                      ) : (
                        <button
                          className="mini-btn"
                          onClick={() => {
                            setEditing(m.key);
                            setLimitInput(m.limit != null ? String(m.limit) : '');
                          }}
                        >
                          ✎
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <div className="token-note">
            Showing models with {formatTokens(data.threshold)}+ tokens used · totals are strict sums
            across all sessions, never averages · "limited" = the model has a usage cap that is not
            publicly disclosed · limit for "OmniRoute Local AI" combines all auto/* models
          </div>
        </>
      )}
    </div>
  );
}
