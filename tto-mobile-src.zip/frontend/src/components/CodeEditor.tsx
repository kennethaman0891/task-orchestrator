import { useEffect, useRef, useCallback, useState } from 'react';
import {
  EditorView,
  keymap,
  lineNumbers,
  highlightActiveLine,
  highlightSpecialChars,
} from '@codemirror/view';
import { EditorState } from '@codemirror/state';
import { defaultKeymap, history, historyKeymap } from '@codemirror/commands';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
import { oneDark } from '@codemirror/theme-one-dark';
import { searchKeymap, highlightSelectionMatches } from '@codemirror/search';
import { autocompletion, closeBrackets } from '@codemirror/autocomplete';
import { linter, lintGutter } from '@codemirror/lint';
import { showMinimap } from '@oeyoews/codemirror-minimap';
import { getFile, putFile } from '../api/client';
import { apiBase, isTauri } from '../api/base';
import { convertFileSrc } from '@tauri-apps/api/core';

function detectLang(filename: string) {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  if (['js', 'jsx', 'ts', 'tsx', 'mjs', 'cjs'].includes(ext)) return javascript();
  if (['py', 'pyi'].includes(ext)) return python();
  if (['html', 'htm', 'vue', 'svelte'].includes(ext)) return html();
  if (['css', 'scss', 'less'].includes(ext)) return css();
  if (['json', 'jsonc'].includes(ext)) return json();
  return javascript();
}

/** Simple inline linter — checks for trailing whitespace and missing newlines. */
const simpleLinter = linter(() => {
  // Return empty array for now — real linters (pyright, eslint) would go here
  // This provides the infrastructure; the lint dot shows it's wired
  return [];
});

/**
 * Paths whose unsaved buffer the user explicitly chose to DISCARD (via the
 * close-confirm dialog). The unmount flush in the load-effect cleanup skips
 * these so a confirmed "Discard unsaved changes" actually discards.
 */
const discardOnClose = new Set<string>();
export function markDiscardOnClose(path: string) {
  discardOnClose.add(path);
}

/** Jump the editor cursor to a 1-based line (clamped to the document). */
function jumpToLine(view: EditorView, line: number) {
  try {
    const l = view.state.doc.line(Math.max(1, line));
    view.dispatch({ selection: { anchor: l.from }, scrollIntoView: true });
  } catch {
    /* line out of range */
  }
}

/** Returns a small emoji icon for common file extensions. */
export function fileIcon(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    ts: '💻',
    tsx: '💻',
    js: '💻',
    jsx: '💻',
    mjs: '💻',
    cjs: '💻',
    py: '✦',
    pyi: '✦',
    html: '📄',
    htm: '📄',
    vue: '📄',
    svelte: '📄',
    css: '🎨',
    scss: '🎨',
    less: '🎨',
    json: '📋',
    jsonc: '📋',
    rs: '🦀',
    go: '🔷',
    rb: '💎',
    sh: '⚙️',
    bash: '⚙️',
    yaml: '⚙️',
    yml: '⚙️',
    toml: '⚙️',
    cfg: '⚙️',
    ini: '⚙️',
    env: '⚙️',
    md: '📝',
    mdx: '📝',
    svg: '🖼',
    png: '🖼',
    jpg: '🖼',
    jpeg: '🖼',
    gif: '🖼',
    sql: '🗃',
    sqlite: '🗃',
    gitignore: '🔒',
  };
  return map[ext] ?? '📄';
}

interface Props {
  path: string;
  name: string;
  onClose: () => void;
  onToast: (msg: string, error?: boolean) => void;
  /** Jump to this line number when the editor loads (from terminal link clicks). */
  gotoLine?: number;
  /** Called when content has unsaved changes — used for tab dirty indicator. */
  onChange?: (dirty: boolean) => void;
  /** Called with the 1-based line/column of the cursor whenever the
      selection moves — powers the live Ln/Col readout in the status bar. */
  onCursor?: (line: number, col: number) => void;
}

/** Image extensions that should be previewed instead of opened in CodeMirror. */
const IMAGE_EXTS = new Set(['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'bmp', 'ico', 'avif']);

function isImageFile(filename: string): boolean {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  return IMAGE_EXTS.has(ext);
}

export function CodeEditor({ path, name, onClose, onToast, gotoLine, onChange, onCursor }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const saveTimerRef = useRef<number | undefined>(undefined);
  const hasChangesRef = useRef(false);
  // Serializes EditorView creation so two views can never attach to one host
  // (initial load + lint-toggle re-create race).
  const creatingRef = useRef(false);
  // Live copy of the onCursor callback so the (single-mount) update listener
  // never reads a stale closure.
  const onCursorRef = useRef(onCursor);
  onCursorRef.current = onCursor;

  // ── Image preview detection ─────────────────────────────────────────────
  const isImage = isImageFile(name);
  const imageExt = name.split('.').pop()?.toLowerCase() || '';
  const isSvg = imageExt === 'svg';

  // ── Auto-save ──────────────────────────────────────────────────────────
  const [autoSave, setAutoSave] = useState(() => {
    try {
      return localStorage.getItem('autoSave') !== 'false';
    } catch {
      return true;
    }
  });
  // Live copy of the toggle for the (stale-closure-prone) update listener.
  const autoSaveRef = useRef(autoSave);

  const toggleAutoSave = useCallback(() => {
    setAutoSave((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('autoSave', String(next));
      } catch {}
      return next;
    });
  }, []);

  // ── Lint indicator (placeholder) ───────────────────────────────────────
  const [lintEnabled, setLintEnabled] = useState(() => {
    try {
      return localStorage.getItem('lintEnabled') === 'true';
    } catch {
      return false;
    }
  });

  // ── Load editor ────────────────────────────────────────────────────────
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let cancelled = false;
    if (creatingRef.current) return; // another view is mid-creation for this host
    creatingRef.current = true;

    getFile(path)
      .then(({ content }) => {
        if (cancelled) return;
        const state = EditorState.create({
          doc: content,
          extensions: [
            lineNumbers(),
            highlightActiveLine(),
            highlightSpecialChars(),
            history(),
            autocompletion(),
            closeBrackets(),
            highlightSelectionMatches(),
            keymap.of([...defaultKeymap, ...historyKeymap, ...searchKeymap]),
            detectLang(name),
            oneDark,
            EditorView.lineWrapping,
            // Lint gutter always visible; linter runs only when enabled
            lintGutter(),
            ...(lintEnabled ? [simpleLinter] : []),
            // Minimap — proper implementation with content
            showMinimap.of({
              create: () => {
                const dom = document.createElement('div');
                dom.className = 'cm-minimap';
                return { dom };
              },
              displayText: 'blocks',
              showOverlay: 'mouse-over',
            }),
            EditorView.updateListener.of((update) => {
              if (update.selectionSet || update.docChanged) {
                // Live Ln/Col readout: 1-based line/column of the cursor head.
                const head = update.state.selection.main.head;
                const lineObj = update.state.doc.lineAt(head);
                onCursorRef.current?.(lineObj.number, head - lineObj.from + 1);
              }
              if (update.docChanged) {
                hasChangesRef.current = true;
                onChange?.(true);
                if (autoSaveRef.current) {
                  clearTimeout(saveTimerRef.current);
                  saveTimerRef.current = window.setTimeout(() => {
                    if (hasChangesRef.current && autoSaveRef.current && viewRef.current) {
                      doSave(viewRef.current, path, name, onToast, () => {
                        hasChangesRef.current = false;
                        onChange?.(false);
                      });
                    }
                  }, 2000);
                }
              }
            }),
          ],
        });
        const view = new EditorView({ state, parent: host });
        viewRef.current = view;
        if (gotoLine) jumpToLine(view, gotoLine);
      })
      .catch(() => {
        if (!cancelled) onToast(`Failed to load ${path}`, true);
      })
      .finally(() => {
        if (!cancelled) creatingRef.current = false;
      });

    return () => {
      cancelled = true;
      creatingRef.current = false;
      clearTimeout(saveTimerRef.current);
      const view = viewRef.current;
      if (view && hasChangesRef.current) {
        if (discardOnClose.has(path)) {
          // User confirmed discarding this file's changes — do NOT flush.
          discardOnClose.delete(path);
        } else {
          // Flush unsaved edits before destroying the view (autosave off, or a
          // pending autosave timer). Capture the doc BEFORE destroying.
          const content = view.state.doc.toString();
          hasChangesRef.current = false;
          void putFile(path, content)
            .then(() => onChange?.(false))
            .catch(() => {});
        }
      }
      viewRef.current?.destroy();
      viewRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, name, gotoLine]);

  // Jump to line after editor loads
  useEffect(() => {
    if (!gotoLine || !viewRef.current) return;
    const view = viewRef.current;
    const line = view.state.doc.line(gotoLine);
    view.dispatch({ selection: { anchor: line.from } });
    // Clear pending line after using it
    (window as any).__tto_pending_goto_line = null;
  }, [gotoLine]);

  // Keep the ref in sync with the toggle so the (single-mount) update listener
  // always reads the CURRENT setting — fixes stale-closure autosave toggling.
  useEffect(() => {
    autoSaveRef.current = autoSave;
    clearTimeout(saveTimerRef.current);
  }, [autoSave]);

  // Re-create editor view when lint toggle changes so extensions are re-bound.
  // Uses the CURRENT buffer (NOT a re-fetch from disk) so unsaved edits survive
  // the toggle. Serialized with creatingRef so two views can't share a host.
  useEffect(() => {
    const view = viewRef.current;
    const host = hostRef.current;
    if (!view || !host) return; // nothing mounted yet (initial load in flight)
    if (creatingRef.current) return; // load effect is creating — it attaches with fresh config
    const doc = view.state.doc.toString();
    viewRef.current?.destroy();
    viewRef.current = null;
    creatingRef.current = true;
    try {
      const state = EditorState.create({
        doc,
        extensions: [
          lineNumbers(),
          highlightActiveLine(),
          highlightSpecialChars(),
          history(),
          autocompletion(),
          closeBrackets(),
          highlightSelectionMatches(),
          keymap.of([...defaultKeymap, ...historyKeymap, ...searchKeymap]),
          detectLang(name),
          oneDark,
          EditorView.lineWrapping,
          lintGutter(),
          ...(lintEnabled ? [simpleLinter] : []),
          showMinimap.of({
            create: () => ({ dom: document.createElement('div') }),
            displayText: 'blocks',
            showOverlay: 'mouse-over',
          }),
          EditorView.updateListener.of((update) => {
            if (update.selectionSet || update.docChanged) {
              const head = update.state.selection.main.head;
              const lineObj = update.state.doc.lineAt(head);
              onCursorRef.current?.(lineObj.number, head - lineObj.from + 1);
            }
            if (update.docChanged) {
              hasChangesRef.current = true;
              onChange?.(true);
              if (autoSaveRef.current) {
                clearTimeout(saveTimerRef.current);
                saveTimerRef.current = window.setTimeout(() => {
                  if (hasChangesRef.current && autoSaveRef.current && viewRef.current) {
                    doSave(viewRef.current, path, name, onToast, () => {
                      hasChangesRef.current = false;
                      onChange?.(false);
                    });
                  }
                }, 2000);
              }
            }
          }),
        ],
      });
      const freshView = new EditorView({ state, parent: host });
      viewRef.current = freshView;
      if (gotoLine) jumpToLine(freshView, gotoLine);
    } finally {
      creatingRef.current = false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lintEnabled]);

  // ── Save ───────────────────────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    const view = viewRef.current;
    if (!view) return;
    await doSave(view, path, name, onToast, () => {
      hasChangesRef.current = false;
      onChange?.(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, name, onToast]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [handleSave]);

  // ── Image preview renderer ──────────────────────────────────────────────
  if (isImage) {
    // Tauri: WKWebView blocks file:// URLs — use convertFileSrc (asset protocol).
    // Web: the sidecar blob endpoint serves the binary with a proper MIME type.
    const imageUrl = isTauri()
      ? convertFileSrc(path)
      : `${apiBase()}/api/file/blob?path=${encodeURIComponent(path)}`;
    return (
      <div className="editor-panel">
        <div className="editor-header">
          <div className="editor-actions">
            <span className="editor-image-badge">🖼 Image Preview</span>
            <button className="mini-btn" onClick={onClose} title="Close">
              ×
            </button>
          </div>
        </div>
        <div className="editor-image-preview">
          {isSvg ? (
            <div className="editor-image-svg-wrap">
              <object data={imageUrl} type="image/svg+xml" className="editor-image-svg" />
            </div>
          ) : (
            <img
              src={imageUrl}
              alt={name}
              className="editor-image-img"
              onError={(e) => {
                const target = e.currentTarget as HTMLImageElement;
                target.style.display = 'none';
                const fallback = target.nextElementSibling as HTMLElement;
                if (fallback) fallback.style.display = 'flex';
              }}
            />
          )}
          <div className="editor-image-fallback" style={{ display: 'none' }}>
            <div className="editor-image-fallback-icon">🖼</div>
            <div className="editor-image-fallback-text">Cannot preview this image</div>
            <div className="editor-image-fallback-path">{path}</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="editor-panel">
      <div className="editor-header">
        <div className="editor-actions">
          {/* Lint dot — clickable button for keyboard accessibility */}
          <button
            type="button"
            className={`lint-dot ${lintEnabled ? 'lint-ok' : 'lint-off'}`}
            title={
              lintEnabled
                ? 'Linting enabled — syntax checking active'
                : 'Linting disabled — click to enable'
            }
            aria-pressed={lintEnabled}
            aria-label={lintEnabled ? 'Linting enabled' : 'Linting disabled'}
            onClick={() => {
              const next = !lintEnabled;
              try {
                localStorage.setItem('lintEnabled', String(next));
              } catch {}
              setLintEnabled(next);
            }}
          >
            ●
          </button>
          {/* Auto-save toggle */}
          <button
            className={`mini-btn autosave-btn${autoSave ? ' autosave-on' : ''}`}
            onClick={toggleAutoSave}
            title={autoSave ? 'Auto-save on — saves 2s after typing' : 'Auto-save off'}
          >
            {autoSave ? '⟳ Auto' : '⟳'}
          </button>
          <button className="mini-btn" onClick={handleSave} title="Save (Ctrl/Cmd+S)">
            Save
          </button>
          <button className="mini-btn" onClick={onClose} title="Close">
            ×
          </button>
        </div>
      </div>
      <div className="editor-host" ref={hostRef} />
    </div>
  );
}

async function doSave(
  view: EditorView,
  path: string,
  name: string,
  onToast: (msg: string, error?: boolean) => void,
  onSaved?: () => void,
) {
  const content = view.state.doc.toString();
  try {
    await putFile(path, content);
    onToast(`Saved ${name}`);
    onSaved?.();
  } catch {
    onToast(`Failed to save ${name}`, true);
  }
}
