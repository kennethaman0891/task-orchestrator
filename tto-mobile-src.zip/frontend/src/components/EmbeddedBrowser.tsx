import { useState, useRef } from 'react';
import './EmbeddedBrowser.css';
import { apiBase } from '../api/base';

interface EmbeddedBrowserProps {
  /** The real URL to display. Parent (IDEView) owns this. */
  url: string;
  /** Fired when the address bar / toolbar should navigate somewhere new. */
  onUrlChange: (url: string) => void;
  /** Fired for explicit user navigation (typed URL / retry). */
  onNavigate?: (url: string) => void;
  /** Accepted for API compatibility; the parent owns history in this controlled
   *  implementation (the IDEView sidebar + large overlay share one history). */
  initialHistory?: string[];
  initialHistoryIndex?: number;
  onClose?: () => void;
}

const DEFAULT_HOME = 'https://duckduckgo.com';

/**
 * In-panel browser for the IDE.
 *
 * Sites like Google / DuckDuckGo / Wikipedia send X-Frame-Options / CSP
 * `frame-ancestors`, which blank a raw iframe. The backend `/api/browse`
 * proxy strips those headers, injects a `<base>` for relative assets, and
 * rewrites every link/form to host-relative `/api/browse?url=…` URLs — so
 * the page renders AND all navigation (clicks, forms, redirects) stays inside
 * the proxy and the iframe. The proxy re-validates every hop (scheme + SSRF),
 * so the existing security model holds.
 *
 * This component is CONTROLLED: the iframe mirrors `props.url` (proxied),
 * and when the user wants a different site it calls `onUrlChange`/`onNavigate`
 * so the parent (IDEView) records history and feeds the URL back.
 */
export function EmbeddedBrowser({
  url: controlledUrl,
  onUrlChange,
  onNavigate,
  onClose,
}: EmbeddedBrowserProps) {
  const url = controlledUrl || DEFAULT_HOME;

  const [editing, setEditing] = useState<string | null>(null); // address-bar draft
  const [loading, setLoading] = useState(true);
  const [loadFailed, setLoadFailed] = useState(false);
  const reloadNonce = useRef(0); // bump to force the iframe to re-fetch

  const iframeSrc = `${apiBase()}/api/browse?url=${encodeURIComponent(url)}${
    reloadNonce.current ? `#__tto=${reloadNonce.current}` : ''
  }`;

  const normalize = (raw: string): string => {
    let target = raw.trim();
    if (!target) return url;
    if (!/^[a-z][a-z0-9+.-]*:/i.test(target)) target = 'https://' + target;
    try {
      const parsed = new URL(target);
      if (!parsed.hostname) throw new Error('no host');
    } catch {
      target = `https://duckduckgo.com/?q=${encodeURIComponent(raw.trim())}`;
    }
    return target;
  };

  const handleSubmit = () => {
    if (editing === null) return;
    const target = normalize(editing);
    setEditing(null);
    setLoading(true);
    setLoadFailed(false);
    if (target === url) {
      reloadNonce.current += 1; // same site → hard reload
    }
    onUrlChange?.(target);
    onNavigate?.(target);
  };

  const handleReload = () => {
    reloadNonce.current += 1;
    setLoading(true);
    setLoadFailed(false);
  };

  return (
    <div className="embedded-browser">
      {/* ── Toolbar ── */}
      <div className="browser-toolbar">
        <button className="browser-btn" onClick={handleReload} title="Reload" disabled={loading}>
          ↻
        </button>

        <form
          className="browser-url-form"
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
        >
          <input
            className="browser-url-input"
            type="text"
            value={editing === null ? url : editing}
            onChange={(e) => setEditing(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') setEditing(null);
            }}
            placeholder="Enter URL..."
            spellCheck={false}
          />
        </form>

        {onClose && (
          <button className="browser-btn" onClick={onClose} title="Close browser">
            ✕
          </button>
        )}
      </div>

      {/* ── Content: proxied iframe ── */}
      <div className="browser-webview-container">
        {loadFailed && (
          <div className="browser-error-fallback">
            <div className="browser-error-content">
              <div className="browser-error-icon">🌐</div>
              <h3 className="browser-error-title">Browser Error</h3>
              <p className="browser-error-message">
                This site could not be loaded in the embedded browser. It may block proxied viewing,
                or the backend may be unreachable.
              </p>
              <button
                className="browser-error-btn"
                onClick={() => {
                  setLoadFailed(false);
                  setLoading(true);
                  reloadNonce.current += 1;
                }}
              >
                Retry
              </button>
            </div>
          </div>
        )}
        {!loadFailed && (
          <iframe
            key={`${url}|${reloadNonce.current}`}
            className="browser-webview"
            src={iframeSrc}
            title={`Embedded browser — ${url}`}
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-presentation"
            onLoad={() => {
              setLoading(false);
              setLoadFailed(false);
            }}
            onError={() => setLoadFailed(true)}
            allow="clipboard-read; clipboard-write; fullscreen"
          />
        )}
        {loading && !loadFailed && (
          <div className="browser-loading">
            <div className="browser-loading-spinner" />
            <span>Loading {url}...</span>
          </div>
        )}
      </div>

      {/* ── Status Bar ── */}
      <div className="browser-status-bar">{loading ? 'Loading…' : url}</div>
    </div>
  );
}
