import { useEffect, useRef, useState } from 'react';

interface Props {
  onComplete: () => void;
}

export function WelcomeVideo({ onComplete }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [showSkip, setShowSkip] = useState(false);
  const [videoError, setVideoError] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowSkip(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleEnded = () => {
    onComplete();
  };

  const handleSkip = () => {
    onComplete();
  };

  const handleError = () => {
    setVideoError(true);
    // Auto-complete after 2 seconds if video fails
    setTimeout(onComplete, 2000);
  };

  if (videoError) {
    return null;
  }

  return (
    <div className="welcome-video-overlay">
      <video
        ref={videoRef}
        src="/videos/welcome.mp4"
        className="welcome-video"
        autoPlay
        muted
        playsInline
        onEnded={handleEnded}
        onError={handleError}
      />
      {showSkip && (
        <button className="welcome-skip-btn" onClick={handleSkip} title="Skip intro">
          Skip ⟫
        </button>
      )}
    </div>
  );
}
