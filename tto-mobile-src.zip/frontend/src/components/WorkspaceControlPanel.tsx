import { useMemo, useState, useRef, useEffect } from 'react';
import type { Workspace } from '../workspace';
import type { UnifiedTerminal } from '../types';
import { isClosed, formatTokens, cleanModel } from '../lib/format';
import { TerminalManager } from '../terminal/TerminalManager';

export type ViewMode = 'focus' | 'split' | 'grid';

/** Live task/lifecycle status of a terminal pane. */
export type TermStatus = 'empty' | 'closed' | 'running' | 'stopped' | 'over' | 'asking';

/**
 * Derive the RIGHT-SIDE status for a terminal by asking the CLI what it is
 * ACTUALLY doing — not by guessing from shell activity:
 *
 *  1. The sidecar reads opencode's own session DB every ~1s and reports
 *     `opencode_status`:
 *       - 'working'   → the agent's turn is in flight (parts still streaming)
 *                       ⇒ RUNNING (or ASKING when it has paused in its TUI on
 *                       a visible permission/confirm question)
 *       - 'waiting'   → turn finished, CLI sits at the prompt; if the last
 *                       assistant text ends in '?' (and is recent) it is
 *                       ASKING with that question, otherwise STOPPED
 *       - 'off'       → no live opencode session; fall back to other signals
 *  2. App-tracked tasks (current_task) take precedence for OVER/STOPPED, and
 *     keep showing RUNNING while in flight even if opencode sits momentarily
 *     quiet between output bursts.
 *  3. `claude_running` (Claude Code): same contract via TUI + quiet + a
 *     visible question in the buffer (Claude stores sessions in its own
 *     JSONL, so the opencode DB does not apply).
 *  4. Quiet-TUI question detection: when a CLI pauses inside its full-screen
 *     TUI (permission prompts like "Allow access…?", "Do you want to
 *     proceed?") it stops writing output but leaves the question ON SCREEN.
 *     quiet gap (3–20s) + active context (task in flight / agent mid-turn /
 *     Claude running) + a question-shaped buffer ⇒ ASKING.
 *  5. Rear-guard fallbacks: recent terminal output ⇒ RUNNING; a full-screen
 *     TUI at rest with no task ⇒ STOPPED; otherwise live shell ⇒ STOPPED.
 */
function deriveTaskStatus(
  tty: string | null,
  entry: UnifiedTerminal | undefined,
  closed: boolean,
): TermStatus {
  if (!tty) return 'empty';
  if (closed) return 'closed';
  if (!entry) return 'stopped';

  const st = (entry.current_task?.status ?? '').toLowerCase();
  const paused = !!(entry as any).paused;
  const claude = !!entry.claude_running;
  const oc = entry.opencode_status;
  const ocState = oc?.state ?? 'off';
  const ocText = (oc?.last_text ?? '').trim();
  const ocRecent =
    oc != null && oc.last_update_ms > 0 && Date.now() - oc.last_update_ms < 3 * 60_000;
  const ocQuestion = ocState === 'waiting' && ocRecent && ocText.endsWith('?');

  const tui = TerminalManager.isTui(tty);
  const lastOut = TerminalManager.outputAt(tty);
  const hasRenderer = lastOut !== 0;
  const now = Date.now();
  // Output flowing within 6s ⇒ actively working.
  const recentOutput = hasRenderer && now - lastOut < 6000;
  // A quiet gap 3–20s after output = the CLI paused to ask/await input.
  const quietShort = hasRenderer && now - lastOut > 3000 && now - lastOut < 20000;
  // Question-shaped content currently on screen (permission/confirm prompts).
  const recentLines = hasRenderer ? TerminalManager.lastLines(tty, 3).join(' ') : '';
  const bufferAsks =
    /[?]\s*$/.test(recentLines) ||
    /\b(allow|access|permission|permit|proceed|continue|confirm|yes\/no)\b/i.test(recentLines);
  const taskInFlight = st.length > 0;
  // Quiet full-screen TUI + active context + visible question ⇒ asking.
  const askedQuietly =
    tui && quietShort && bufferAsks && (taskInFlight || ocState === 'working' || claude);

  // Task reached a terminal state → OVER / STOPPED (outranks everything: a
  // completed task may have just printed its final lines).
  if (
    st === 'done' ||
    st === 'completed' ||
    st === 'success' ||
    st === 'succeeded' ||
    st === 'finished'
  ) {
    return 'over';
  }
  if (
    st === 'cancelled' ||
    st === 'canceled' ||
    st === 'blocked' ||
    st === 'failed' ||
    st === 'error' ||
    st === 'stopped' ||
    paused
  ) {
    return 'stopped';
  }

  // App-tracked task in flight → RUNNING, or ASKING when the CLI paused on a
  // question. Never flickers to STOPPED between output bursts.
  if (taskInFlight) {
    return askedQuietly || ocQuestion ? 'asking' : 'running';
  }

  // No app task. Ask opencode what it is doing right now.
  if (ocState === 'working') {
    return askedQuietly ? 'asking' : 'running';
  }
  if (ocState === 'waiting') {
    // The DB is authoritative: the turn FINISHED and the CLI is at its
    // prompt — that is ASKING (recent '?' question) or STOPPED. Ignore
    // renderer recency here: the final response/prompt render just touched
    // the buffer, and a TUI that redraws its status line would otherwise
    // keep the row stuck on RUNNING forever at an idle prompt.
    if (ocQuestion) return 'asking';
    return 'stopped';
  }

  // Claude Code (no opencode DB): working = output flowing; a quiet TUI with
  // a permission/question prompt on screen = asking.
  if (claude) {
    if (recentOutput) return 'running';
    if (askedQuietly) return 'asking';
    return 'stopped';
  }

  // opencode IS running on this tty but its own session reports 'off'
  // (DB first-tick / re-scan latency). Never fall through to renderer
  // recency here: the opencode TUI redraws its screen periodically, which
  // would resurrect a FINISHED terminal back to RUNNING. For an agent CLI,
  // status comes ONLY from the per-tty signals above — else it is stopped.
  if (entry.opencode_running) return 'stopped';

  // No live CLI signal → renderer + TUI rear guard.
  if (recentOutput) return 'running';
  if (tui) return now - lastOut > 8000 ? 'stopped' : 'running';

  return 'stopped';
}

/** Short label + CSS class suffix for a derived status. */
export function statusLabel(s: TermStatus): { text: string; cls: string } {
  switch (s) {
    case 'running':
      return { text: 'RUNNING', cls: 'running' };
    case 'asking':
      return { text: 'ASKING', cls: 'asking' };
    case 'stopped':
      return { text: 'STOPPED', cls: 'stopped' };
    case 'over':
      return { text: 'OVER', cls: 'over' };
    case 'closed':
      return { text: 'EXITED', cls: 'closed' };
    default:
      return { text: 'EMPTY', cls: 'empty' };
  }
}

interface Props {
  workspaces: Workspace[];
  activeId: string;
  terminals: Record<string, UnifiedTerminal>;
  focusedTerminal: string | null;
  viewMode: ViewMode;
  onSelectTerminal: (sessionId: string) => void;
  onSetViewMode: (mode: ViewMode) => void;
  onNewTerminal: () => void;
  onRenameTerminal: (sessionId: string, name: string) => void;
  /** Switch the active workspace (wires up the workspace dropdown). */
  onSelectWorkspace?: (id: string) => void;
  /** Token usage summary from the sidecar. */
  tokenUsage?: { totals: { used: number; available: number; left: number } } | null;
}

/**
 * Right-side workspace control panel (~35-40% width).
 *
 * Sections:
 *   1. Workspace selector dropdown
 *   2. View mode toggle (Focus / Split / Grid)
 *   3. Terminal list (compact rows, NOT cards)
 *   4. Selected terminal details
 *   5. Task summary
 *   6. Token usage summary
 */
export function WorkspaceControlPanel({
  workspaces,
  activeId,
  terminals,
  focusedTerminal,
  viewMode,
  onSelectTerminal,
  onSetViewMode,
  onNewTerminal,
  onRenameTerminal,
  onSelectWorkspace,
  tokenUsage,
}: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const editRef = useRef<HTMLInputElement>(null);

  // Poll the live renderer signals (TUI state, output activity) every 2s so the
  // terminal rows' Running/Asking/Stopped/Over badges stay current.
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setTick((t) => t + 1), 500);
    return () => window.clearInterval(id);
  }, []);
  // Optimistic local renames — applied immediately, overridden when sidecar broadcasts
  const [renamedMap, setRenamedMap] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editingId && editRef.current) editRef.current.focus();
  }, [editingId]);
  const activeWs = workspaces.find((w) => w.id === activeId) || workspaces[0];

  // `terminals` (unifiedTerminals) is keyed by OS tty, but a WorkspacePane's
  // `tty` field actually holds the Rust session id in Tauri. Index by session_id
  // so we can resolve a pane to its entry in native mode too — without this the
  // rows showed no name/agent/model and renames never appeared.
  const bySessionId = useMemo(() => {
    const m: Record<string, UnifiedTerminal> = {};
    for (const u of Object.values(terminals)) {
      if (u.session_id) m[u.session_id] = u;
    }
    return m;
  }, [terminals]);

  // Resolve terminals for the active workspace
  const resolvedTerminals = useMemo(() => {
    if (!activeWs) return [];
    return activeWs.panes.map((pane, i) => {
      const tty = pane.tty;
      const entry = tty ? terminals[tty] || bySessionId[tty] : undefined;
      const closed = entry ? isClosed(entry) : false;
      const hasTask =
        entry?.current_task &&
        !['done', 'cancelled', 'blocked'].includes(entry.current_task.status);
      const agent = entry?.agent || '';
      const model = entry?.model || '';
      const shortModel = model ? cleanModel(model) : '';
      const sessionTitle =
        renamedMap[tty || ''] ||
        entry?.session_name ||
        entry?.pane_title ||
        entry?.tokens?.session_title ||
        '';
      // Live lifecycle + task state → the right-side status badge.
      const status = deriveTaskStatus(tty, entry, closed);

      return {
        num: i + 1,
        paneId: pane.id,
        sessionId: tty,
        label: sessionTitle || tty || `Terminal ${i + 1}`,
        agent,
        model: shortModel,
        status,
        hasTask,
        entry,
      };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeWs, terminals, bySessionId, renamedMap, tick]);

  const selectedTerminal = focusedTerminal
    ? resolvedTerminals.find((t) => t.sessionId === focusedTerminal)
    : resolvedTerminals.find((t) => t.status === 'running') ||
      resolvedTerminals.find((t) => t.status === 'asking') ||
      resolvedTerminals[0];

  const liveCount = resolvedTerminals.filter(
    (t) => t.status !== 'empty' && t.status !== 'closed',
  ).length;
  // "In Progress" for the Task Summary = terminals with an in-flight task
  // (not merely a live shell — every live terminal now shows 'running').
  const activeCount = resolvedTerminals.filter((t) => t.hasTask).length;

  // Task stats — scoped to the active workspace's terminals only
  const taskStats = useMemo(() => {
    let completed = 0;
    let inProgress = 0;
    let failed = 0;
    // Get only terminals belonging to the active workspace
    const wsTerminals =
      workspaces
        .find((w) => w.id === activeId)
        ?.panes?.map((p) => p.tty)
        .filter(Boolean) || [];
    for (const t of Object.values(terminals)) {
      // Skip if this terminal doesn't belong to the active workspace
      if ((t as any).tty && !wsTerminals.includes((t as any).tty)) continue;
      if (t.history) {
        for (const h of t.history) {
          if (h.status === 'done') completed++;
          else if (h.status === 'blocked') failed++;
        }
      }
      if (
        t.current_task &&
        (t.current_task.status === 'running' || t.current_task.status === 'pending')
      ) {
        inProgress++;
      }
    }
    return { completed, inProgress, failed };
  }, [terminals, activeId, workspaces]);

  return (
    <div className="wcp">
      {/* ── Workspace selector ── */}
      <div className="wcp-section">
        <div className="wcp-section-title">Workspace</div>
        <div className="wcp-ws-row">
          <select
            className="wcp-ws-select"
            value={activeId}
            onChange={(e) => onSelectWorkspace?.(e.target.value)}
            title="Active workspace"
          >
            {workspaces.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
          <span className="wcp-ws-dot" style={{ background: activeWs?.color || '#666' }} />
        </div>
        {activeWs?.projectPath && (
          <div className="wcp-ws-path" title={activeWs.projectPath}>
            📁 {activeWs.projectPath}
          </div>
        )}
      </div>

      {/* ── View mode toggle ── */}
      <div className="wcp-section">
        <div className="wcp-section-title">View Mode</div>
        <div className="wcp-viewmodes" role="radiogroup" aria-label="Terminal layout mode">
          {(['focus', 'split', 'grid'] as ViewMode[]).map((mode) => (
            <button
              key={mode}
              role="radio"
              aria-checked={viewMode === mode}
              className={`wcp-viewmode ${viewMode === mode ? 'active' : ''}`}
              onClick={() => onSetViewMode(mode)}
              title={`${
                mode === 'focus'
                  ? 'One terminal fills the left panel'
                  : mode === 'split'
                    ? '2-4 terminals in resizable panes'
                    : '5-16 terminals displayed compactly'
              }`}
            >
              {mode === 'focus' ? '⊞' : mode === 'split' ? '⊟' : '▦'}{' '}
              {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* ── Terminal list ── */}
      <div className="wcp-section wcp-terminals-section">
        <div className="wcp-section-title">
          <span>Terminals</span>
          <span className="wcp-section-count">
            {liveCount} / {resolvedTerminals.length}
          </span>
        </div>
        <div className="wcp-terminal-list">
          {resolvedTerminals.map((t) => {
            const isFocused = t.sessionId === focusedTerminal;
            const isEditing = editingId === t.sessionId;
            return (
              <div
                key={t.paneId}
                className={`wcp-terminal-row ${isFocused ? 'focused' : ''} ${t.status}`}
              >
                <span className="wcp-terminal-num">{String(t.num).padStart(2, '0')}</span>
                <span className={`wcp-terminal-dot ${t.status}`} />
                {isEditing ? (
                  <input
                    ref={editRef}
                    className="wcp-terminal-rename-input"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && editName.trim() && t.sessionId) {
                        onRenameTerminal(t.sessionId, editName.trim());
                        setRenamedMap((prev) => ({ ...prev, [t.sessionId!]: editName.trim() }));
                        setEditingId(null);
                      }
                      if (e.key === 'Escape') setEditingId(null);
                    }}
                    onBlur={() => {
                      if (editName.trim() && t.sessionId) {
                        onRenameTerminal(t.sessionId, editName.trim());
                        setRenamedMap((prev) => ({ ...prev, [t.sessionId!]: editName.trim() }));
                      }
                      setEditingId(null);
                    }}
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <span
                    className="wcp-terminal-info"
                    onClick={() => t.sessionId && onSelectTerminal(t.sessionId)}
                    style={{ cursor: t.sessionId ? 'pointer' : 'default', flex: 1, minWidth: 0 }}
                  >
                    <span className="wcp-terminal-name">{t.label}</span>
                    {t.agent && <span className="wcp-terminal-agent">{t.agent}</span>}
                  </span>
                )}
                {t.model && <span className="wcp-terminal-model">{t.model}</span>}
                {['running', 'asking', 'stopped', 'over', 'closed'].includes(t.status) && (
                  <span
                    className={`wcp-terminal-status ${statusLabel(t.status).cls}`}
                    title={
                      t.status === 'asking'
                        ? 'CLI is waiting for your input (question prompt)'
                        : t.status === 'running'
                          ? 'Agent task in progress'
                          : t.status === 'stopped'
                            ? 'Terminal running — no task in flight'
                            : t.status === 'over'
                              ? 'Task completed'
                              : 'Process exited'
                    }
                  >
                    {statusLabel(t.status).text}
                  </span>
                )}
                {t.sessionId && !isEditing && (
                  <button
                    className="wcp-terminal-rename-btn"
                    title="Rename terminal"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingId(t.sessionId);
                      setEditName(t.label);
                    }}
                  >
                    ✎
                  </button>
                )}
              </div>
            );
          })}
        </div>
        <button className="wcp-new-terminal" onClick={onNewTerminal}>
          + New Terminal
        </button>
      </div>

      {/* ── Selected terminal details ── */}
      {selectedTerminal?.sessionId && selectedTerminal.entry && (
        <div className="wcp-section">
          <div className="wcp-section-title">Terminal Details</div>
          <div className="wcp-details">
            <div className="wcp-detail-row">
              <span className="wcp-detail-label">Terminal</span>
              <span className="wcp-detail-value mono">{selectedTerminal.sessionId}</span>
            </div>
            <div className="wcp-detail-row">
              <span className="wcp-detail-label">Status</span>
              <span className={`wcp-detail-value ${statusLabel(selectedTerminal.status).cls}`}>
                {selectedTerminal.status === 'running'
                  ? '● Running — task in progress'
                  : selectedTerminal.status === 'asking'
                    ? '● Asking — CLI waiting for input'
                    : selectedTerminal.status === 'stopped'
                      ? '○ Stopped — no task in flight'
                      : selectedTerminal.status === 'over'
                        ? '✓ Over — task completed'
                        : selectedTerminal.status === 'closed'
                          ? '✕ Exited — process closed'
                          : '○ Empty'}
              </span>
            </div>
            {selectedTerminal.status === 'asking' && (
              <div className="wcp-detail-row">
                <span className="wcp-detail-label">Question</span>
                <span className="wcp-detail-value question">
                  {(() => {
                    // Exact question from the sidecar (opencode DB) when it
                    // reads as a question; otherwise the on-screen buffer
                    // (permission/confirm prompts render in the TUI).
                    const lines = TerminalManager.lastLines(selectedTerminal.sessionId!, 4);
                    const buffer = lines.join(' ');
                    const ocText = (
                      selectedTerminal.entry?.opencode_status?.last_text ?? ''
                    ).trim();
                    const raw = /[?]\s*$/.test(buffer)
                      ? buffer
                      : ocText.endsWith('?')
                        ? ocText
                        : buffer;
                    return raw && raw.trim()
                      ? raw.trim().slice(0, 300)
                      : 'CLI is waiting for your input…';
                  })()}
                </span>
              </div>
            )}
            {selectedTerminal.agent && (
              <div className="wcp-detail-row">
                <span className="wcp-detail-label">Agent</span>
                <span className="wcp-detail-value">{selectedTerminal.agent}</span>
              </div>
            )}
            {selectedTerminal.entry.cwd && (
              <div className="wcp-detail-row">
                <span className="wcp-detail-label">Directory</span>
                <span className="wcp-detail-value mono" title={selectedTerminal.entry.cwd}>
                  {selectedTerminal.entry.cwd}
                </span>
              </div>
            )}
            {selectedTerminal.entry.current_task &&
              !['done', 'cancelled', 'blocked'].includes(
                selectedTerminal.entry.current_task.status,
              ) && (
                <div className="wcp-detail-row">
                  <span className="wcp-detail-label">Current Task</span>
                  <span className="wcp-detail-value task">
                    {selectedTerminal.entry.current_task.description}
                  </span>
                </div>
              )}
          </div>
        </div>
      )}

      {/* ── Task summary ── */}
      <div className="wcp-section">
        <div className="wcp-section-title">Task Summary</div>
        <div className="wcp-task-stats">
          <div className="wcp-task-stat">
            <span className="wcp-task-stat-num">{activeCount}</span>
            <span className="wcp-task-stat-label">In Progress</span>
          </div>
          <div className="wcp-task-stat">
            <span className="wcp-task-stat-num done">{taskStats.completed}</span>
            <span className="wcp-task-stat-label">Completed</span>
          </div>
          {taskStats.failed > 0 && (
            <div className="wcp-task-stat">
              <span className="wcp-task-stat-num failed">{taskStats.failed}</span>
              <span className="wcp-task-stat-label">Failed</span>
            </div>
          )}
        </div>
      </div>

      {/* ── Token usage ── */}
      {tokenUsage && (
        <div className="wcp-section wcp-token-card">
          {/* Header with model badge */}
          <div className="wcp-token-header">
            <span className="wcp-token-title">Token Usage</span>
            {(() => {
              // Try to find model from terminal tokens
              const entry = Object.values(terminals).find((u) => u.tokens?.cost != null);
              const model = entry?.tokens?.model || '';
              return model ? <span className="wcp-token-model">{model}</span> : null;
            })()}
          </div>

          {/* Progress bar with % on bar */}
          <div className="wcp-token-progress">
            <div className="wcp-token-bar-track">
              <div
                className="wcp-token-bar-fill"
                style={{
                  width: `${
                    tokenUsage.totals.available > 0
                      ? Math.min(100, (tokenUsage.totals.used / tokenUsage.totals.available) * 100)
                      : 0
                  }%`,
                }}
              />
              <span className="wcp-token-pct">
                {tokenUsage.totals.available > 0
                  ? `${Math.min(100, Math.round((tokenUsage.totals.used / tokenUsage.totals.available) * 100))}%`
                  : '—'}
              </span>
            </div>
            <div className="wcp-token-main">
              <span>
                {formatTokens(tokenUsage.totals.used)} / {formatTokens(tokenUsage.totals.available)}
              </span>
            </div>
          </div>

          {/* Detail rows */}
          <div className="wcp-token-details">
            <div className="wcp-token-row">
              <span className="wcp-token-label">Used</span>
              <span className="wcp-token-value">{formatTokens(tokenUsage.totals.used)}</span>
            </div>
            <div className="wcp-token-row">
              <span className="wcp-token-label">Available</span>
              <span className="wcp-token-value">{formatTokens(tokenUsage.totals.available)}</span>
            </div>
            <div className="wcp-token-row">
              <span className="wcp-token-label">Left</span>
              <span className="wcp-token-value">{formatTokens(tokenUsage.totals.left)}</span>
            </div>
            {(() => {
              // Cost estimate from terminal tokens if available
              const entry = Object.values(terminals).find((u) => u.tokens?.cost != null);
              const cost = entry?.tokens?.cost;
              if (cost != null && cost > 0) {
                return (
                  <div className="wcp-token-row wcp-token-cost">
                    <span className="wcp-token-label">Est. cost</span>
                    <span className="wcp-token-value">${cost.toFixed(4)}</span>
                  </div>
                );
              }
              return null;
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
