/**
 * InspectorOverlay — handles hover detection, element selection, and renders
 * visual markers for saved annotations.
 *
 * Renders nothing when `isOpen` is false.  Attaches global mousemove/mousedown
 * listeners when active; removes them on unmount.
 */

import { useEffect, useRef, useCallback, useState } from 'react';
import type { InspectedElement, Annotation } from '../types';
import { getStore, inspectorActions } from '../lib/inspector/store';
import { findComponentName, getElementLabel } from '../lib/inspector/react-finder';
import { resolveSourceFile } from '../lib/inspector/source-map';

// ── Helpers ───────────────────────────────────────────────────────────────────

let nextId = 0;
function uid(): string {
  return `insp-${Date.now()}-${++nextId}`;
}

function buildSelector(el: HTMLElement): string {
  const parts: string[] = [];
  let current: HTMLElement | null = el;
  while (current && parts.length < 6) {
    let segment = current.tagName.toLowerCase();
    if (current.id) {
      segment += `#${current.id}`;
    } else if (current.className && typeof current.className === 'string') {
      const cls = current.className.trim().split(/\s+/)[0];
      if (cls && !cls.startsWith('css-') && !cls.startsWith('sc-')) {
        segment += `.${cls}`;
      }
    }
    parts.unshift(segment);
    current = current.parentElement;
  }
  return parts.join(' > ');
}

function captureElement(el: HTMLElement): InspectedElement {
  const rect = el.getBoundingClientRect();
  const computed = window.getComputedStyle(el);
  const styleRecord: Record<string, string> = {};
  const keys = [
    'display',
    'flexDirection',
    'justifyContent',
    'alignItems',
    'width',
    'height',
    'minWidth',
    'minHeight',
    'maxWidth',
    'maxHeight',
    'padding',
    'paddingTop',
    'paddingRight',
    'paddingBottom',
    'paddingLeft',
    'margin',
    'marginTop',
    'marginRight',
    'marginBottom',
    'marginLeft',
    'borderRadius',
    'border',
    'backgroundColor',
    'color',
    'fontSize',
    'fontWeight',
    'lineHeight',
    'textAlign',
    'gap',
    'rowGap',
    'columnGap',
    'overflow',
    'position',
    'zIndex',
    'opacity',
    'cursor',
    'boxShadow',
  ];
  for (const k of keys) {
    const v = computed.getPropertyValue(k);
    if (v) styleRecord[k] = v;
  }

  const attrRecord: Record<string, string> = {};
  for (const attr of el.attributes) {
    if (
      attr.name.startsWith('data-') ||
      attr.name.startsWith('aria-') ||
      ['id', 'className', 'role', 'tabIndex', 'title', 'disabled', 'checked'].includes(attr.name)
    ) {
      attrRecord[attr.name] = attr.value;
    }
  }

  const rawText = el.textContent || '';
  const textContent = rawText.replace(/\s+/g, ' ').trim().slice(0, 200);

  const componentName = findComponentName(el) || undefined;
  const source = resolveSourceFile(el);

  const selector = buildSelector(el);
  const parentEl = el.parentElement;
  const parentSelector = parentEl ? buildSelector(parentEl) : undefined;

  return {
    id: uid(),
    domTag: el.tagName.toLowerCase(),
    domId: el.id || undefined,
    className: typeof el.className === 'string' ? el.className : '',
    role: el.getAttribute('role') || undefined,
    ariaLabel: el.getAttribute('aria-label') || undefined,
    textContent,
    selector,
    parentSelector,
    boundingBox: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
    computedStyles: styleRecord,
    attributes: attrRecord,
    componentName,
    sourceFile: source.sourceFile,
    sourceLine: source.sourceLine,
    sourceColumn: source.sourceColumn,
    sourceExact: source.exact,
    detectedAt: Date.now(),
  };
}

// ── Component ─────────────────────────────────────────────────────────────────

interface Props {
  isOpen: boolean;
  annotations: Annotation[];
}

export function InspectorOverlay({ isOpen, annotations }: Props) {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const [hoverLabel, setHoverLabel] = useState<string | null>(null);
  const hoverRaf = useRef<number>(0);
  const lastHoveredEl = useRef<HTMLElement | null>(null);
  const [markerPositions, setMarkerPositions] = useState<Map<string, { x: number; y: number }>>(
    new Map(),
  );

  const syncMarkerPositions = useCallback(() => {
    const posMap = new Map<string, { x: number; y: number }>();
    for (const ann of annotations) {
      const el = document.querySelector(
        `[data-inspect-id="${ann.element.id}"]`,
      ) as HTMLElement | null;
      if (el) {
        const r = el.getBoundingClientRect();
        posMap.set(ann.id, { x: r.right - 8, y: r.top + r.height / 2 });
      }
    }
    setMarkerPositions(posMap);
  }, [annotations]);

  useEffect(() => {
    if (!isOpen) return;
    inspectorActions.setMode('hover');

    const onMouseMove = (e: MouseEvent) => {
      cancelAnimationFrame(hoverRaf.current);
      hoverRaf.current = requestAnimationFrame(() => {
        const target =
          (e.target as HTMLElement) ||
          document
            .elementsFromPoint(e.clientX, e.clientY)
            .find(
              (el): el is HTMLElement =>
                el instanceof HTMLElement &&
                el !== document.body &&
                el !== document.documentElement,
            );
        if (!target) {
          lastHoveredEl.current?.removeAttribute('data-inspect-hover');
          lastHoveredEl.current = null;
          setHoverLabel(null);
          inspectorActions.setHovered(null);
          return;
        }
        if (target.closest('[data-inspector-ui]')) {
          lastHoveredEl.current?.removeAttribute('data-inspect-hover');
          lastHoveredEl.current = null;
          setHoverLabel(null);
          return;
        }

        if (lastHoveredEl.current !== target) {
          lastHoveredEl.current?.removeAttribute('data-inspect-hover');
          target.setAttribute('data-inspect-hover', '');
          lastHoveredEl.current = target;
        }

        const label = getElementLabel(target);
        setHoverLabel(label);
        inspectorActions.setHovered(captureElement(target));
      });
    };

    const onMouseDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target || target.closest('[data-inspector-ui]')) return;
      const el = document
        .elementsFromPoint(e.clientX, e.clientY)
        .find(
          (node): node is HTMLElement =>
            node instanceof HTMLElement &&
            node !== document.body &&
            node !== document.documentElement,
        );
      if (!el) return;
      const captured = captureElement(el);
      inspectorActions.selectElement(captured);
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        const store = getStore();
        if (store.selectedEl) {
          inspectorActions.clearSelection();
        } else if (store.mode === 'hover') {
          inspectorActions.setMode('normal');
        }
      }
    };

    const observer = new MutationObserver(syncMarkerPositions);
    observer.observe(document.body, { attributes: true, childList: true, subtree: true });
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('keydown', onKey);
    window.addEventListener('scroll', syncMarkerPositions, { passive: true });
    window.addEventListener('resize', syncMarkerPositions);

    return () => {
      cancelAnimationFrame(hoverRaf.current);
      lastHoveredEl.current?.removeAttribute('data-inspect-hover');
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', syncMarkerPositions);
      window.removeEventListener('resize', syncMarkerPositions);
      observer.disconnect();
    };
  }, [isOpen, syncMarkerPositions]);

  // Keep tooltip near cursor
  useEffect(() => {
    if (!hoverLabel || !isOpen) return;
    const onCur = (e: MouseEvent) => setTooltipPos({ x: e.clientX, y: e.clientY });
    window.addEventListener('mousemove', onCur, { passive: true });
    return () => window.removeEventListener('mousemove', onCur);
  }, [hoverLabel, isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Hover tooltip */}
      {hoverLabel && (
        <div
          ref={tooltipRef}
          className="inspection-tooltip"
          data-inspector-ui
          style={{ left: tooltipPos.x, top: tooltipPos.y }}
        >
          {hoverLabel}
        </div>
      )}

      {/* Numbered markers for saved annotations */}
      {annotations.map((ann, i) => {
        const pos = markerPositions.get(ann.id);
        if (!pos) return null;
        return (
          <div
            key={ann.id}
            className="inspector-marker"
            data-inspector-ui
            data-inspect-id={ann.element.id}
            style={{ left: pos.x, top: pos.y, transform: 'translate(50%, -50%)' }}
            title={ann.userComment.slice(0, 60)}
          >
            {i + 1}
          </div>
        );
      })}
    </>
  );
}

export default InspectorOverlay;
