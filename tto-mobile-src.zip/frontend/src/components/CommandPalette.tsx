import { useEffect, useMemo, useRef, useState } from 'react';
import type { FileEntry } from '../api/client';

interface Props {
  open: boolean;
  onClose: () => void;
  onSelectFile: (path: string, name: string) => void;
  onNewTerminal?: () => void;
  onNewWorkspace?: () => void;
  files?: FileEntry[];
}

interface FuzzyResult {
  path: string;
  name: string;
  is_dir: boolean;
  score: number;
}

/** Returns true when `query` matches `text` in a case-insensitive fuzzy way. */
function fuzzyMatch(query: string, text: string): number {
  if (!query) return 0;
  const q = query.toLowerCase();
  const t = text.toLowerCase();
  let qi = 0;
  let consecutive = 0;
  let bestRun = 0;
  for (let ti = 0; ti < t.length && qi < q.length; ti++) {
    if (t[ti] === q[qi]) {
      consecutive++;
      bestRun = Math.max(bestRun, consecutive);
      qi++;
    } else {
      consecutive = 0;
    }
  }
  if (qi < q.length) return -1; // didn't match
  // Score: higher is better — prefer longer consecutive runs and earlier matches
  return bestRun * 10 - t.lastIndexOf(q[q.length - 1]);
}

function getRecentFiles(): Array<{ path: string; name: string }> {
  try {
    const raw = localStorage.getItem('tto-command-palette-recent');
    if (!raw) return [];
    return JSON.parse(raw) as Array<{ path: string; name: string }>;
  } catch {
    return [];
  }
}

function saveRecentFiles(recent: Array<{ path: string; name: string }>): void {
  try {
    localStorage.setItem('tto-command-palette-recent', JSON.stringify(recent.slice(0, 20)));
  } catch {
    /* ignore */
  }
}

function addToRecent(path: string, name: string): void {
  const recent = getRecentFiles().filter((f) => f.path !== path);
  saveRecentFiles([{ path, name }, ...recent]);
}

export function CommandPalette({
  open,
  onClose,
  onSelectFile,
  onNewTerminal,
  onNewWorkspace,
  files = [],
}: Props) {
  const [query, setQuery] = useState('');
  const [index, setIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQuery('');
      setIndex(0);
      // Defer focus so the animation has time to start
      requestAnimationFrame(() => inputRef.current?.focus());
    } else {
      inputRef.current?.blur();
    }
  }, [open]);

  // Build result list: recents first, then matched files
  const results = useMemo<FuzzyResult[]>(() => {
    const recent = getRecentFiles();
    const queryLower = query.toLowerCase().trim();

    // If there's a query, filter files fuzzily
    let matched: FuzzyResult[] = [];
    if (queryLower) {
      matched = files
        .filter((f) => !f.is_dir)
        .map((f) => ({
          path: f.name,
          name: f.name,
          is_dir: false,
          score: fuzzyMatch(queryLower, f.name),
        }))
        .filter((r) => r.score >= 0)
        .sort((a, b) => b.score - a.score);
    }

    // Interleave: recents that match the query go first, then other recents,
    // then file matches.
    const recentsMatching = queryLower
      ? recent.filter((r) => fuzzyMatch(queryLower, r.path) >= 0)
      : recent;
    const recentsOther = queryLower ? recent.filter((r) => fuzzyMatch(queryLower, r.path) < 0) : [];

    const all = [
      ...recentsMatching.map((r) => ({ ...r, is_dir: false, score: 9999 })),
      ...recentsOther.map((r) => ({ ...r, is_dir: false, score: 9998 })),
      ...matched,
    ];

    // Deduplicate by path
    const seen = new Set<string>();
    return all.filter((r) => {
      if (seen.has(r.path)) return false;
      seen.add(r.path);
      return true;
    });
  }, [files, query]);

  // Reset index when results change
  useEffect(() => {
    setIndex(0);
  }, [query]);

  // Keyboard handler
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setIndex((i) => Math.min(i + 1, results.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const sel = results[index];
        if (sel) {
          addToRecent(sel.path, sel.name);
          onSelectFile(sel.path, sel.name);
          onClose();
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, results, index, onClose, onSelectFile]);

  // Close on click outside
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    // Delay to avoid closing immediately on our own buttons
    const t = setTimeout(() => window.addEventListener('mousedown', handler), 0);
    return () => {
      clearTimeout(t);
      window.removeEventListener('mousedown', handler);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="cmd-palette-overlay" ref={containerRef}>
      <div className="cmd-palette">
        <div className="cmd-palette-header">
          <input
            ref={inputRef}
            className="cmd-palette-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type to search files…"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
          />
          <kbd className="cmd-palette-esc">ESC</kbd>
        </div>

        <div className="cmd-palette-body">
          {/* Action rows */}
          {onNewTerminal && (
            <button
              className={`cmd-palette-row${index === 0 && !query ? ' active' : ''}`}
              onClick={() => {
                onNewTerminal();
                onClose();
              }}
              onMouseEnter={() => {
                if (!query) setIndex(0);
              }}
            >
              <span className="cmd-palette-action-icon">+</span>
              <span className="cmd-palette-action-label">New Terminal</span>
            </button>
          )}
          {onNewWorkspace && (
            <button
              className={`cmd-palette-row${index === (onNewTerminal ? 1 : 0) && !query ? ' active' : ''}`}
              onClick={() => {
                onNewWorkspace();
                onClose();
              }}
              onMouseEnter={() => {
                if (!query) setIndex(onNewTerminal ? 1 : 0);
              }}
            >
              <span className="cmd-palette-action-icon">⊞</span>
              <span className="cmd-palette-action-label">New Workspace</span>
            </button>
          )}

          {/* Divider if we have both actions and file results */}
          {(onNewTerminal || onNewWorkspace) && results.length > 0 && (
            <div className="cmd-palette-divider" />
          )}

          {/* File results */}
          {results.length === 0 && query && (
            <div className="cmd-palette-empty">No results for &ldquo;{query}&rdquo;</div>
          )}
          {results.length === 0 && !query && (
            <div className="cmd-palette-empty">Start typing to search files…</div>
          )}

          {results.map((r, i) => (
            <button
              key={r.path}
              className={`cmd-palette-row${index === i ? ' active' : ''}`}
              onClick={() => {
                addToRecent(r.path, r.name);
                onSelectFile(r.path, r.name);
                onClose();
              }}
              onMouseEnter={() => setIndex(i)}
            >
              <span className="cmd-palette-file-icon">{r.is_dir ? '▾' : '⤡'}</span>
              <span className="cmd-palette-file-name">{r.name}</span>
              <span className="cmd-palette-file-path">{r.path}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
