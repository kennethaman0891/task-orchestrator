import React, { useState, useEffect, useRef } from 'react';
import type { Workspace } from '../workspace';
import { TEMPLATES } from '../workspace';
import { FileBrowser } from './FileBrowser';
import { modifierLabel, baseName } from '../lib/format';

interface Props {
  workspaces: Workspace[];
  activeId: string;
  activeWorkspace?: Workspace;
  onSelectWorkspace: (id: string) => void;
  onRenameWorkspace: (id: string, name: string) => void;
  onSetProjectPath: (id: string, projectPath: string) => void;
  onCloseWorkspace: (id: string) => void;
  onNewWorkspace: () => void;
  onOpenFile: (path: string, name: string) => void;
  /** Drop a sidebar file onto a terminal */
  onDropFiles?: (paths: string[], sessionId?: string, kinds?: ('file' | 'folder')[]) => void;
}

/** Generate initials from workspace name (max 2 chars). */
function wsInitials(name: string): string {
  return name
    .split(/[\s_-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() || '')
    .join('');
}

export function Sidebar({
  workspaces,
  activeId,
  activeWorkspace,
  onSelectWorkspace,
  onRenameWorkspace,
  onSetProjectPath,
  onCloseWorkspace,
  onNewWorkspace,
  onOpenFile,
  onDropFiles,
}: Props) {
  const [filesOpen, setFilesOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [nameDraft, setNameDraft] = useState('');
  const [editingPathId, setEditingPathId] = useState<string | null>(null);
  const [pathDraft, setPathDraft] = useState('');
  // Track the last active workspace so we only auto-open the Files section when
  // the user SWITCHES to a workspace that has a project path (not on every
  // render, and not if the user intentionally collapsed it).
  const lastActiveIdRef = useRef<string | null>(null);
  useEffect(() => {
    if (lastActiveIdRef.current !== activeId) {
      lastActiveIdRef.current = activeId;
      if (activeWorkspace?.projectPath) setFilesOpen(true);
    }
  }, [activeId, activeWorkspace?.projectPath]);

  const startRename = (ws: Workspace) => {
    setEditingId(ws.id);
    setNameDraft(ws.name);
  };

  const commitRename = (id: string) => {
    const name = nameDraft.trim();
    if (name) onRenameWorkspace(id, name);
    setEditingId(null);
  };

  const startEditPath = (ws: Workspace) => {
    setEditingPathId(ws.id);
    setPathDraft(ws.projectPath || '');
  };

  const commitPath = (id: string) => {
    const p = pathDraft.trim();
    onSetProjectPath(id, p);
    setEditingPathId(null);
  };

  return (
    <aside className="sidebar" aria-label="Workspace sidebar">
      {/* ── Workspaces ── */}
      <div className="sidebar-section sidebar-workspaces">
        <div className="sidebar-title">
          <span>Workspaces</span>
          <span
            style={{
              fontSize: 9,
              fontWeight: 600,
              color: 'var(--accent)',
              background: 'rgba(74,158,255,0.1)',
              border: '1px solid rgba(74,158,255,0.2)',
              borderRadius: 8,
              padding: '1px 7px',
              letterSpacing: '0.5px',
            }}
          >
            {workspaces.length}
          </span>
        </div>
        <div className="sidebar-list">
          {workspaces.map((ws) => {
            const isActive = ws.id === activeId;
            const editing = editingId === ws.id;
            const templateInfo = TEMPLATES[ws.template];
            const paneCount = ws.panes?.length || 0;
            const liveCount = ws.panes?.filter((p) => p.tty).length || 0;
            return (
              <React.Fragment key={ws.id}>
                <div
                  className={`sidebar-item ${isActive ? 'active' : ''}`}
                  onClick={() => !editing && onSelectWorkspace(ws.id)}
                  role="button"
                  tabIndex={0}
                  aria-current={isActive ? 'page' : undefined}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !editing) onSelectWorkspace(ws.id);
                    if (e.key === 'Escape' && editing) setEditingId(null);
                  }}
                >
                  {/* Workspace avatar / initials */}
                  <span
                    className="sidebar-ws-avatar"
                    style={{
                      width: 28,
                      height: 28,
                      borderRadius: 8,
                      flex: 'none',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: '0.5px',
                      color: isActive ? '#fff' : '#888',
                      background: isActive
                        ? `linear-gradient(135deg, ${ws.color || '#4a9eff'}88, ${ws.color || '#4a9eff'}33)`
                        : 'rgba(255,255,255,0.05)',
                      border: `1px solid ${isActive ? (ws.color || 'var(--accent)') + '44' : 'rgba(255,255,255,0.06)'}`,
                      boxShadow: isActive ? `0 2px 8px ${ws.color || 'var(--accent)'}22` : 'none',
                    }}
                  >
                    {wsInitials(ws.name)}
                  </span>

                  {editing ? (
                    <input
                      className="sidebar-ws-rename"
                      autoFocus
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      onBlur={() => commitRename(ws.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          commitRename(ws.id);
                        }
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <div className="sidebar-item-info">
                      <span
                        className="sidebar-ws-name"
                        title={`${ws.name} — ${templateInfo?.label ?? ws.template} template`}
                      >
                        {ws.name}
                      </span>
                      <span
                        className="sidebar-task"
                        style={{ display: 'flex', alignItems: 'center', gap: 4 }}
                      >
                        {templateInfo?.label || ws.template}
                        {liveCount > 0 && (
                          <span
                            style={{
                              fontSize: 9,
                              color: 'var(--green)',
                              fontWeight: 600,
                              display: 'flex',
                              alignItems: 'center',
                              gap: 3,
                            }}
                          >
                            <span className="sidebar-dot live" style={{ width: 5, height: 5 }} />
                            {liveCount}
                          </span>
                        )}
                        {paneCount > 0 && (
                          <span style={{ fontSize: 9, color: '#5a605a' }}>· {paneCount} panes</span>
                        )}
                      </span>
                    </div>
                  )}

                  <button
                    className="sidebar-item-action"
                    title="Rename workspace"
                    onClick={(e) => {
                      e.stopPropagation();
                      editing ? commitRename(ws.id) : startRename(ws);
                    }}
                  >
                    ✎
                  </button>
                  <button
                    className="sidebar-item-close"
                    title="Close workspace"
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseWorkspace(ws.id);
                    }}
                  >
                    ✕
                  </button>
                </div>
                {/* ── Project path row (active workspace only) ── */}
                {isActive && (
                  <div
                    className="sidebar-ws-path-row"
                    onClick={(e) => {
                      e.stopPropagation();
                      editingPathId !== ws.id && startEditPath(ws);
                    }}
                    title={ws.projectPath || 'Click to set project folder'}
                  >
                    {editingPathId === ws.id ? (
                      <input
                        className="sidebar-ws-path-input"
                        autoFocus
                        value={pathDraft}
                        placeholder="/path/to/project"
                        onChange={(e) => setPathDraft(e.target.value)}
                        onBlur={() => commitPath(ws.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            commitPath(ws.id);
                          }
                          if (e.key === 'Escape') setEditingPathId(null);
                        }}
                        onClick={(e) => e.stopPropagation()}
                      />
                    ) : (
                      <span className="sidebar-ws-path-text">
                        📁 {ws.projectPath ? baseName(ws.projectPath) : 'Set project path…'}
                        {ws.projectPath && (
                          <span className="sidebar-ws-path-full" title={ws.projectPath}>
                            {ws.projectPath}
                          </span>
                        )}
                      </span>
                    )}
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
        <button
          className="sidebar-ws-new"
          onClick={onNewWorkspace}
          title={`New workspace (${modifierLabel()}+T)`}
        >
          <span style={{ marginRight: 4 }}>+</span> New workspace
        </button>
      </div>

      {/* ── Files (collapsible) ── */}
      <div className="sidebar-section">
        <div
          className="sidebar-title sidebar-title-toggle"
          onClick={() => setFilesOpen((o) => !o)}
          role="button"
          tabIndex={0}
        >
          <span className={`sidebar-chevron ${filesOpen ? 'open' : ''}`}>▸</span>
          <span>Files</span>
          {activeWorkspace?.projectPath && (
            <span className="sidebar-ws-path" title={activeWorkspace.projectPath}>
              {baseName(activeWorkspace.projectPath)}
            </span>
          )}
        </div>
        {filesOpen && (
          <div className="sidebar-files-body">
            <FileBrowser
              key={`${activeId}-${activeWorkspace?.projectPath || 'root'}`}
              initialPath={activeWorkspace?.projectPath || ''}
              onOpenFile={onOpenFile}
              onDropFiles={onDropFiles}
            />
          </div>
        )}
      </div>
    </aside>
  );
}
