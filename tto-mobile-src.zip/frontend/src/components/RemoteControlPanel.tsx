import { useCallback, useEffect, useState } from 'react';
import {
  fetchRemoteStatus,
  remoteConnect,
  remoteRefresh,
  remoteTestConnection,
  type RemoteStatus,
} from '../api/client';

interface Props {
  onToast: (msg: string, error?: boolean) => void;
  onClose: () => void;
}

/** Small Remote Control section (Settings → Remote Control). Shows live status,
 *  notification preferences, last command and actions — never secrets. */
export function RemoteControlPanel({ onToast, onClose }: Props) {
  const [status, setStatus] = useState<RemoteStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [qr, setQr] = useState<string | null>(null);

  const refresh = useCallback(() => {
    fetchRemoteStatus()
      .then(setStatus)
      .catch(() =>
        setStatus(
          (s) =>
            s || {
              enabled: false,
              openwa_connected: false,
              whatsapp_session: '',
              paired: false,
              qr_available: false,
              last_command: '',
              last_activity: 0,
              last_error: '',
            },
        ),
      );
  }, []);

  useEffect(() => {
    refresh();
    const iv = window.setInterval(refresh, 10000);
    return () => clearInterval(iv);
  }, [refresh]);

  const test = async () => {
    setBusy(true);
    try {
      const r = await remoteTestConnection();
      onToast(r.message || (r.ok ? 'Connection OK' : 'Connection failed'), !r.ok);
      refresh();
    } catch (e) {
      onToast('Test failed: ' + (e as Error).message, true);
    } finally {
      setBusy(false);
    }
  };

  const showQr = async () => {
    setBusy(true);
    try {
      const r = await remoteConnect();
      setQr(r.qr || null);
      if (r.qr) {
        onToast(
          r.webhook
            ? 'WhatsApp session started — scan the QR with your phone'
            : 'Session started, but webhook registration failed',
          !r.webhook,
        );
      } else {
        onToast(r.error || 'No QR available yet — start the OpenWA session first', true);
      }
      refresh();
    } catch (e) {
      onToast('Connect failed: ' + (e as Error).message, true);
    } finally {
      setBusy(false);
    }
  };

  const cfg = status?.config;
  const notif = cfg?.notifications;
  const lastActivity = status?.last_activity
    ? Math.max(0, Math.round(Date.now() / 1000 - status.last_activity))
    : null;

  return (
    <div className="remote-panel">
      <div className="remote-panel-head">
        <span className="remote-panel-title">🛰️ Remote Control</span>
        <button className="remote-panel-close" onClick={onClose} title="Close">
          ✕
        </button>
      </div>

      <div className="remote-panel-body">
        <div className="remote-row">
          <span className="remote-label">Status</span>
          <span className={status?.enabled ? 'remote-dot on' : 'remote-dot off'}>
            {status?.enabled ? '🟢 Enabled' : '🔴 Disabled'}
          </span>
        </div>
        <div className="remote-row">
          <span className="remote-label">OpenWA</span>
          <span className={status?.openwa_connected ? 'remote-dot on' : 'remote-dot off'}>
            {status?.openwa_connected ? '🟢 Connected' : '🔴 Disconnected'}
          </span>
        </div>
        {status?.whatsapp_session && (
          <div className="remote-row">
            <span className="remote-label">WhatsApp session</span>
            <span className="remote-val">
              {status.whatsapp_session}{' '}
              {status.paired ? '· paired' : status.qr_available ? '· waiting for QR' : ''}
            </span>
          </div>
        )}
        <div className="remote-row">
          <span className="remote-label">Authorized senders</span>
          <span className="remote-val">
            {(cfg?.allowed_phone_numbers?.length || 0) + (cfg?.allowed_chat_ids?.length || 0)}
          </span>
        </div>

        {notif && (
          <div className="remote-row">
            <span className="remote-label">Notifications</span>
            <span className="remote-val remote-notif">
              {[
                notif.task_complete && '✓ Task completed',
                notif.task_failed && '✓ Task failed',
                notif.agent_waiting && '✓ Agent waiting',
                notif.terminal_crash && '✓ Terminal crash',
                notif.system_error && '✓ System error',
              ]
                .filter(Boolean)
                .join(' · ') || '—'}
            </span>
          </div>
        )}

        <div className="remote-row">
          <span className="remote-label">Last command</span>
          <span className="remote-val mono">{status?.last_command || '—'}</span>
        </div>
        <div className="remote-row">
          <span className="remote-label">Last activity</span>
          <span className="remote-val">
            {lastActivity === null
              ? '—'
              : lastActivity < 60
                ? `${lastActivity}s ago`
                : `${Math.round(lastActivity / 60)}m ago`}
          </span>
        </div>
        {status?.last_error && (
          <div className="remote-row">
            <span className="remote-label">Last error</span>
            <span className="remote-val remote-err">{status.last_error}</span>
          </div>
        )}

        {qr && <img className="remote-qr" src={qr} alt="WhatsApp QR" />}

        <div className="remote-actions">
          <button className="btn small" onClick={test} disabled={busy || !status?.enabled}>
            {busy ? '…' : 'Test Connection'}
          </button>
          <button
            className="btn small primary"
            onClick={showQr}
            disabled={busy || !status?.enabled}
            title="Start the WhatsApp session and show the pairing QR"
          >
            {status?.paired ? 'Reconnect WhatsApp' : 'Connect WhatsApp'}
          </button>
          <button
            className="btn small"
            onClick={() => {
              remoteRefresh()
                .then(setStatus)
                .catch(() => {});
            }}
            disabled={busy}
          >
            Refresh
          </button>
        </div>

        {!status?.enabled && (
          <div className="remote-hint">
            Remote control is disabled. Set <span className="mono">TTO_REMOTE_ENABLED=true</span> (+
            OpenWA + allowlist + webhook secret) in <span className="mono">~/.env</span> or the
            sidecar environment, then restart. See <span className="mono">.env.example</span> and{' '}
            <span className="mono">docs/remote-control.md</span>.
          </div>
        )}
      </div>
    </div>
  );
}
