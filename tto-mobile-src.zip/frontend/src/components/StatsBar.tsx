export interface Stats {
  live: number;
  closed: number;
  active: number;
  done: number;
  agents: number;
}

/** Small stat text boxes — compact label/value chips rather than large tiles.
 *  Each box: muted uppercase label next to the value, tight padding. */
export function StatsBar({ stats, leading }: { stats: Stats; leading?: React.ReactNode }) {
  const items = [
    { num: stats.live, label: 'Live' },
    { num: stats.closed, label: 'Closed' },
    { num: stats.active, label: 'Active' },
    { num: stats.done, label: 'Done' },
    { num: stats.agents, label: 'Agents' },
  ];
  return (
    <div className="stats">
      {leading}
      {items.map((it) => (
        <div className="stat" key={it.label}>
          <span className="stat-num">{it.num}</span>
          <span className="stat-label">{it.label}</span>
        </div>
      ))}
    </div>
  );
}

/** Slim workspace status bar — one line, never grows with terminal count.
 *  The + create-terminal control lives in the toolbar (always visible). */
export function StatsBarCompact({ stats }: { stats: Stats }) {
  return (
    <div className="stats-compact" role="status">
      <span className="stats-compact-item">
        <b>{stats.live}</b> LIVE
      </span>
      <span className="stats-compact-sep">·</span>
      <span className="stats-compact-item">
        <b>{stats.active}</b> ACTIVE
      </span>
      <span className="stats-compact-sep">·</span>
      <span className="stats-compact-item">
        <b>{stats.agents}</b> AGENTS
      </span>
    </div>
  );
}
