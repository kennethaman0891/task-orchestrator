//! Tauri IPC: terminal commands + streaming channels (spec §36).
//!
//! Terminal DATA flows through binary channels (Vec<u8>) — never through
//! React state. UI metadata flows through cheap command invocations.
//! All arguments are validated (id lookup, dimension clamps) before touching
//! the PTY (spec §37).

use std::sync::Arc;

use tauri::ipc::Channel;
use tauri::State;

use crate::terminal::session::{SessionDiag, SessionMeta};
use crate::AppState;

#[tauri::command]
pub async fn terminal_create(
    state: State<'_, Arc<AppState>>,
    cwd: Option<String>,
    workspace_id: Option<String>,
    cols: Option<u16>,
    rows: Option<u16>,
) -> Result<SessionMeta, String> {
    eprintln!("[IPC] terminal_create cwd={:?} ws_id={:?} cols={} rows={}", cwd, workspace_id, cols.unwrap_or(120), rows.unwrap_or(30));
    // Async command: runs on the Tauri worker runtime, NOT the main (UI) thread.
    // This keeps PTY process spawn + the `ps` tty lookup (pty::tty_for_pid)
    // from blocking the webview and causing "Not Responding" freezes on create.
    let result = state.manager.create(
        cwd,
        workspace_id.unwrap_or_default(),
        cols.unwrap_or(120),
        rows.unwrap_or(30),
    );
    eprintln!("[IPC] terminal_create result: {:?}", result.as_ref().map(|m| &m.id).unwrap_or(&"ERROR".to_string()));
    result
}

#[tauri::command]
pub async fn terminal_attach(
    state: State<'_, Arc<AppState>>,
    id: String,
    on_output: Channel<Vec<u8>>,
    on_exit: Channel<()>,
) -> Result<(), String> {
    eprintln!("[IPC] terminal_attach id={}", id);
    let r = state.manager.attach(&id, on_output, on_exit);
    eprintln!("[IPC] terminal_attach id={} -> {:?}", id, r.as_ref().err());
    r
}

#[tauri::command]
pub async fn terminal_detach(state: State<'_, Arc<AppState>>, id: String) -> Result<(), String> {
    state.manager.detach(&id)
}

/// Return the full persistent scrollback for a session (FIX: full-history
/// replay). The frontend calls this after (re)creating a renderer so the
/// terminal shows the ENTIRE output history instead of only the newest chunks.
#[tauri::command]
pub async fn terminal_get_scrollback(
    state: State<'_, Arc<AppState>>,
    id: String,
) -> Result<Vec<u8>, String> {
    state.manager.get_scrollback(&id)
}

/// Space view: secondary read-only mirror channel (primary renderer untouched).
#[tauri::command]
pub async fn terminal_subscribe(
    state: State<'_, Arc<AppState>>,
    id: String,
    sub_id: u64,
    on_output: Channel<Vec<u8>>,
) -> Result<(), String> {
    state.manager.subscribe(&id, sub_id, on_output)
}

/// Remove a Space view mirror subscriber (idempotent).
#[tauri::command]
pub async fn terminal_unsubscribe(
    state: State<'_, Arc<AppState>>,
    id: String,
    sub_id: u64,
) -> Result<(), String> {
    state.manager.unsubscribe(&id, sub_id)
}

#[tauri::command]
pub async fn terminal_write(
    state: State<'_, Arc<AppState>>,
    id: String,
    data: Vec<u8>,
) -> Result<(), String> {
    // Async: PTY write_all+flush no longer runs on the main thread, so typing
    // into a busy/backpressured terminal can't freeze the webview.
    state.manager.write(&id, &data)
}

#[tauri::command]
pub async fn terminal_send_command(
    state: State<'_, Arc<AppState>>,
    id: String,
    command: String,
) -> Result<(), String> {
    state.manager.send_command(&id, &command)
}

#[tauri::command]
pub async fn terminal_resize(
    state: State<'_, Arc<AppState>>,
    id: String,
    cols: u16,
    rows: u16,
) -> Result<(), String> {
    state.manager.resize(&id, cols, rows)
}

#[tauri::command]
pub async fn terminal_close(state: State<'_, Arc<AppState>>, id: String) -> Result<(), String> {
    state.manager.close(&id)
}

#[tauri::command]
pub async fn terminal_restart(state: State<'_, Arc<AppState>>, id: String) -> Result<(), String> {
    // Async: shell respawn + `ps` tty lookup run off the main thread.
    state.manager.restart(&id)
}

#[tauri::command]
pub async fn terminal_list(state: State<'_, Arc<AppState>>) -> Result<Vec<SessionMeta>, String> {
    Ok(state.manager.list())
}

#[tauri::command]
pub async fn terminal_set_title(
    state: State<'_, Arc<AppState>>,
    id: String,
    title: String,
) -> Result<(), String> {
    state.manager.set_title(&id, &title);
    Ok(())
}

#[tauri::command]
pub async fn terminal_set_tui(
    state: State<'_, Arc<AppState>>,
    id: String,
    active: bool,
) -> Result<(), String> {
    state.manager.set_tui(&id, active);
    Ok(())
}

#[tauri::command]
pub async fn terminal_set_focus(
    state: State<'_, Arc<AppState>>,
    id: String,
    focused: bool,
) -> Result<(), String> {
    state.manager.set_focus(&id, focused);
    Ok(())
}

#[tauri::command]
pub async fn terminal_set_visible(
    state: State<'_, Arc<AppState>>,
    id: String,
    visible: bool,
) -> Result<(), String> {
    state.manager.set_visible(&id, visible);
    Ok(())
}

/// Update the grid layout mode for a session (auto | grid | compact | large).
/// Stored in metadata so the scheduler and diagnostics know the presentation
/// context.
#[tauri::command]
pub async fn terminal_set_grid_mode(
    state: State<'_, Arc<AppState>>,
    id: String,
    mode: String,
) -> Result<(), String> {
    state.manager.set_grid_mode(&id, &mode);
    Ok(())
}

/// Batch-resize all sessions in a workspace to the given dimensions.
/// Called when the user switches grid layout modes so every terminal gets a
/// SIGWINCH at the new card size in one pass.
#[tauri::command]
pub async fn terminal_batch_resize(
    state: State<'_, Arc<AppState>>,
    workspace_id: String,
    cols: u16,
    rows: u16,
) -> Result<usize, String> {
    Ok(state.manager.batch_resize(&workspace_id, cols, rows))
}

#[tauri::command]
pub async fn terminal_drop_files(
    state: State<'_, Arc<AppState>>,
    id: String,
    paths: Vec<String>,
) -> Result<(), String> {
    // Shell-escape each path (handles spaces, quotes, glob chars) then type
    // them as if the user dragged them into a real terminal. Files are joined
    // with spaces and followed by \r so the shell accepts the input.
    let mut joined = String::new();
    for path in &paths {
        if !joined.is_empty() {
            joined.push(' ');
        }
        // Shell-escape: wrap in single quotes, escaping any embedded single quotes
        let escaped = path.replace('\'', "'\\''");
        joined.push_str(&format!("'{}'", escaped));
    }
    // Insert shell-quoted paths without trailing newline so the user can edit/append args before pressing Enter.
    state.manager.write(&id, joined.as_bytes())
}

#[tauri::command]
pub async fn terminal_diagnostics(state: State<'_, Arc<AppState>>) -> Result<Vec<SessionDiag>, String> {
    Ok(state.manager.diagnostics())
}

// --- Workspace index (session↔workspace association, spec §22/§29) ---

#[tauri::command]
pub async fn workspace_index_set(
    state: State<'_, Arc<AppState>>,
    workspace_id: String,
    session_ids: Vec<String>,
) -> Result<(), String> {
    state.workspaces.set_workspace_sessions(&workspace_id, session_ids);
    Ok(())
}

#[tauri::command]
pub async fn workspace_index_get(
    state: State<'_, Arc<AppState>>,
    workspace_id: String,
) -> Result<Vec<String>, String> {
    Ok(state.workspaces.sessions_for(&workspace_id))
}

// --- Python sidecar health (Phase 4) ---

#[tauri::command]
pub async fn sidecar_status() -> bool {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::time::{timeout, Duration};

    let connect = async {
        let mut stream = tokio::net::TcpStream::connect("127.0.0.1:8765").await?;
        let req = b"GET /api/health HTTP/1.0\r\nHost: localhost\r\n\r\n";
        stream.write_all(req).await?;
        let mut buf = [0u8; 64];
        let n = stream.read(&mut buf).await?;
        let head = String::from_utf8_lossy(&buf[..n]);
        Ok::<_, std::io::Error>(head.starts_with("HTTP/1."))
    };
    timeout(Duration::from_millis(800), connect).await.map(|r| r.unwrap_or(false)).unwrap_or(false)
}

// --- Folder picker (workspace wizard) ---

#[tauri::command]
pub async fn pick_folder(app: tauri::AppHandle) -> Result<Option<String>, String> {
    use tauri_plugin_dialog::DialogExt;
    // The desktop dialog API is callback-based (must run on the main thread);
    // bridge it to the async command with a oneshot channel.
    let (tx, rx) = tokio::sync::oneshot::channel::<Option<tauri_plugin_dialog::FilePath>>();
    app.dialog().file().pick_folder(move |p| {
        let _ = tx.send(p);
    });
    let picked = rx
        .await
        .map_err(|_| "folder picker failed".to_string())?;
    Ok(picked.map(|p| match p {
        tauri_plugin_dialog::FilePath::Path(s) => s.to_string_lossy().to_string(),
        tauri_plugin_dialog::FilePath::Url(u) => {
            // Convert file:// URL to a real filesystem path.
            match u.to_file_path() {
                Ok(pb) => pb.to_string_lossy().to_string(),
                Err(_) => u.to_string(),
            }
        }
    }))
}

/// Return the user's HOME directory (cross-platform).
#[tauri::command]
pub async fn get_home_dir() -> Option<String> {
    let home = super::home_dir();
    let s = home.to_string_lossy().to_string();
    if s.is_empty() { return None; }
    Some(s)
}

// --- ego-lite browser automation status ---

#[derive(serde::Serialize)]
pub struct EgoLiteStatus {
    /// Whether the ego-lite.app is installed.
    pub app_installed: bool,
    /// Whether the ego-browser skill is available for agents.
    pub skill_installed: bool,
    /// Path to the skill directory if found.
    pub skill_path: Option<String>,
}

/// Check if ego-lite (browser automation for AI agents) is installed.
#[tauri::command]
pub async fn ego_lite_status() -> EgoLiteStatus {
    let home = super::home_dir();
    let home_str = home.display().to_string();

    // macOS: /Applications/ego-lite.app or /Applications/ego (lite).app
    #[cfg(not(target_os = "windows"))]
    let app_installed = std::path::Path::new("/Applications/ego-lite.app").exists()
        || std::path::Path::new("/Applications/ego (lite).app").exists();
    // Windows: modern install locations (winget/NSIS place here)
    #[cfg(target_os = "windows")]
    let app_installed = [
        // winget / common installer locations
        format!("{}\\AppData\\Local\\Programs\\ego-lite", home.display()),
        format!("{}\\AppData\\Roaming\\ego-lite", home.display()),
        // Traditional Program Files locations
        "C:\\Program Files\\ego-lite".to_string(),
        "C:\\Program Files (x86)\\ego-lite".to_string(),
    ].iter().any(|p| std::path::Path::new(p).exists());

    // Check for the ego-browser skill in common agent skill directories
    let skill_dirs = [
        format!("{home_str}/.agents/skills/ego-browser"),
        format!("{home_str}/.claude/skills/ego-browser"),
        format!("{home_str}/.codex/skills/ego-browser"),
        format!("{home_str}/.gemini/skills/ego-browser"),
    ];
    let mut skill_installed = false;
    let mut skill_path = None;
    for dir in &skill_dirs {
        if std::path::Path::new(dir).exists() {
            skill_installed = true;
            skill_path = Some(dir.to_string());
            break;
        }
    }

    EgoLiteStatus { app_installed, skill_installed, skill_path }
}

// --- Launch CWD (the directory the user ran `tto` from) ---

#[tauri::command]
pub async fn get_launch_cwd() -> Option<String> {
    // Read the CWD that the `tto` script wrote before launching the app.
    let path = crate::home_dir().join(".tto-web/launch-cwd");
    let content = std::fs::read_to_string(&path).ok()?;
    let cwd = content.trim().to_string();
    // Validate it's a real directory
    if cwd.is_empty() || !std::path::Path::new(&cwd).is_dir() {
        return None;
    }
    Some(cwd)
}

// ── Django Project Reviewer ────────────────────────────────────────────────

#[tauri::command]
pub async fn django_extract_zip(zip_path: String) -> Result<crate::django::ProjectInfo, String> {
    crate::django::extractor::extract_zip(&zip_path)
}

#[tauri::command]
pub async fn django_analyze(project_path: String) -> Result<crate::django::AnalysisReport, String> {
    let root = std::path::Path::new(&project_path);
    // If it's a zip file, extract first; if it's a directory, analyze directly.
    let info = if project_path.ends_with(".zip") {
        crate::django::extractor::extract_zip(&project_path)?
    } else {
        crate::django::ProjectInfo {
            name: root.file_name().and_then(|n| n.to_str()).unwrap_or("project").to_string(),
            path: project_path.clone(),
            file_tree: crate::django::extractor::build_file_tree(root, root).unwrap_or_default(),
            has_manage_py: root.join("manage.py").exists(),
            has_settings_py: crate::django::extractor::find_settings_py(root).is_some(),
            python_files: crate::django::extractor::find_python_files(root),
            total_files: crate::django::extractor::count_files(root),
        }
    };
    crate::django::analyzer::analyze_project(&info)
}

#[tauri::command]
pub async fn django_fix(project_path: String) -> Result<crate::django::FixReport, String> {    let info = crate::django::ProjectInfo {
            name: "fix-target".to_string(),
            path: project_path.clone(),
            file_tree: vec![],
            has_manage_py: std::path::Path::new(&project_path).join("manage.py").exists(),
            has_settings_py: true,
            python_files: crate::django::extractor::find_python_files(
                std::path::Path::new(&project_path)
            ),
            total_files: 0,
        };
    let report = crate::django::analyzer::analyze_project(&info)?;
    crate::django::fixer::fix_project(&report)
}

#[tauri::command]
pub async fn django_run_checks(project_path: String) -> Result<crate::django::CheckResults, String> {
    crate::django::executor::run_checks(&project_path)
}

#[tauri::command]
pub async fn django_package(project_path: String) -> Result<String, String> {
    crate::django::packager::package_project(&project_path, None)
}

/// Clean up old extracted Django project directories from temp.
/// Removes any tto-django-* directories older than the specified age (in minutes).
/// Default is 60 minutes (1 hour).
#[tauri::command]
pub async fn django_cleanup_old_projects(max_age_minutes: u64) -> Result<usize, String> {
    crate::django::extractor::cleanup_old_projects(max_age_minutes)
}
