//! Python sidecar lifecycle (auto-start / auto-stop).
//!
//! The FastAPI backend (tasks, token usage, file browser, LLM suggestions) is
//! spawned automatically on app launch when nothing is already serving on
//! 127.0.0.1:8765, and stopped on app exit — but ONLY when WE spawned it. An
//! externally-started server (e.g. `./start_server.sh`) is left alone.
//!
//! The frontend already retries its WebSocket every 3 s, so a freshly-spawned
//! sidecar (binds in ~1 s) is picked up automatically without any extra code.

use std::net::TcpStream;
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::Duration;

/// Sidecar address the whole app agrees on (see ipc::sidecar_status).
pub const SIDECAR_ADDR: &str = "127.0.0.1:8765";

/// True when something already answers on the sidecar port.
pub fn already_running() -> bool {
    let Ok(addr) = SIDECAR_ADDR.parse() else {
        return false;
    };
    TcpStream::connect_timeout(&addr, Duration::from_millis(300)).is_ok()
}

/// Start the Python backend if it isn't running.
/// Returns `Some(child)` when we spawned it (the caller should kill it on app
/// exit), `None` when it was already running or spawn failed.
pub fn spawn_if_needed() -> Option<Child> {
    if already_running() {
        log("sidecar already running — not spawning");
        return None;
    }
    // Kill any orphaned sidecar processes from a previous crashed run
    kill_stale_sidecars();

    let home = crate::home_dir();
    // Allow an override for non-default install locations.
    let base = PathBuf::from(
        std::env::var("TTO_WEB_HOME").unwrap_or_else(|_| format!("{}/tto-web", home.display())),
    );
    let backend_dir = base.join("backend");
    let script = backend_dir.join("main.py");

    // Locate the Python interpreter.
    // Unix: venv/bin/python or python3 on PATH.
    // Windows: venv\Scripts\python.exe or python / py on PATH.
    let python_unix = base.join("venv/bin/python");
    #[cfg(target_os = "windows")]
    let python_windows = base.join("venv\\Scripts\\python.exe");
    let python = {
        #[cfg(not(target_os = "windows"))]
        {
            if python_unix.exists() {
                python_unix
            } else {
                log("venv python not found — falling back to python3 on PATH");
                PathBuf::from("python3")
            }
        }
        #[cfg(target_os = "windows")]
        {
            if python_windows.exists() {
                python_windows
            } else if python_unix.exists() {
                python_unix // handle Unix-style paths if present
            } else {
                log("venv python not found — falling back to python/py on PATH");
                // Try both `python` and `py` launcher; pick whichever resolves.
                if Command::new("python").arg("--version").output().is_ok() {
                    PathBuf::from("python")
                } else if Command::new("py").arg("--version").output().is_ok() {
                    PathBuf::from("py")
                } else {
                    PathBuf::from("python") // will likely fail later with a clear error
                }
            }
        }
    };

    // Log sidecar stdout/stderr so failures are diagnosable.
    let log_path = home.join(".local/share/tto/sidecar.log");
    if let Some(parent) = log_path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let Ok(log_file) = std::fs::OpenOptions::new().create(true).append(true).open(&log_path) else {
        log("could not open sidecar.log");
        return None;
    };
    let Ok(err_file) = log_file.try_clone() else {
        return None;
    };

    match Command::new(&python)
        .arg(&script)
        .current_dir(&backend_dir)
        .stdout(Stdio::from(log_file))
        .stderr(Stdio::from(err_file))
        .spawn()
    {
        Ok(child) => {
            log(&format!("spawned sidecar: {} {} (pid {})", python.display(), script.display(), child.id()));
            Some(child)
        }
        Err(e) => {
            log(&format!("failed to spawn sidecar {}: {e}", python.display()));
            None
        }
    }
}

/// Best-effort graceful stop (SIGTERM / taskkill) for a sidecar we spawned.
pub fn stop(child: &mut Child) {
    #[cfg(not(target_os = "windows"))]
    {
        // `kill(1)` sends SIGTERM so the FastAPI app can run its shutdown hooks
        // (state flush) instead of being SIGKILLed.
        let _ = Command::new("kill").arg(child.id().to_string()).status();
    }
    #[cfg(target_os = "windows")]
    {
        // Windows has no SIGTERM; ask the OS to terminate the process directly.
        let _ = child.kill();
    }
    let _ = child.wait();
}

/// Kill any orphaned sidecar processes from a previous crashed run.
///
/// Unix: `lsof -ti :8765 -sTCP:LISTEN` → PIDs → `kill -TERM <pid>`.
/// Windows: `netstat -ano` parsed for LISTENING on :8765 → PIDs → `taskkill /F /PID`.
fn kill_stale_sidecars() {
    #[cfg(target_os = "windows")]
    {
        // Windows: parse netstat for the sidecar port and kill those PIDs.
        // We read the raw output and do our own parsing rather than depending on
        // any third-party crate. If anything is unparseable we no-op safely —
        // leaking one stale sidecar is worse than accidentally killing another
        // process, so we only act on lines that clearly look like a listening PID.
        let Ok(output) = Command::new("netstat")
            .args(["-ano"])
            .output()
        else {
            return;
        };
        let text = String::from_utf8_lossy(&output.stdout);
        // Each listening entry looks like:
        //   TCP    127.0.0.1:8765         0.0.0.0:0              LISTENING       12345
        for line in text.lines() {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 5 || !parts[1].ends_with(":8765") || parts[3] != "LISTENING" {
                continue;
            }
            let pid = match parts[4].parse::<u32>() {
                Ok(p) => p,
                Err(_) => continue,
            };
            log(&format!("killing stale sidecar pid {pid}"));
            let _ = Command::new("taskkill")
                .args(["/F", "/PID", &pid.to_string()])
                .output();
        }
        std::thread::sleep(std::time::Duration::from_millis(500));
        return;
    }

    // Unix path (macOS / Linux).
    let Ok(output) = Command::new("lsof")
        .args(["-ti", ":8765", "-sTCP:LISTEN"])
        .output()
    else {
        return;
    };
    let stdout = String::from_utf8_lossy(&output.stdout);
    for line in stdout.lines() {
        let pid = line.trim();
        if pid.is_empty() {
            continue;
        }
        log(&format!("killing stale sidecar pid {pid}"));
        let _ = Command::new("kill").arg("-TERM").arg(pid).status();
    }
    // Brief pause to let SIGTERM propagate
    std::thread::sleep(std::time::Duration::from_millis(500));
}

fn log(msg: &str) {
    eprintln!("[sidecar] {msg}");
    use std::io::Write;
    use std::time::{SystemTime, UNIX_EPOCH};
    let ts = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis()).unwrap_or(0);
    let path = crate::home_dir().join(".local/share/tto/rust-diag.log");
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(&path) {
        let _ = writeln!(f, "{ts} | {msg}");
    }
}
