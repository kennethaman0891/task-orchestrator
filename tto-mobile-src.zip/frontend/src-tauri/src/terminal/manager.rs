//! Terminal manager: registry + lifecycle (spec §4, §7, §36).
//!
//! Owns every terminal session. Creating T5 spawns PTY #5 + reader #5 and
//! leaves T1–T4 untouched.

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::AtomicU64;
use std::sync::Arc;

use parking_lot::Mutex;
use tauri::ipc::Channel;
use tauri::{AppHandle, Emitter};

use super::output::{spawn_reader, QUEUE_CAP};
use super::pty::{self};
use super::recovery;
use super::session::{SessionDiag, SessionMeta, TerminalSession};

pub struct TerminalManager {
    pub app: AppHandle,
    pub sessions: Mutex<HashMap<String, Arc<TerminalSession>>>,
    counter: AtomicU64,
}

/// Heuristic agent detection from the launched command (spec §26).
fn detect_agent(command: &str) -> String {
    let lower = command.to_lowercase();
    let candidates: &[(&str, &[&str])] = &[
        ("claude", &["claude"][..]),
        ("codex", &["codex"][..]),
        ("opencode", &["opencode"][..]),
        ("gemini", &["gemini", "gemini-cli"][..]),
        ("aider", &["aider"][..]),
        ("cursor-agent", &["cursor-agent"][..]),
    ];
    for (name, keys) in candidates {
        if keys.iter().any(|k| lower.contains(k)) {
            return name.to_string();
        }
    }
    String::new()
}

impl TerminalManager {
    pub fn new(app: AppHandle) -> Self {
        Self {
            app,
            sessions: Mutex::new(HashMap::new()),
            counter: AtomicU64::new(1),
        }
    }

    fn next_id(&self) -> String {
        let n = self.counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        format!("terminal-{n}")
    }

    /// Create a native terminal session (spec §7: creates ONLY the new session).
    pub fn create(
        &self,
        cwd: Option<String>,
        workspace_id: String,
        cols: u16,
        rows: u16,
    ) -> Result<SessionMeta, String> {
        let id = self.next_id();
        eprintln!("[MANAGER] create() id={}, cwd={:?}, ws={}", id, cwd, workspace_id);
        let shell = pty::user_shell();
        let cwd_path = {
            let raw = cwd.unwrap_or_default();
            // Expand ~ to the user's home directory (shell convention).
            // Uses crate::home_dir() which handles USERPROFILE on Windows.
            let expanded = if raw.starts_with('~') {
                let home = crate::home_dir();
                if let Some(rest) = raw.strip_prefix("~/") {
                    format!("{}", home.join(rest).display())
                } else if raw == "~" {
                    home.to_string_lossy().to_string()
                } else {
                    raw.clone()
                }
            } else {
                raw
            };
            let p = PathBuf::from(&expanded);
            // Validate the path exists and is a directory; fall back to HOME.
            if !expanded.is_empty() && p.is_dir() {
                p
            } else {
                crate::home_dir()
            }
        };
        let (handle, reader) = pty::spawn_shell(&cwd_path, cols.max(2), rows.max(2))?;
        let pid = handle.pid;

        let (tx, rx) = tokio::sync::mpsc::channel(QUEUE_CAP);
        let _reader = spawn_reader(reader, tx);

        let meta = SessionMeta {
            id: id.clone(),
            workspace_id,
            shell,
            cwd: cwd_path.to_string_lossy().to_string(),
            title: "tto · shell".to_string(),
            status: "running".to_string(),
            agent: String::new(),
            created_at: now(),
            last_activity: now(),
            cols,
            rows,
            tui_active: false,
            pid,
            tty: pty::tty_for_pid(pid),
            grid_mode: "auto".to_string(),
        };

        let session = Arc::new(TerminalSession::new(meta.clone(), handle, rx));
        eprintln!("[MANAGER] insert session={} tty={}", id, meta.tty);
        self.sessions.lock().insert(id.clone(), session);
        let _ = self.app.emit("terminal-updated", ());
        Ok(meta)
    }

    /// Attach a frontend renderer channel + exit channel to an existing session
    /// (spec §28: reattach, never restart the process).
    pub fn attach(
        &self,
        id: &str,
        on_output: Channel<Vec<u8>>,
        on_exit: Channel<()>,
    ) -> Result<(), String> {
        eprintln!("[MANAGER] attach() id={}", id);
        let sessions = self.sessions.lock();
        let session = sessions.get(id).ok_or_else(|| format!("no session {id}"))?;
        recovery::attach(session, on_output, on_exit);
        eprintln!("[MANAGER] attach() id={} -> OK", id);
        Ok(())
    }

    /// Explicitly detach (e.g. window unload). PTY keeps running; output stays
    /// bounded in the queue.
    pub fn detach(&self, id: &str) -> Result<(), String> {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            recovery::detach(session);
        }
        Ok(())
    }

    /// Register a secondary read-only mirror subscriber (Space view renderer).
    pub fn subscribe(&self, id: &str, sub_id: u64, channel: Channel<Vec<u8>>) -> Result<(), String> {
        let sessions = self.sessions.lock();
        let session = sessions.get(id).ok_or_else(|| format!("no session {id}"))?;
        recovery::subscribe(session, sub_id, channel);
        Ok(())
    }

    /// Remove a secondary subscriber (idempotent).
    pub fn unsubscribe(&self, id: &str, sub_id: u64) -> Result<(), String> {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            recovery::unsubscribe(session, sub_id);
        }
        Ok(())
    }

    pub fn write(&self, id: &str, data: &[u8]) -> Result<(), String> {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            return session.write(data);
        }
        for session in sessions.values() {
            let meta = session.meta.lock();
            if meta.id == id || meta.tty == id || (!id.is_empty() && meta.tty.contains(id)) {
                return session.write(data);
            }
        }
        Err(format!("no session {id}"))
    }

    pub fn send_command(&self, id: &str, command: &str) -> Result<(), String> {
        let sessions = self.sessions.lock();
        let session = sessions.get(id).cloned().or_else(|| {
            sessions.values().find(|s| {
                let meta = s.meta.lock();
                meta.id == id || meta.tty == id || (!id.is_empty() && meta.tty.contains(id))
            }).cloned()
        }).ok_or_else(|| format!("no session {id}"))?;
        eprintln!("[MANAGER] send_command id={} cmd={:?}", id, command);
        let agent = detect_agent(command);
        if !agent.is_empty() {
            session.meta.lock().agent = agent;
        }
        let r = session.send_command(command);
        eprintln!("[MANAGER] send_command id={} -> {:?}", id, r.as_ref().err());
        r
    }

    /// Look up a session by its slave tty (e.g. "ttys004") and inject a
    /// command. Used by the sidecar command relay: the sidecar knows only the
    /// tty, and only we (the Rust process) hold the PTY master fd.
    pub fn send_command_by_tty(&self, tty: &str, command: &str) -> Result<(), String> {
        if tty.is_empty() {
            return Err("empty tty".to_string());
        }
        let sessions = self.sessions.lock();
        for session in sessions.values() {
            if session.meta.lock().tty == tty {
                let agent = detect_agent(command);
                if !agent.is_empty() {
                    session.meta.lock().agent = agent;
                }
                return session.send_command(command);
            }
        }
        Err(format!("no session with tty {tty}"))
    }

    /// Write raw bytes to a session found by its slave tty (remote /stop
    /// sends Ctrl+C this way). Mirrors `send_command_by_tty`.
    pub fn write_by_tty(&self, tty: &str, data: &str) -> Result<(), String> {
        if tty.is_empty() {
            return Err("empty tty".to_string());
        }
        let sessions = self.sessions.lock();
        for session in sessions.values() {
            if session.meta.lock().tty == tty {
                return session.write(data.as_bytes());
            }
        }
        Err(format!("no session with tty {tty}"))
    }

    /// Restart the shell inside the session whose slave tty matches
    /// (remote /restart for Rust sessions).
    pub fn restart_by_tty(&self, tty: &str) -> Result<(), String> {
        if tty.is_empty() {
            return Err("empty tty".to_string());
        }
        let id = self.id_for_tty(tty)?;
        self.restart(&id)
    }

    /// Close/kill the session whose slave tty matches (remote /kill).
    pub fn close_by_tty(&self, tty: &str) -> Result<(), String> {
        if tty.is_empty() {
            return Err("empty tty".to_string());
        }
        let id = self.id_for_tty(tty)?;
        self.close(&id)
    }

    fn id_for_tty(&self, tty: &str) -> Result<String, String> {
        let sessions = self.sessions.lock();
        for (id, session) in sessions.iter() {
            if session.meta.lock().tty == tty {
                return Ok(id.clone());
            }
        }
        Err(format!("no session with tty {tty}"))
    }

    pub fn resize(&self, id: &str, cols: u16, rows: u16) -> Result<(), String> {
        use super::resize as rz;
        let sessions = self.sessions.lock();
        let session = sessions.get(id).ok_or_else(|| format!("no session {id}"))?;
        let (cols, rows) = rz::clamp(cols, rows);
        {
            let m = session.meta.lock();
            if !rz::changed(m.cols, m.rows, cols, rows) {
                return Ok(()); // no-op: avoids ioctl + resize loops (spec §35)
            }
        }
        {
            let pty = session.pty.lock();
            pty::resize(&*pty.master, cols, rows)?;
        }
        {
            let mut m = session.meta.lock();
            m.cols = cols;
            m.rows = rows;
        }
        Ok(())
    }

    /// Kill the process and drop the session. The frontend recreates on demand.
    pub fn close(&self, id: &str) -> Result<(), String> {
        let mut sessions = self.sessions.lock();
        if let Some(session) = sessions.remove(id) {
            let _ = session.pty.lock().child.kill();
            let _ = session.pty.lock().child.wait();
        }
        let _ = self.app.emit("terminal-updated", ());
        Ok(())
    }

    /// Kill every PTY child. Called on app exit so shells/TUIs (e.g. opencode)
    /// are NOT orphaned with a dead terminal — orphaned TUI processes spin at
    /// 100% CPU and can crash their runtime (Bun SIGTRAP in the renderer).
    pub fn kill_all(&self) {
        let sessions = self.sessions.lock();
        for session in sessions.values() {
            let mut pty = session.pty.lock();
            let _ = pty.child.kill();
            let _ = pty.child.wait();
        }
    }

    /// Restart the shell process inside the same session (same id, same cwd).
    /// The renderer channel is preserved; the reader queue is swapped.
    pub fn restart(&self, id: &str) -> Result<(), String> {
        let sessions = self.sessions.lock();
        let session = sessions.get(id).ok_or_else(|| format!("no session {id}"))?;

        let (cwd, cols, rows, grid_mode) = {
            let m = session.meta.lock();
            (m.cwd.clone(), m.cols, m.rows, m.grid_mode.clone())
        };

        {
            let mut pty = session.pty.lock();
            let _ = pty.child.kill();
            let _ = pty.child.wait();
        }

        let (handle, reader) = pty::spawn_shell(&PathBuf::from(&cwd), cols, rows)?;
        let pid = handle.pid;
        let (tx, rx) = tokio::sync::mpsc::channel(QUEUE_CAP);
        let _reader = spawn_reader(reader, tx);

        // Swap PTY + queue; keep id + channels (detach/re-attach handled by UI).
        recovery::detach(session);
        session.reset_scrollback();
        *session.pty.lock() = handle;
        *session.rx.lock() = Some(rx);

        {
            let mut m = session.meta.lock();
            m.status = "running".to_string();
            m.pid = pid;
            m.tty = pty::tty_for_pid(pid);
            m.last_activity = now();
            m.grid_mode = grid_mode;
        }
        let _ = self.app.emit("terminal-updated", ());
        Ok(())
    }

    pub fn list(&self) -> Vec<SessionMeta> {
        self.sessions.lock().values().map(|s| s.meta()).collect()
    }

    pub fn get_meta(&self, id: &str) -> Option<SessionMeta> {
        self.sessions.lock().get(id).map(|s| s.meta())
    }

    /// Return the full persistent scrollback for a session (FIX: full-history
    /// replay). The frontend calls this after (re)creating a renderer so the
    /// terminal shows the ENTIRE output history, not just the newest chunks.
    pub fn get_scrollback(&self, id: &str) -> Result<Vec<u8>, String> {
        let sessions = self.sessions.lock();
        let session = sessions.get(id).ok_or_else(|| format!("no session {id}"))?;
        Ok(session.scrollback_copy())
    }

    pub fn set_title(&self, id: &str, title: &str) {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            session.meta.lock().title = title.to_string();
        }
    }

    pub fn set_tui(&self, id: &str, active: bool) {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            session.meta.lock().tui_active = active;
        }
    }

    pub fn set_focus(&self, id: &str, focused: bool) {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            let changed = session.focused.load(std::sync::atomic::Ordering::Relaxed) != focused;
            session
                .focused
                .store(focused, std::sync::atomic::Ordering::Relaxed);
            if changed {
                drop(sessions);
                let _ = self.app.emit("terminal-updated", ());
            }
        }
    }

    pub fn set_visible(&self, id: &str, visible: bool) {
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            let changed = session.visible.load(std::sync::atomic::Ordering::Relaxed) != visible;
            session
                .visible
                .store(visible, std::sync::atomic::Ordering::Relaxed);
            if changed {
                drop(sessions);
                let _ = self.app.emit("terminal-updated", ());
            }
        }
    }

    /// Update the grid layout mode for a session (auto | grid | compact | large).
    /// Stored in metadata so the scheduler and diagnostics know the presentation
    /// context. Also emits a terminal-updated event so the frontend can react.
    pub fn set_grid_mode(&self, id: &str, mode: &str) {
        let valid = matches!(mode, "auto" | "grid" | "compact" | "large");
        let mode = if valid { mode } else { "auto" };
        let sessions = self.sessions.lock();
        if let Some(session) = sessions.get(id) {
            session.meta.lock().grid_mode = mode.to_string();
            drop(sessions);
            let _ = self.app.emit("terminal-updated", ());
        }
    }

    /// Batch-resize all sessions belonging to a workspace to the given dimensions.
    /// Called when the user switches grid layout modes so every terminal in the
    /// workspace gets a SIGWINCH at the new card size in one pass.
    pub fn batch_resize(&self, workspace_id: &str, cols: u16, rows: u16) -> usize {
        use super::resize as rz;
        let (cols, rows) = rz::clamp(cols, rows);
        let mut resized = 0usize;
        let sessions = self.sessions.lock();
        for session in sessions.values() {
            {
                let m = session.meta.lock();
                if m.workspace_id != workspace_id {
                    continue;
                }
                if !rz::changed(m.cols, m.rows, cols, rows) {
                    continue;
                }
            }
            {
                let pty = session.pty.lock();
                if pty::resize(&*pty.master, cols, rows).is_err() {
                    continue;
                }
            }
            {
                let mut m = session.meta.lock();
                m.cols = cols;
                m.rows = rows;
            }
            resized += 1;
        }
        if resized > 0 {
            drop(sessions);
            let _ = self.app.emit("terminal-updated", ());
        }
        resized
    }

    pub fn diagnostics(&self) -> Vec<SessionDiag> {
        self.sessions.lock().values().map(|s| s.diag()).collect()
    }

    /// Drain one terminal's pending output up to `budget` chunks, forwarding to
    /// the attached renderer channel AND/OR mirror subscribers. Returns (forwarded, exited).
    ///
    /// IMPORTANT (fix: blank-terminal bug): output is ONLY consumed while a
    /// renderer is listening — either the PRIMARY channel (old grid view) or at
    /// least ONE mirror SUBSCRIBER (Space view). While nothing listens (e.g.
    /// the first ~200 ms between spawn and webview attach, or a pane swap),
    /// chunks stay queued — bounded by QUEUE_CAP — so the next listener resumes
    /// exactly where output left off.
    ///
    /// FIX (missing-content bug): previously drain refused to run unless the
    /// PRIMARY channel existed. The Space view only ever SUBSCRIBES (mirrors),
    /// never attaches — so its sessions had channel=None forever, the queue
    /// filled to QUEUE_CAP (~2 MB), the PTY reader blocked on backpressure,
    /// and terminals froze with truncated/missing content. Now mirrors count
    /// as listeners too.
    pub fn drain(&self, id: &str, budget: usize) -> (usize, bool) {
        let sessions = self.sessions.lock();
        let Some(session) = sessions.get(id) else {
            return (0, false);
        };
        // Original reattach semantics (spec §28): do NOT consume the queue unless
        // a renderer (primary channel or mirror subscriber) is listening. Output
        // accumulates in the bounded queue and is transparently replayed to a
        // renderer when it attaches — no destructive watchdog remount loop.
        let has_primary = session.channel.lock().is_some();
        let has_subscribers = !session.subscribers.lock().is_empty();
        if !has_primary && !has_subscribers {
            return (0, false);
        }
        let mut forwarded = 0usize;
        let mut exited = false;
        for _ in 0..budget {
            let chunk = {
                let mut rx_guard = session.rx.lock();
                match rx_guard.as_mut().map(|r| r.try_recv()) {
                    Some(Ok(chunk)) => chunk,
                    _ => break,
                }
            };
            session
                .dropped
                .fetch_add(chunk.dropped, std::sync::atomic::Ordering::Relaxed);
            // Keep the persistent scrollback updated for the read-only
            // get_scrollback diagnostic; it does NOT change when the queue is
            // consumed (reattach replay still works as before).
            session.append_scrollback(&chunk.data);
            if chunk.eof {
                exited = true;
                let _ = session.pty.lock().child.try_wait();
                session.meta.lock().status = "exited".to_string();
            }
            if !chunk.data.is_empty() {
                // Rust-side taps (gateway bridge) get a copy BEFORE the JS
                // fan-out so remote streaming never competes with renderers.
                session.publish_rust_taps(&chunk.data);
                if recovery::send_chunk(session, chunk.data) {
                    session
                        .chunks_sent
                        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    forwarded += 1;
                }
            }
            if chunk.eof {
                recovery::notify_exit(session);
            }
        }
        if exited {
            drop(sessions);
            let _ = self.app.emit("terminal-updated", ());
        }
        (forwarded, exited)
    }
}

fn now() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs_f64())
        .unwrap_or(0.0)
}
