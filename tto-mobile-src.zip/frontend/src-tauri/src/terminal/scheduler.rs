//! Centralized render scheduler (spec §10, §27, §31, §12).
//!
//! Priority model:
//!   focused    → flush up to 64 chunks per 16 ms tick (instant typing/UX)
//!   visible    → flush up to 16 chunks per 16 ms tick (normal live output)
//!   visible+compact → flush up to 24 chunks per 16 ms tick (smaller panes
//!                     need more frequent updates to stay readable)
//!   background → flush up to 8 chunks per 250 ms tick (throttled, coalesced)
//!
//! Round-robin across sessions prevents one terminal from starving others.
//! IMPORTANT: only RENDERING is throttled — the PTY/process always runs.
//!
//! Flush deadlines: the 16 ms tick is the max-age deadline for focused/visible
//! terminals, so live output streams while an agent works (never waits for a
//! whole burst).

use std::sync::Arc;
use std::time::Duration;

use super::manager::TerminalManager;

/// ms between scheduler ticks.
const TICK_MS: u64 = 16;
/// Background flush cadence: every 16th tick (≈ 250 ms).
const BACKGROUND_EVERY: u64 = 16;

pub fn spawn_scheduler(manager: Arc<TerminalManager>) {
    std::thread::spawn(move || {
        let mut tick: u64 = 0;
        loop {
            std::thread::sleep(Duration::from_millis(TICK_MS));
            tick += 1;

            let ids: Vec<String> = manager
                .sessions
                .lock()
                .keys()
                .cloned()
                .collect();

            for id in &ids {
                let budget = {
                    let sessions = manager.sessions.lock();
                    match sessions.get(id) {
                        Some(s) => match s.mode() {
                            "focused" => 64,
                            "visible" => {
                                // In compact mode visible terminals are smaller
                                // and need more frequent flushes to stay readable.
                                let m = s.meta.lock();
                                if m.grid_mode == "compact" { 24 } else { 16 }
                            }
                            _ => {
                                if tick % BACKGROUND_EVERY == 0 {
                                    8
                                } else {
                                    0
                                }
                            }
                        },
                        None => 0,
                    }
                };
                if budget > 0 {
                    manager.drain(id, budget);
                }
            }
        }
    });
}
