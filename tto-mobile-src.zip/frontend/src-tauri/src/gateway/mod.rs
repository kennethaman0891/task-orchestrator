//! TTO Gateway client — outbound persistent connection.
//!
//! The desktop connects OUTBOUND to the gateway (WSS), so no inbound ports,
//! port forwarding, or static IP are ever needed on the home network. The
//! connection survives UI closure (spawned as a tokio task) and reconnects
//! with exponential backoff + jitter on network changes / gateway restarts.
//!
//! Protocol: versioned JSON envelopes `{ v, id, type, payload }` (see
//! gateway/src/protocol.ts). This module speaks the DESKTOP role:
//!   hello (deviceId + credential) → ack → heartbeat / pong
//!   terminal.input / terminal.resize / terminal.signal → local PTY manager
//!   session.list / terminal.list → local manager list
//!   terminal.output (from remote clients) → forwarded to local PTY manager
//!   file.list / file.read → scoped filesystem access

pub mod identity;
pub mod ipc;

use std::sync::Arc;
use std::time::Duration;

use futures_util::{SinkExt, StreamExt};
use parking_lot::Mutex;
use serde_json::json;
use tauri::{AppHandle, Emitter};
use tokio_tungstenite::tungstenite::Message;

use crate::terminal::manager::TerminalManager;

use identity::DeviceIdentity;

/// Connection state surfaced to the UI.
#[derive(Clone, serde::Serialize, PartialEq, Debug)]
#[serde(rename_all = "UPPERCASE")]
pub enum GatewayState {
    OFFLINE,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
}

pub struct GatewayClient {
    /// Shared connection state (updated by the worker task).
    pub state: Mutex<GatewayState>,
    /// How many reconnect attempts have happened in the current cycle.
    pub attempts: Mutex<u32>,
}

impl GatewayClient {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(GatewayState::OFFLINE),
            attempts: Mutex::new(0),
        }
    }

    pub fn status(&self) -> GatewayState {
        self.state.lock().clone()
    }
}

impl Default for GatewayClient {
    fn default() -> Self {
        Self::new()
    }
}

/// Worker: connects to the gateway and keeps the connection alive.
/// Returns when the connection is intentionally stopped.
pub async fn run_connection(
    app: AppHandle,
    manager: Arc<TerminalManager>,
    client: Arc<GatewayClient>,
    ident: Arc<Mutex<DeviceIdentity>>,
) {
    let mut attempt: u32 = 0;
    loop {
        // Clone values under the lock, then drop the guard before any .await
        // (parking_lot::MutexGuard is !Send and cannot cross await points).
        let (url, has_credential) = {
            let id = ident.lock();
            (id.gateway_url.clone(), !id.credential.is_empty())
        };
        if url.is_empty() || !has_credential {
            // Not paired yet — wait for the user to pair.
            *client.state.lock() = GatewayState::OFFLINE;
            tokio::time::sleep(Duration::from_secs(3)).await;
            continue;
        }

        *client.state.lock() = GatewayState::CONNECTING;
        let _ = app.emit("gateway-status", client.status());

        match connect_once(&app, &manager, &client, &ident, &url).await {
            Ok(_) => {
                // Clean disconnect (e.g. app exit or explicit stop).
                *client.state.lock() = GatewayState::OFFLINE;
                let _ = app.emit("gateway-status", client.status());
                return;
            }
            Err(_) => {
                attempt += 1;
                *client.attempts.lock() = attempt;
                *client.state.lock() = if attempt > 1 {
                    GatewayState::RECONNECTING
                } else {
                    GatewayState::CONNECTING
                };
                let _ = app.emit("gateway-status", client.status());
                // Exponential backoff with jitter: 2s, 4s, 8s, ... capped at 60s.
                let backoff = Duration::from_secs((2u64 << attempt.min(5)) + rand::random::<u64>() % 2);
                tokio::time::sleep(backoff).await;
            }
        }
    }
}

/// One connect cycle: handshake, heartbeat, message loop. Returns Ok on clean
/// disconnect (stops the worker) or Err on failure (triggers reconnect).
async fn connect_once(
    app: &AppHandle,
    manager: &Arc<TerminalManager>,
    client: &Arc<GatewayClient>,
    ident: &Arc<Mutex<DeviceIdentity>>,
    url: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let (device_id, credential) = {
        let id = ident.lock();
        (id.device_id.clone(), id.credential.clone())
    };

    let (mut ws, _resp) = tokio_tungstenite::connect_async(url).await?;

    // Handshake: hello with device identity.
    ws.send(Message::Text(
        json!({
            "v": 1,
            "id": "hello",
            "type": "hello",
            "payload": { "role": "desktop", "deviceId": device_id, "credential": credential }
        })
        .to_string(),
    ))
    .await?;

    *client.state.lock() = GatewayState::CONNECTED;
    let _ = app.emit("gateway-status", client.status());
    // TODO(remote): reset attempts on successful connect
    *client.attempts.lock() = 0;

    let (mut write, mut read) = ws.split();
    let mut heartbeat = tokio::time::interval(Duration::from_secs(15));
    heartbeat.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    loop {
        tokio::select! {
            _ = heartbeat.tick() => {
                write.send(Message::Text(json!({
                    "v": 1, "id": "hb", "type": "heartbeat", "payload": {}
                }).to_string())).await?;
            }
            msg = read.next() => {
                match msg {
                    Some(Ok(Message::Text(text))) => {
                        if let Ok(env) = serde_json::from_str::<Envelope>(&text) {
                            handle_message(app, manager, env, &mut write).await;
                        }
                    }
                    Some(Ok(Message::Ping(p))) => {
                        write.send(Message::Pong(p)).await?;
                    }
                    Some(Ok(Message::Close(_))) => {
                        return Err("gateway closed connection".into());
                    }
                    Some(Err(e)) => {
                        return Err(e.into());
                    }
                    None => {
                        return Err("gateway connection ended".into());
                    }
                    _ => {}
                }
            }
        }
    }
}

#[derive(serde::Deserialize)]
struct Envelope {
    #[serde(default)]
    id: String,
    #[serde(rename = "type")]
    kind: String,
    #[serde(default)]
    payload: serde_json::Value,
}

async fn handle_message(
    app: &AppHandle,
    manager: &Arc<TerminalManager>,
    env: Envelope,
    write: &mut (impl SinkExt<Message> + Unpin),
) {
    match env.kind.as_str() {
        "pong" | "ack" => {}
        "session.list" | "terminal.list" => {
            let sessions: Vec<_> = manager
                .list()
                .into_iter()
                .map(|m| {
                    json!({
                        "id": m.id,
                        "tty": m.tty,
                        "title": m.title,
                        "cwd": m.cwd,
                        "status": m.status,
                        "agent": m.agent,
                        "cols": m.cols,
                        "rows": m.rows,
                        "pid": m.pid,
                    })
                })
                .collect();
            let resp = json!({
                "v": 1, "id": env.id, "type": "terminal.list", "payload": { "sessions": sessions }
            });
            let _ = write.send(Message::Text(resp.to_string())).await;
        }
        "terminal.input" => {
            // Remote client typed into a terminal. ACK the result instead of
            // silently dropping — a wrong/stale sessionId must be visible.
            let session_id = env.payload.get("sessionId").and_then(|v| v.as_str()).unwrap_or("");
            let data = env.payload.get("data").and_then(|v| v.as_str()).unwrap_or("");
            let bytes = decode_b64(data);
            match manager.write(&session_id, &bytes) {
                Ok(()) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "ack",
                        "payload": { "ok": true, "kind": "terminal.input", "sessionId": session_id } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
                Err(e) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "error",
                        "payload": { "ok": false, "kind": "terminal.input", "sessionId": session_id, "error": e } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
            }
        }
        "terminal.send_command" | "task.dispatch" => {
            // Shared dispatch path: run a command in an existing session, or
            // create a NEW session when only a command is given (task.dispatch).
            let session_id = env.payload.get("sessionId").and_then(|v| v.as_str()).unwrap_or("");
            let command = env.payload.get("command").and_then(|v| v.as_str()).unwrap_or("");
            let cwd = env.payload.get("cwd").and_then(|v| v.as_str()).unwrap_or("");
            let is_task_dispatch = env.kind == "task.dispatch";

            if command.is_empty() {
                let resp = json!({ "v": 1, "id": env.id, "type": "error",
                    "payload": { "ok": false, "kind": env.kind, "error": "empty_command" } });
                let _ = write.send(Message::Text(resp.to_string())).await;
                return;
            }

            // task.dispatch with no sessionId → start a fresh terminal session
            // and run the command there, then hand the id back to the client.
            let target_session = if is_task_dispatch && session_id.is_empty() {
                let cols = env.payload.get("cols").and_then(|v| v.as_u64()).unwrap_or(120) as u16;
                let rows = env.payload.get("rows").and_then(|v| v.as_u64()).unwrap_or(40) as u16;
                let ws = env.payload.get("workspaceId").and_then(|v| v.as_str()).unwrap_or("remote").to_string();
                let cwd_owned: Option<String> =
                    if cwd.is_empty() { None } else { Some(cwd.to_string()) };
                match manager.create(cwd_owned, ws, cols, rows) {
                    Ok(meta) => Some(meta.id.clone()),
                    Err(e) => {
                        let resp = json!({ "v": 1, "id": env.id, "type": "error",
                            "payload": { "ok": false, "kind": "task.dispatch", "error": format!("create_failed: {e}") } });
                        let _ = write.send(Message::Text(resp.to_string())).await;
                        return;
                    }
                }
            } else if !session_id.is_empty() {
                Some(session_id.to_string())
            } else {
                None
            };

            let Some(target) = target_session else {
                let resp = json!({ "v": 1, "id": env.id, "type": "error",
                    "payload": { "ok": false, "kind": env.kind, "error": "no_session_id" } });
                let _ = write.send(Message::Text(resp.to_string())).await;
                return;
            };

            match manager.send_command(&target, &command) {
                Ok(()) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "ack",
                        "payload": { "ok": true, "kind": env.kind, "sessionId": target } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
                Err(e) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "error",
                        "payload": { "ok": false, "kind": env.kind, "sessionId": target, "error": e } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
            }
        }
        "terminal.resize" => {
            let session_id = env.payload.get("sessionId").and_then(|v| v.as_str()).unwrap_or("");
            let cols = env.payload.get("cols").and_then(|v| v.as_u64()).unwrap_or(80) as u16;
            let rows = env.payload.get("rows").and_then(|v| v.as_u64()).unwrap_or(24) as u16;
            match manager.resize(&session_id, cols, rows) {
                Ok(()) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "ack",
                        "payload": { "ok": true, "kind": "terminal.resize", "sessionId": session_id } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
                Err(e) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "error",
                        "payload": { "ok": false, "kind": "terminal.resize", "sessionId": session_id, "error": e } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
            }
        }
        "terminal.signal" => {
            let session_id = env.payload.get("sessionId").and_then(|v| v.as_str()).unwrap_or("");
            let signal = env.payload.get("signal").and_then(|v| v.as_str()).unwrap_or("");
            let result = match signal {
                "SIGINT" => manager.write(&session_id, b"\x03"),
                "SIGQUIT" => manager.write(&session_id, b"\x1c"),
                "SIGTSTP" => manager.write(&session_id, b"\x1a"),
                "SIGTERM" | "close" => manager.close(&session_id),
                other => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "error",
                        "payload": { "ok": false, "kind": "terminal.signal", "sessionId": session_id, "error": format!("unknown_signal: {other}") } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                    return;
                }
            };
            match result {
                Ok(()) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "ack",
                        "payload": { "ok": true, "kind": "terminal.signal", "sessionId": session_id, "signal": signal } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
                Err(e) => {
                    let resp = json!({ "v": 1, "id": env.id, "type": "error",
                        "payload": { "ok": false, "kind": "terminal.signal", "sessionId": session_id, "error": e } });
                    let _ = write.send(Message::Text(resp.to_string())).await;
                }
            }
        }
        "terminal.attach" => {
            let session_id = env.payload.get("sessionId").and_then(|v| v.as_str()).unwrap_or("");
            // Send current scrollback so the remote client can render history.
            if let Ok(scrollback) = manager.get_scrollback(session_id) {
                let resp = json!({
                    "v": 1, "id": env.id, "type": "terminal.output", "payload": {
                        "sessionId": session_id, "data": encode_b64(&scrollback), "initial": true
                    }
                });
                let _ = write.send(Message::Text(resp.to_string())).await;
            }
        }
        "file.list" => {
            let path = env.payload.get("path").and_then(|v| v.as_str()).unwrap_or("");
            let resp = handle_file_list(path);
            let out = json!({ "v": 1, "id": env.id, "type": "file.meta", "payload": resp });
            let _ = write.send(Message::Text(out.to_string())).await;
        }
        "file.read" => {
            let path = env.payload.get("path").and_then(|v| v.as_str()).unwrap_or("");
            let resp = handle_file_read(path);
            let out = json!({ "v": 1, "id": env.id, "type": "file.meta", "payload": resp });
            let _ = write.send(Message::Text(out.to_string())).await;
        }
        other => {
            // Never silently swallow an unknown type — the remote client should
            // see exactly why its message was not acted on.
            let resp = json!({ "v": 1, "id": env.id, "type": "error",
                "payload": { "ok": false, "kind": other, "error": "unknown_type" } });
            let _ = write.send(Message::Text(resp.to_string())).await;
        }
    }
    let _ = app;
}

/// List a directory (scoped: absolute paths only; hidden entries included).
fn handle_file_list(path: &str) -> serde_json::Value {
    let dir = std::path::Path::new(path);
    if !dir.is_dir() {
        return json!({ "ok": false, "error": "not_a_directory" });
    }
    let mut entries: Vec<serde_json::Value> = Vec::new();
    if let Ok(read) = std::fs::read_dir(dir) {
        for entry in read.flatten() {
            let name = entry.file_name().to_string_lossy().to_string();
            let is_dir = entry.file_type().map(|t| t.is_dir()).unwrap_or(false);
            let size = if is_dir {
                None
            } else {
                entry.metadata().ok().map(|m| m.len())
            };
            entries.push(json!({ "name": name, "isDir": is_dir, "size": size }));
        }
    }
    entries.sort_by(|a, b| {
        let ad = a["isDir"].as_bool().unwrap_or(false);
        let bd = b["isDir"].as_bool().unwrap_or(false);
        bd.cmp(&ad).then(a["name"].as_str().cmp(&b["name"].as_str()))
    });
    json!({ "ok": true, "path": path, "entries": entries })
}

/// Read a file (text-safe; binary returned as base64 with a flag).
fn handle_file_read(path: &str) -> serde_json::Value {
    let p = std::path::Path::new(path);
    if !p.is_file() {
        return json!({ "ok": false, "error": "not_a_file" });
    }
    match std::fs::read(p) {
        Ok(bytes) => {
            if bytes.iter().all(|b| b.is_ascii() || *b >= 0x20 || *b == b'\n' || *b == b'\r' || *b == b'\t') {
                json!({ "ok": true, "path": path, "text": String::from_utf8_lossy(&bytes).to_string() })
            } else {
                json!({ "ok": true, "path": path, "base64": encode_b64(&bytes), "binary": true })
            }
        }
        Err(e) => json!({ "ok": false, "error": e.to_string() }),
    }
}

fn encode_b64(data: &[u8]) -> String {
    use base64::Engine;
    base64::engine::general_purpose::STANDARD.encode(data)
}

fn decode_b64(s: &str) -> Vec<u8> {
    use base64::Engine;
    base64::engine::general_purpose::STANDARD
        .decode(s.trim())
        .unwrap_or_default()
}