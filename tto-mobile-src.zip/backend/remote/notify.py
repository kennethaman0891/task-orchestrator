"""TTO Remote Control — proactive notifications.

Watches the EXISTING terminal/task state (via the bridge) and pushes concise
WhatsApp messages for: task complete, task failed, agent waiting, terminal
crash, system error.  Guards against spam: per-category cooldown, message
dedup (identical body within the cooldown is skipped), and a bounded queue.
"""
from __future__ import annotations

import time
from typing import Any, Dict, Optional, Set

from .config import load_config
from .formatter import SEP
from .models import state
from .openwa_client import client as openwa

# Categories that map to env flags.
CATEGORY_FLAG = {
    "task_complete": "notify_task_complete",
    "task_failed": "notify_task_failed",
    "agent_waiting": "notify_agent_waiting",
    "terminal_crash": "notify_terminal_crash",
    "system_error": "notify_system_error",
}

_recent_bodies: Dict[str, float] = {}  # body hash -> last sent ts (dedup)


def _category_enabled(category: str) -> bool:
    cfg = load_config()
    flag = CATEGORY_FLAG.get(category)
    if not flag:
        return False
    return bool(getattr(cfg, flag, False))


def _cooldown_ok(category: str) -> bool:
    cfg = load_config()
    last = state.notify_last_sent.get(category, 0.0)
    return time.time() - last >= cfg.notify_min_interval_seconds


def push(category: str, body: str, chat_id: str = "") -> bool:
    """Send a proactive notification (if enabled + not on cooldown + not a
    duplicate).  Returns True when a message was actually sent."""
    if not _category_enabled(category):
        return False
    if not _cooldown_ok(category):
        return False
    body_hash = category + "|" + body[:200]
    if _recent_bodies.get(body_hash, 0) > time.time() - 60:
        return False
    _recent_bodies[body_hash] = time.time()
    sent = False
    # WhatsApp channel (existing OpenWA transport).
    target = chat_id or _default_chat()
    if target:
        try:
            sent = openwa.send_message(target, body) or sent
        except Exception:
            pass
    # Telegram channel (alternative/parallel transport — same body).
    cfg = load_config()
    if cfg.telegram_enabled:
        try:
            from .telegram import send_telegram_notification_sync
            sent = send_telegram_notification_sync(body) or sent
        except Exception:
            pass
    if sent:
        state.notify_last_sent[category] = time.time()
    return sent


def _default_chat() -> str:
    cfg = load_config()
    if cfg.allowed_chat_ids:
        return cfg.allowed_chat_ids[0]
    if cfg.allowed_phone_numbers:
        return cfg.allowed_phone_numbers[0]
    return ""


def format_task_complete(terminal_label: str, task: Dict[str, Any], duration_sec: float) -> str:
    return (
        f"✅ TERMINAL {terminal_label} COMPLETED\n\n"
        f"Task:\n{task.get('description', '')[:200]}\n\n"
        f"Duration: {_fmt_duration(duration_sec)}\n"
        f"Result: SUCCESS"
    )


def format_task_failed(terminal_label: str, task: Dict[str, Any], error: str = "") -> str:
    return (
        f"❌ TERMINAL {terminal_label} FAILED\n\n"
        f"Task:\n{task.get('description', '')[:200]}\n\n"
        + (f"Error: {error[:200]}\n" if error else "")
        + SEP
    )


def format_agent_waiting(terminal_label: str, agent: str = "") -> str:
    return f"🟡 TERMINAL {terminal_label} WAITING\n{agent or 'Agent'} is waiting for input."


def format_terminal_crash(terminal_label: str) -> str:
    return f"💥 TERMINAL {terminal_label} CRASHED\nCheck the workspace layout."


def format_system_error(error: str) -> str:
    return f"⚠️ TTO SYSTEM ERROR\n{error[:200]}"


def _fmt_duration(sec: float) -> str:
    sec = max(0, int(sec))
    if sec < 60:
        return f"{sec}s"
    if sec < 3600:
        return f"{sec // 60}m {sec % 60}s"
    return f"{sec // 3600}h {sec % 3600 // 60}m"
