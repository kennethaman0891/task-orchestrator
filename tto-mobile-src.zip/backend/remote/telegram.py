"""TTO Remote Control — Telegram bot transport.

Telegram gives TTO a real separate bot identity (no second SIM needed).  The
ENTIRE command engine is shared with WhatsApp: parser → service →
confirmations/safety/formatter.  Only the transport differs — Telegram's Bot
API via long polling (works on localhost, no public webhook URL required).

Environment (see .env.example):
  TTO_TELEGRAM_ENABLED=true
  TELEGRAM_BOT_TOKEN=<token from @BotFather>
  TELEGRAM_ALLOWED_USER_IDS=<numeric telegram user ids, comma separated>

Security is identical to WhatsApp: fail-closed allowlist, per-sender rate
limit, sender-bound expiring confirmations, command classification, audit log
(never secrets).  The bot token is a secret and is never logged.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

from . import service
from .auth import rate_limit_exceeded
from .config import load_config
from .models import AuditEntry, log_audit, state
from .parser import parse_message

_API = "https://api.telegram.org"


class TelegramTransport:
    """Minimal Telegram Bot API client (stdlib urllib, no third-party deps)."""

    def __init__(self, token: str, base_url: str = _API) -> None:
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.last_error = ""

    def _call(self, method: str, payload: Optional[dict] = None, timeout: float = 30.0) -> Optional[dict]:
        if not self.token:
            return None
        url = f"{self.base_url}/bot{self.token}/{method}"
        body = json.dumps(payload or {}).encode() if payload is not None else None
        headers = {"Content-Type": "application/json"}
        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except Exception as e:  # network / HTTP / JSON
            self.last_error = str(e)
            return None

    def get_updates(self, offset: int = 0, timeout: int = 25) -> List[dict]:
        res = self._call("getUpdates", {"offset": offset, "timeout": timeout}, timeout=timeout + 5)
        if not res or not res.get("ok"):
            return []
        return res.get("result") or []

    def send_message(self, chat_id: int, text: str) -> bool:
        if not text:
            return False
        res = self._call("sendMessage", {"chat_id": chat_id, "text": text})
        return bool(res and res.get("ok"))

    def set_my_commands(self, commands: List[Dict[str, str]]) -> bool:
        res = self._call("setMyCommands", {"commands": commands})
        return bool(res and res.get("ok"))


def _update_parts(update: Dict[str, Any]) -> Optional[Tuple[int, int, str]]:
    """Extract (chat_id, user_id, text) from a message update, or None.

    Only plain text messages from users (not bots) are handled; edits,
    media, channels and other update kinds are ignored safely."""
    msg = update.get("message") or update.get("edited_message")
    if not isinstance(msg, dict):
        return None
    if msg.get("from", {}).get("is_bot"):
        return None
    text = msg.get("text")
    if not isinstance(text, str) or not text.strip():
        return None  # media / non-text messages
    chat_id = msg.get("chat", {}).get("id")
    user_id = msg.get("from", {}).get("id")
    if chat_id is None or user_id is None:
        return None
    return int(chat_id), int(user_id), text.strip()


async def handle_telegram_update(update: Dict[str, Any], transport: Optional[TelegramTransport] = None) -> Optional[Tuple[int, str]]:
    """Process one Telegram update; return (chat_id, reply_text) when a reply
    should be sent, else None.  Testable: transport is only used for nothing
    here (the caller sends), but kept for signature symmetry.

    Reuses the exact same pipeline as WhatsApp: parse → dispatch → reply.
    Unauthorized users are silently ignored (except /start, which reports the
    user's own id so they can allowlist themselves)."""
    parts = _update_parts(update)
    if not parts:
        return None
    chat_id, user_id, text = parts
    cfg = load_config()

    # /start is the only thing an unauthorized user may hear: it reports their
    # numeric id (needed to configure TELEGRAM_ALLOWED_USER_IDS).
    first = text.strip().lower().split()
    if first and first[0].split("@")[0] == "/start":
        allowed = str(user_id) in cfg.telegram_allowed_user_ids
        from . import formatter as _fmt
        msg = (
            f"🖥️ TTO REMOTE — Welcome!\n\n"
            f"Your Telegram user id: {user_id}\n"
            f"Status: {'🟢 authorized' if allowed else '🔴 NOT authorized'}\n\n"
            + (f"{'═' * 30}\n\n{_fmt.help_message()}" if allowed else
               f"To enable: add {user_id} to TELEGRAM_ALLOWED_USER_IDS\n"
               f"in ~/tto-web/.env and restart the sidecar.\n\n"
               f"Send /help once authorized.")
        )
        return chat_id, msg

    sender = str(user_id)
    if sender not in cfg.telegram_allowed_user_ids:
        return None  # silent ignore — bot presence is not advertised

    if rate_limit_exceeded(sender):
        return chat_id, "⏳ Too many commands — please wait a moment."

    start = time.time()
    cmd = parse_message(text)
    result = await service.dispatch(sender, str(chat_id), cmd)
    log_audit(AuditEntry(
        sender=sender, command=cmd.name, terminal=cmd.target or "",
        result=result.reply[:100], success=result.ok,
        confirmation=result.confirmation_token or "",
        duration_ms=round((time.time() - start) * 1000),
    ))
    return chat_id, result.reply


def send_telegram_notification_sync(text: str) -> bool:
    """Push a proactive notification to the first allowed Telegram user.
    Synchronous (blocking urllib) so the notification loop can call it directly."""
    cfg = load_config()
    if not cfg.telegram_enabled or not cfg.telegram_bot_token:
        return False
    if not cfg.telegram_allowed_user_ids:
        return False
    try:
        chat_id = int(cfg.telegram_allowed_user_ids[0])
    except (TypeError, ValueError):
        return False
    return TelegramTransport(cfg.telegram_bot_token).send_message(chat_id, text)


async def send_telegram_notification(text: str) -> bool:
    """Async wrapper (same transport)."""
    return send_telegram_notification_sync(text)
